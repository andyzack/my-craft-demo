# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 5.6.38)
# Database: my_craft_demo
# Generation Time: 2021-01-03 04:19:08 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table assetindexdata
# ------------------------------------------------------------

DROP TABLE IF EXISTS `assetindexdata`;

CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(36) NOT NULL DEFAULT '',
  `volumeId` int(11) NOT NULL,
  `uri` text,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `recordId` int(11) DEFAULT NULL,
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assetindexdata_sessionId_volumeId_idx` (`sessionId`,`volumeId`),
  KEY `assetindexdata_volumeId_idx` (`volumeId`),
  CONSTRAINT `assetindexdata_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table assets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `assets`;

CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assets_filename_folderId_idx` (`filename`,`folderId`),
  KEY `assets_folderId_idx` (`folderId`),
  KEY `assets_volumeId_idx` (`volumeId`),
  KEY `assets_uploaderId_fk` (`uploaderId`),
  CONSTRAINT `assets_folderId_fk` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assets_uploaderId_fk` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `assets_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;

INSERT INTO `assets` (`id`, `volumeId`, `folderId`, `uploaderId`, `filename`, `kind`, `width`, `height`, `size`, `focalPoint`, `deletedWithVolume`, `keptFile`, `dateModified`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(6,1,1,5,'branchout-logo.svg','image',118,82,5607,NULL,NULL,NULL,'2020-12-07 19:19:19','2020-12-07 19:19:19','2020-12-07 19:19:19','5de950b9-abc4-42d1-966c-8c3a88cecca0'),
	(7,1,1,5,'branchout-jaggeddivider.svg','image',1432,92,5599,NULL,NULL,NULL,'2020-12-07 19:19:34','2020-12-07 19:19:34','2020-12-07 19:19:34','70d597a9-becc-433a-a14b-4baceac6cbca'),
	(8,1,1,5,'branchout-badge.svg','image',184,184,13506,NULL,NULL,NULL,'2020-12-07 19:19:40','2020-12-07 19:19:40','2020-12-07 19:19:40','18e1a880-d480-4233-9523-58a875be51cd'),
	(9,1,1,5,'branchout-icon1.svg','image',55,55,1930,NULL,NULL,NULL,'2020-12-07 19:19:48','2020-12-07 19:19:48','2020-12-07 19:19:48','e8743711-20d2-4f23-9f86-6a00e1dc3456'),
	(10,1,1,5,'branchout-icon2.svg','image',55,55,1143,NULL,NULL,NULL,'2020-12-07 19:19:53','2020-12-07 19:19:53','2020-12-07 19:19:53','97307dbb-a354-4309-950f-2f3993975c83'),
	(11,1,1,5,'branchout-icon3.svg','image',55,55,1936,NULL,NULL,NULL,'2020-12-07 19:19:58','2020-12-07 19:19:58','2020-12-07 19:19:58','d95900a1-a84d-46ba-9b50-8cad72b9803c'),
	(12,1,1,5,'branchout-icon4.svg','image',55,55,2068,NULL,NULL,NULL,'2020-12-07 19:20:03','2020-12-07 19:20:03','2020-12-07 19:20:03','1206ac45-db52-4e0f-89d1-19e809553dbc'),
	(13,1,1,5,'branchout-icon5.svg','image',55,55,1793,NULL,NULL,NULL,'2020-12-07 19:20:08','2020-12-07 19:20:08','2020-12-07 19:20:08','5a1ff7a4-1846-496e-8e63-f5e3c0bc87d2'),
	(14,1,1,5,'14711049381_84dab5ff50_o.jpg','image',3744,5616,2551821,NULL,NULL,NULL,'2020-12-07 19:23:21','2020-12-07 19:23:22','2020-12-07 19:23:22','ed698965-bc81-45ab-81f4-fd290e7c3da2'),
	(15,1,1,5,'MG_7346.jpg','image',5566,3711,6688288,NULL,NULL,NULL,'2020-12-07 19:23:53','2020-12-07 19:23:55','2020-12-07 19:23:55','23a76cc6-8a6d-4540-8106-dc4a45642b92'),
	(16,1,1,5,'MG_8600.jpg','image',5616,3744,5185054,NULL,NULL,NULL,'2020-12-07 19:24:17','2020-12-07 19:24:18','2020-12-07 19:24:18','18303c3d-7c52-4595-8cd5-d3e940380cf7'),
	(17,1,1,5,'40999098740_eb68d5446e_o.jpg','image',5616,3744,5291286,NULL,NULL,NULL,'2020-12-07 19:24:49','2020-12-07 19:24:50','2020-12-07 19:24:50','e6143407-0a79-455a-8481-0f7d1107960d'),
	(18,1,1,5,'adventure-stock.jpg','image',1480,1082,603465,NULL,NULL,NULL,'2020-12-07 19:25:06','2020-12-07 19:25:07','2020-12-07 19:25:07','9964f094-52ac-4914-8304-6db2ef44f0df'),
	(19,1,1,5,'IMG_8649.jpg','image',5616,3744,4764320,NULL,NULL,NULL,'2020-12-07 19:25:32','2020-12-07 19:25:32','2020-12-07 19:25:32','31c8b500-2e3a-4247-886b-2d0c9bd3b2aa'),
	(20,1,1,5,'MG_9091.jpg','image',2048,1365,1720183,NULL,NULL,NULL,'2020-12-07 19:25:52','2020-12-07 19:25:52','2020-12-07 19:25:52','004a2e36-f1b8-4a7a-a077-7913b3cb5396'),
	(21,1,1,5,'MG_8105.jpg','image',5616,3744,7324270,NULL,NULL,NULL,'2020-12-07 19:26:20','2020-12-07 19:26:21','2020-12-07 19:26:21','4a81673f-3d84-4a5d-9863-95cbd6bce362'),
	(22,1,1,5,'MG_7359.jpg','image',5616,3744,5370230,NULL,NULL,NULL,'2020-12-07 19:26:45','2020-12-07 19:26:46','2020-12-07 19:26:46','d6fdd42f-0a87-4f67-b5ef-c6a90aabe422');

/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table assettransformindex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `assettransformindex`;

CREATE TABLE `assettransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assettransformindex_volumeId_assetId_location_idx` (`volumeId`,`assetId`,`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `assettransformindex` WRITE;
/*!40000 ALTER TABLE `assettransformindex` DISABLE KEYS */;

INSERT INTO `assettransformindex` (`id`, `assetId`, `filename`, `format`, `location`, `volumeId`, `fileExists`, `inProgress`, `error`, `dateIndexed`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,14,'14711049381_84dab5ff50_o.jpg',NULL,'_1400x1400_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:49','3f579010-755b-476d-ab44-569e01f9a8e1'),
	(2,14,'14711049381_84dab5ff50_o.jpg',NULL,'_700x700_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','40073e42-a695-427a-9c4b-71efef09ec64'),
	(3,14,'14711049381_84dab5ff50_o.jpg',NULL,'_350x350_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','d8e1f3db-50a3-4e72-b529-64577d5ad372'),
	(4,15,'MG_7346.jpg',NULL,'_1400x1400_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:49','d8a95da7-9b38-4e13-a145-b05fb6629871'),
	(5,15,'MG_7346.jpg',NULL,'_700x700_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','51c5eceb-d7c4-4721-8306-675a0428b761'),
	(6,15,'MG_7346.jpg',NULL,'_350x350_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','49343c8d-44e4-4a2d-b7d0-59d271342c4b'),
	(7,16,'MG_8600.jpg',NULL,'_1400x1400_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:49','6c9de20b-2ef0-42c8-8fc0-5a19879e8315'),
	(8,16,'MG_8600.jpg',NULL,'_700x700_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','283a8fc5-9b28-4cb4-af68-78c3cd8bc7df'),
	(9,16,'MG_8600.jpg',NULL,'_350x350_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','ce2834dc-1575-42d3-82ac-0cedc8b49936'),
	(10,20,'MG_9091.jpg',NULL,'_1400x1400_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:49','21e16bdb-1cb4-4cc5-ba68-f91770b8db08'),
	(11,20,'MG_9091.jpg',NULL,'_700x700_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','5ce53e33-fa6b-41ed-ad7a-896730eb5731'),
	(12,20,'MG_9091.jpg',NULL,'_350x350_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','3ecd7e97-281e-426c-8ddc-c85ca03fe70b'),
	(13,9,'branchout-icon1.svg',NULL,'_1400x1400_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','cbf89a81-89dd-42b1-839a-af06f4e12477'),
	(14,9,'branchout-icon1.svg',NULL,'_700x700_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','0acf38a9-ab6e-4a91-ac99-cad4d9a2d097'),
	(15,9,'branchout-icon1.svg',NULL,'_350x350_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','94a9c415-0600-4ef7-bd7f-6d2167606077'),
	(16,10,'branchout-icon2.svg',NULL,'_1400x1400_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','b60d6905-a072-4be4-bf77-2ab2b2e5de2b'),
	(17,10,'branchout-icon2.svg',NULL,'_700x700_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','d8236518-e93c-4e2d-804e-cbf6aa702845'),
	(18,10,'branchout-icon2.svg',NULL,'_350x350_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','766ecf82-aa3c-4073-bea9-829c34512fa1'),
	(19,11,'branchout-icon3.svg',NULL,'_1400x1400_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','902b39e7-1638-4cd8-a398-d4c43fa83787'),
	(20,11,'branchout-icon3.svg',NULL,'_700x700_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','bbf18549-ee30-4e95-8e5a-d2bc71da3f9a'),
	(21,11,'branchout-icon3.svg',NULL,'_350x350_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','694d5fbd-8e0a-48ad-8837-17d8d5d76e71'),
	(22,12,'branchout-icon4.svg',NULL,'_1400x1400_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','25ed7e07-2ae8-492a-90c3-4821e5be57e4'),
	(23,12,'branchout-icon4.svg',NULL,'_700x700_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','baa10194-d944-4d8a-9d74-30d380b4b61c'),
	(24,12,'branchout-icon4.svg',NULL,'_350x350_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:50','60c03f8d-961a-4626-8c98-2152f1a66d1b'),
	(25,13,'branchout-icon5.svg',NULL,'_1400x1400_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','b464d8bf-9825-4599-850a-04a4c9c92e75'),
	(26,13,'branchout-icon5.svg',NULL,'_700x700_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','b16160a6-2ff0-4e8c-b2f8-664214e513f5'),
	(27,13,'branchout-icon5.svg',NULL,'_350x350_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','761e3afd-6bb6-4e1f-9d61-c7ccbc6eaac8'),
	(28,18,'adventure-stock.jpg',NULL,'_1400x788_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','21529406-38bf-47c1-ab80-751f947cf127'),
	(29,18,'adventure-stock.jpg',NULL,'_700x394_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','654975c4-35b7-4706-bcf9-4e9a03009b21'),
	(30,18,'adventure-stock.jpg',NULL,'_350x197_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','23af04a5-874f-4075-8672-9bfe2b2bfa86'),
	(31,19,'IMG_8649.jpg',NULL,'_1400x788_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','393c1e2c-acb5-4fb4-b5ed-00a9fb60df83'),
	(32,19,'IMG_8649.jpg',NULL,'_700x394_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','157551c1-f13c-435c-ad35-220df78edfa9'),
	(33,19,'IMG_8649.jpg',NULL,'_350x197_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','6a4423fb-ac19-4315-a659-4831dde42011'),
	(34,20,'MG_9091.jpg',NULL,'_1400x788_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','dae353dd-adb8-4018-8ed8-a0b7df49c290'),
	(35,20,'MG_9091.jpg',NULL,'_700x394_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','682bf06d-dc8b-4272-b2ec-f17d24d0059d'),
	(36,20,'MG_9091.jpg',NULL,'_350x197_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','cb0888c7-c079-45fb-8e8c-66f968f57995'),
	(37,21,'MG_8105.jpg',NULL,'_1400x788_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','03f134f8-76c1-424f-9e86-41a4ba14ec7b'),
	(38,21,'MG_8105.jpg',NULL,'_700x394_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','cbae8986-7866-435d-b65c-4b4e5c15a366'),
	(39,21,'MG_8105.jpg',NULL,'_350x197_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','0ecd1813-14cc-4c29-9ed4-d189f03d09db'),
	(40,22,'MG_7359.jpg',NULL,'_1400x788_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','b5dea93f-4428-4f07-ba71-3f9306b81a1e'),
	(41,22,'MG_7359.jpg',NULL,'_700x394_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','db9cd718-9f4e-437c-93e9-db585879047d'),
	(42,22,'MG_7359.jpg',NULL,'_350x197_crop_center-center_none',1,1,0,0,'2021-01-02 22:41:48','2021-01-02 22:41:48','2021-01-02 22:41:51','a2bd1f69-3dcc-440e-ac4b-c61721d48799');

/*!40000 ALTER TABLE `assettransformindex` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table assettransforms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `assettransforms`;

CREATE TABLE `assettransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `dimensionChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `assettransforms_name_idx` (`name`),
  KEY `assettransforms_handle_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categories_groupId_idx` (`groupId`),
  KEY `categories_parentId_fk` (`parentId`),
  CONSTRAINT `categories_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table categorygroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `categorygroups`;

CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `categorygroups_name_idx` (`name`),
  KEY `categorygroups_handle_idx` (`handle`),
  KEY `categorygroups_structureId_idx` (`structureId`),
  KEY `categorygroups_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `categorygroups_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `categorygroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `categorygroups_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table categorygroups_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `categorygroups_sites`;

CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorygroups_sites_groupId_siteId_unq_idx` (`groupId`,`siteId`),
  KEY `categorygroups_sites_siteId_idx` (`siteId`),
  CONSTRAINT `categorygroups_sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categorygroups_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table changedattributes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `changedattributes`;

CREATE TABLE `changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `changedattributes_elementId_siteId_dateUpdated_idx` (`elementId`,`siteId`,`dateUpdated`),
  KEY `changedattributes_siteId_fk` (`siteId`),
  KEY `changedattributes_userId_fk` (`userId`),
  CONSTRAINT `changedattributes_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `changedattributes_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `changedattributes_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;

INSERT INTO `changedattributes` (`elementId`, `siteId`, `attribute`, `dateUpdated`, `propagated`, `userId`)
VALUES
	(57,1,'uri','2020-12-09 07:17:29',0,5),
	(61,1,'uri','2020-12-09 07:17:29',0,5),
	(64,1,'uri','2020-12-09 07:17:29',0,5);

/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table changedfields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `changedfields`;

CREATE TABLE `changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `changedfields_elementId_siteId_dateUpdated_idx` (`elementId`,`siteId`,`dateUpdated`),
  KEY `changedfields_siteId_fk` (`siteId`),
  KEY `changedfields_fieldId_fk` (`fieldId`),
  KEY `changedfields_userId_fk` (`userId`),
  CONSTRAINT `changedfields_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `changedfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `changedfields_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `changedfields_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;

INSERT INTO `changedfields` (`elementId`, `siteId`, `fieldId`, `dateUpdated`, `propagated`, `userId`)
VALUES
	(1,1,2,'2020-12-10 00:34:14',0,5),
	(1,1,28,'2020-12-14 23:15:25',0,5),
	(1,1,32,'2020-12-09 23:18:21',0,5),
	(1,1,38,'2020-12-16 12:18:09',0,5),
	(1,1,44,'2020-12-16 06:05:09',0,5),
	(3,1,2,'2020-12-07 20:36:27',0,5),
	(57,1,2,'2020-12-09 07:19:41',0,5),
	(57,1,18,'2020-12-09 07:19:41',0,5),
	(57,1,19,'2020-12-09 07:19:41',0,5),
	(57,1,20,'2020-12-09 07:19:41',0,5),
	(61,1,2,'2020-12-09 07:19:41',0,5),
	(61,1,18,'2020-12-09 07:19:41',0,5),
	(61,1,19,'2020-12-09 07:19:41',0,5),
	(61,1,20,'2020-12-09 07:19:41',0,5),
	(64,1,2,'2020-12-09 07:19:41',0,5),
	(64,1,18,'2020-12-09 07:19:41',0,5),
	(64,1,19,'2020-12-09 07:19:41',0,5),
	(64,1,20,'2020-12-09 07:19:41',0,5);

/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table content
# ------------------------------------------------------------

DROP TABLE IF EXISTS `content`;

CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_summary` text,
  `field_imageAlt` text,
  `field_caption` text,
  `field_introduction` text,
  `field_pageCopy` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `content_siteId_idx` (`siteId`),
  KEY `content_title_idx` (`title`),
  CONSTRAINT `content_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `content_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;

INSERT INTO `content` (`id`, `elementId`, `siteId`, `title`, `dateCreated`, `dateUpdated`, `uid`, `field_summary`, `field_imageAlt`, `field_caption`, `field_introduction`, `field_pageCopy`)
VALUES
	(1,1,1,'Home','2020-12-07 08:31:20','2020-12-16 12:19:22','184ccb45-5cd6-4ed1-a067-34e260f241ba',NULL,NULL,NULL,NULL,NULL),
	(2,2,1,'Home','2020-12-07 08:31:20','2020-12-07 08:31:20','1331d262-60d7-41f8-bcf8-9eca3895e42a',NULL,NULL,NULL,NULL,NULL),
	(3,3,1,'About','2020-12-07 08:31:20','2020-12-07 20:36:27','b744c340-c655-422b-8567-c543e5046b43',NULL,NULL,NULL,NULL,NULL),
	(4,4,1,'About','2020-12-07 08:31:20','2020-12-07 08:31:20','e078fd4d-64b4-49dc-8507-6f0b4e84a17d',NULL,NULL,NULL,NULL,NULL),
	(5,5,1,NULL,'2020-12-07 08:31:22','2020-12-07 08:31:22','2e2b806b-9a63-46f0-ae81-2bfdedbdef64',NULL,NULL,NULL,NULL,NULL),
	(6,6,1,'Branchout logo','2020-12-07 19:19:19','2020-12-07 19:19:19','55067e8c-453a-4880-b5b0-fb058b6aa89b',NULL,NULL,NULL,NULL,NULL),
	(7,7,1,'Branchout jaggeddivider','2020-12-07 19:19:34','2020-12-07 19:19:34','795f5859-1783-4a98-bafd-23ff760e233a',NULL,NULL,NULL,NULL,NULL),
	(8,8,1,'Branchout badge','2020-12-07 19:19:40','2020-12-07 19:19:40','f3b7c223-0fe5-448b-85d2-c3d2924513b1',NULL,NULL,NULL,NULL,NULL),
	(9,9,1,'Intimate Groups','2020-12-07 19:19:48','2020-12-09 22:59:17','3cf9e581-13cc-4c01-ac22-555625ecc0fb',NULL,'Intimate Groups','Intimate Groups',NULL,NULL),
	(10,10,1,'Premium Accomodation','2020-12-07 19:19:53','2020-12-09 22:59:29','d3790705-0a8e-4450-a205-5d215dc6b845',NULL,'Premium Accomodation','Premium Accomodation',NULL,NULL),
	(11,11,1,'Luxury Experiences in Local Communities','2020-12-07 19:19:58','2020-12-09 22:59:40','e1c3a503-3d0a-4eae-b2b2-f2c8e89f619d',NULL,'Luxury Experiences in Local Communities','Luxury Experiences in Local Communities',NULL,NULL),
	(12,12,1,'VIP Options','2020-12-07 19:20:03','2020-12-09 22:59:51','15ace3e2-7c99-4cfd-9c6d-b9398253609b',NULL,'VIP Options','VIP Options',NULL,NULL),
	(13,13,1,'Local Guides, Real Connections','2020-12-07 19:20:08','2020-12-09 23:00:02','4d28a6dd-a740-4ab5-88e0-17c42841c425',NULL,'Local Guides, Real Connections','Local Guides, Real Connections',NULL,NULL),
	(14,14,1,'Activities','2020-12-07 19:23:16','2020-12-09 19:10:59','7d7fa7ef-7a32-4e08-be35-ab5054b6fa9f',NULL,'Immersive Activities','Immersive Activities',NULL,NULL),
	(15,15,1,'Places','2020-12-07 19:23:41','2020-12-09 19:10:52','8b3d7428-ca41-4df8-896b-a63c142bce02',NULL,'Incredible Places','Incredible Places',NULL,NULL),
	(16,16,1,'Packages','2020-12-07 19:24:05','2020-12-09 19:10:45','941b11fb-1f48-4b96-be75-faff98e7f057',NULL,'Curative Packages','Curative Packages',NULL,NULL),
	(17,17,1,'Connecting people and places','2020-12-07 19:24:37','2020-12-09 23:20:40','b93da302-cf48-4e21-a6cb-d580c0772bfb',NULL,'Connecting people and places','Connecting people and places',NULL,NULL),
	(18,18,1,'The Icons of Tasmania','2020-12-07 19:25:06','2020-12-09 00:05:00','08067035-1672-4140-9f52-6c707e520669',NULL,'Tasmania','4 Days / 3 Nights',NULL,NULL),
	(19,19,1,'Make the most of the Gold Coast','2020-12-07 19:25:21','2020-12-09 00:05:33','170e3261-ab4f-4185-803d-85c6be589589',NULL,'Gold Coast','4 Days / 3 Nights',NULL,NULL),
	(20,20,1,'The gateway to Queensland\'s tropical north, Cairns','2020-12-07 19:25:50','2020-12-16 12:17:30','1a19d6da-073c-41cd-b7a1-3fc96d593485',NULL,'Cairns','gateway to Queensland\'s tropical north',NULL,NULL),
	(21,21,1,'Hobart is a small city with big ideas','2020-12-07 19:26:07','2020-12-09 00:04:37','89941382-33ee-42eb-a914-db4d906561cd',NULL,'Hobart','4 Days / 3 Nights',NULL,NULL),
	(22,22,1,'Beating heart of Australia\'s Red Centre, Alice','2020-12-07 19:26:31','2020-12-09 00:06:15','e5bfe478-cf10-482a-9e65-3216f5c9f4fb',NULL,'Alice Springs','4 Days / 3 Nights',NULL,NULL),
	(23,23,1,'Home','2020-12-07 19:31:38','2020-12-07 19:31:38','57ec8be2-4903-4b0d-b301-1558820a4947',NULL,NULL,NULL,NULL,NULL),
	(24,26,1,'About','2020-12-07 19:56:43','2020-12-07 19:56:43','0ebf5451-6d5e-4ed8-9b4c-0a0768f6acf3',NULL,NULL,NULL,NULL,NULL),
	(25,29,1,'About','2020-12-07 20:14:29','2020-12-07 20:14:29','7949162e-0111-4b5c-b9cc-6c3e89630a83',NULL,NULL,NULL,NULL,NULL),
	(26,32,1,'About','2020-12-07 20:36:27','2020-12-07 20:36:27','b5ac0d81-daa6-4d54-8a66-dc0fa440cc41',NULL,NULL,NULL,NULL,NULL),
	(28,36,1,'GUIDE TO BROOME','2020-12-07 22:23:41','2020-12-07 22:23:41','2142e849-abd9-4da5-9b50-a6e2f9dd58d2','<p>Broome’s rich and colourful history has created a multicultural melting pot that is reflected in the town’s welcoming and laid-back feel. Warm temperatures and palms deliver a tropical vibe that fits perfectly with the many holiday resorts and the stretch of white sand known as <a href=\"https://www.westernaustralia.com/en/Attraction/Cable_Beach/56b2669daeeeaaf773cf9303\" target=\"_blank\" rel=\"noreferrer noopener\">Cable Beach</a>.</p>\n<p><strong>Don\'t miss</strong></p>\n<ul><li>Watching the sunset on the endless sandy stretch of Cable Beach</li><li>Trying on the perfect white orbs of cultured Broome pearls</li><li>The trip of a lifetime – cruising the Kimberley, departing from Broome</li></ul><p><strong>How to get there</strong></p>\n<p><a href=\"https://www.virginaustralia.com/au/en/\" target=\"_blank\" rel=\"noreferrer noopener\">Virgin Australia</a> and <a href=\"https://www.qantas.com/au/en.html\" target=\"_blank\" rel=\"noreferrer noopener\">Qantas</a> fly to <a href=\"https://www.australiasnorthwest.com/destination/broome\" target=\"_blank\" rel=\"noreferrer noopener\">Broome</a> and it is <a href=\"http://www.broomeair.com.au/passenger-info/airlines/\" target=\"_blank\" rel=\"noreferrer noopener\">serviced</a> by most Australian capital cities. Otherwise, it’s a 2,226-kilometre (1,383-mile) drive from <a href=\"https://www.australia.com/en/places/perth-and-surrounds/guide-to-perth.html\">Perth</a>, the capital city of <a href=\"https://www.australia.com/en/places/western-australia.html\">Western Australia</a>.</p>\n<p><br /></p>',NULL,NULL,NULL,NULL),
	(29,37,1,'GUIDE TO BROOME','2020-12-07 22:23:41','2020-12-07 22:23:41','6ed227e6-b01a-486d-b0ef-7cb4333e409d','<p>Broome’s rich and colourful history has created a multicultural melting pot that is reflected in the town’s welcoming and laid-back feel. Warm temperatures and palms deliver a tropical vibe that fits perfectly with the many holiday resorts and the stretch of white sand known as <a href=\"https://www.westernaustralia.com/en/Attraction/Cable_Beach/56b2669daeeeaaf773cf9303\" target=\"_blank\" rel=\"noreferrer noopener\">Cable Beach</a>.</p>\n<p><strong>Don\'t miss</strong></p>\n<ul><li>Watching the sunset on the endless sandy stretch of Cable Beach</li><li>Trying on the perfect white orbs of cultured Broome pearls</li><li>The trip of a lifetime – cruising the Kimberley, departing from Broome</li></ul><p><strong>How to get there</strong></p>\n<p><a href=\"https://www.virginaustralia.com/au/en/\" target=\"_blank\" rel=\"noreferrer noopener\">Virgin Australia</a> and <a href=\"https://www.qantas.com/au/en.html\" target=\"_blank\" rel=\"noreferrer noopener\">Qantas</a> fly to <a href=\"https://www.australiasnorthwest.com/destination/broome\" target=\"_blank\" rel=\"noreferrer noopener\">Broome</a> and it is <a href=\"http://www.broomeair.com.au/passenger-info/airlines/\" target=\"_blank\" rel=\"noreferrer noopener\">serviced</a> by most Australian capital cities. Otherwise, it’s a 2,226-kilometre (1,383-mile) drive from <a href=\"https://www.australia.com/en/places/perth-and-surrounds/guide-to-perth.html\">Perth</a>, the capital city of <a href=\"https://www.australia.com/en/places/western-australia.html\">Western Australia</a>.</p>\n<p><br /></p>',NULL,NULL,NULL,NULL),
	(31,39,1,'GUIDE TO ALICE SPRINGS','2020-12-07 22:25:36','2020-12-07 22:25:36','eb7491bf-36eb-4fc0-958b-a7293818226a','<p>Surrounded by ochre sands and hauntingly beautiful mountain ranges is Alice Springs, a city perhaps surprisingly full of arts, events and culture despite its remoteness. Known to locals simply as \"Alice\", it\'s the beating heart of Australia\'s <a href=\"https://www.australia.com/en/places/alice-springs-and-surrounds/guide-to-the-red-centre.html\">Red Centre</a> and one of the largest towns in the <a href=\"https://www.australia.com/en/places/northern-territory.html\">Northern Territory</a>. Alice is also a fascinating spot to explore Australia\'s Aboriginal culture and unique wildlife.</p>\n<p>While there is plenty to do in the town itself, Alice Springs is also a great base for exploring the natural wonders of the outback, including <a href=\"https://northernterritory.com/uluru-and-surrounds\" target=\"_blank\" rel=\"noreferrer noopener\">Ulu<u>r</u>u</a>, <a href=\"https://www.australia.com/en/places/alice-springs-and-surrounds/guide-to-kata-tjuta.html\">Kata Tju<u>t</u>a</a>, <a href=\"https://www.australia.com/en/places/alice-springs-and-surrounds/guide-to-kings-canyon.html\" target=\"_blank\" rel=\"noreferrer noopener\">Kings Canyon</a>, the <a href=\"https://northernterritory.com/alice-springs-and-surrounds/destinations/tjoritja-west-macdonnell-national-park\" target=\"_blank\" rel=\"noreferrer noopener\">West MacDonnell Ranges</a>.</p>\n<p><strong>Don\'t miss</strong></p>\n<ul><li>Get up close and personal with native wildlife at The Kangaroo Sanctuary</li><li>Dine under the stars with Aboriginal chef Bob Pernuka from RT Tours</li><li>Discover the work of noted Indigenous artists at Araluen Arts Centre</li></ul>',NULL,NULL,NULL,NULL),
	(32,40,1,'GUIDE TO ALICE SPRINGS','2020-12-07 22:25:36','2020-12-07 22:25:36','8a828f75-0e72-4013-bb88-8b6edc1dd058','<p>Surrounded by ochre sands and hauntingly beautiful mountain ranges is Alice Springs, a city perhaps surprisingly full of arts, events and culture despite its remoteness. Known to locals simply as \"Alice\", it\'s the beating heart of Australia\'s <a href=\"https://www.australia.com/en/places/alice-springs-and-surrounds/guide-to-the-red-centre.html\">Red Centre</a> and one of the largest towns in the <a href=\"https://www.australia.com/en/places/northern-territory.html\">Northern Territory</a>. Alice is also a fascinating spot to explore Australia\'s Aboriginal culture and unique wildlife.</p>\n<p>While there is plenty to do in the town itself, Alice Springs is also a great base for exploring the natural wonders of the outback, including <a href=\"https://northernterritory.com/uluru-and-surrounds\" target=\"_blank\" rel=\"noreferrer noopener\">Ulu<u>r</u>u</a>, <a href=\"https://www.australia.com/en/places/alice-springs-and-surrounds/guide-to-kata-tjuta.html\">Kata Tju<u>t</u>a</a>, <a href=\"https://www.australia.com/en/places/alice-springs-and-surrounds/guide-to-kings-canyon.html\" target=\"_blank\" rel=\"noreferrer noopener\">Kings Canyon</a>, the <a href=\"https://northernterritory.com/alice-springs-and-surrounds/destinations/tjoritja-west-macdonnell-national-park\" target=\"_blank\" rel=\"noreferrer noopener\">West MacDonnell Ranges</a>.</p>\n<p><strong>Don\'t miss</strong></p>\n<ul><li>Get up close and personal with native wildlife at The Kangaroo Sanctuary</li><li>Dine under the stars with Aboriginal chef Bob Pernuka from RT Tours</li><li>Discover the work of noted Indigenous artists at Araluen Arts Centre</li></ul>',NULL,NULL,NULL,NULL),
	(33,41,1,'Home','2020-12-08 08:17:19','2020-12-08 08:17:19','98581e8b-4c5f-4ec8-902b-6c0ddd23d320',NULL,NULL,NULL,NULL,NULL),
	(34,43,1,'Home','2020-12-08 08:19:55','2020-12-08 08:19:55','936f6b21-8cb0-4dce-8fa2-9569f057a958',NULL,NULL,NULL,NULL,NULL),
	(35,45,1,'Home','2020-12-08 08:20:21','2020-12-08 08:20:21','15a5afab-a338-473d-9d73-1ccd9460b570',NULL,NULL,NULL,NULL,NULL),
	(36,50,1,'Home','2020-12-08 09:23:25','2020-12-08 09:23:25','4867d500-2517-46e6-b315-edda0a617c90',NULL,NULL,NULL,NULL,NULL),
	(37,55,1,NULL,'2020-12-08 09:58:09','2020-12-08 09:58:09','4f76e504-14e7-444a-a589-48f1db5fb9f2',NULL,NULL,NULL,NULL,NULL),
	(39,57,1,'Immersive Activities','2020-12-08 10:04:35','2020-12-09 07:19:41','95a70fd0-d1a6-47c4-b2b9-2ba3b72ab922',NULL,NULL,NULL,'Delivering an immersive experience is exciting','<p>Immersive experiences—the use of technology, storytelling, and space to convey a message, educate, or entertain—can transport visitors to another time and/or place. Increasingly, companies are recognizing <a href=\"http://theimmersivexperience.com/2018/06/27/realizing-the-roller-coaster-wow-in-the-business-environment/\" target=\"_blank\" rel=\"noreferrer noopener\">immersive experiences</a> as an opportunity to engage with customers in a unique and powerful way. Here are six tips for approaching your first immersive experience project.</p>'),
	(40,58,1,'Immersive Activities','2020-12-08 10:04:35','2020-12-08 10:04:35','e8529346-c27b-4218-9106-a00ce90abc79',NULL,NULL,NULL,'Delivering an immersive experience is exciting','<p>Immersive experiences—the use of technology, storytelling, and space to convey a message, educate, or entertain—can transport visitors to another time and/or place. Increasingly, companies are recognizing <a href=\"http://theimmersivexperience.com/2018/06/27/realizing-the-roller-coaster-wow-in-the-business-environment/\" target=\"_blank\" rel=\"noreferrer noopener\">immersive experiences</a> as an opportunity to engage with customers in a unique and powerful way. Here are six tips for approaching your first immersive experience project.</p>'),
	(41,59,1,NULL,'2020-12-08 17:46:30','2020-12-08 17:46:30','89f2ea5b-63b3-4f97-9563-2a218d6dfb1b',NULL,NULL,NULL,NULL,NULL),
	(43,61,1,'Places','2020-12-08 17:52:27','2020-12-09 07:19:41','f3069efa-84da-4483-90c6-e8c684f9f809',NULL,NULL,NULL,'Incredible Places','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
	(44,62,1,'Places','2020-12-08 17:52:27','2020-12-08 17:52:27','d6a3abb5-ae52-4d33-bfac-5cb9a9f93992',NULL,NULL,NULL,'Incredible Places','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
	(46,64,1,'Packages','2020-12-08 17:54:04','2020-12-09 07:19:41','f4bb90c0-afeb-46aa-877b-1d695b803488',NULL,NULL,NULL,'Curated Packages','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
	(47,65,1,'Packages','2020-12-08 17:54:04','2020-12-08 17:54:04','44d715b9-e153-4280-8eea-e716583da095',NULL,NULL,NULL,'Curated Packages','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
	(48,67,1,'Packages','2020-12-08 18:08:38','2020-12-08 18:08:38','db3b528b-9b0c-4b6b-abe8-88150b27e06a',NULL,NULL,NULL,'Curated Packages','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
	(49,70,1,'Places','2020-12-08 18:09:16','2020-12-08 18:09:16','31fb36b0-89ba-4bc2-b895-879dbca79762',NULL,NULL,NULL,'Incredible Places','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
	(50,73,1,'Immersive Activities','2020-12-08 18:09:51','2020-12-08 18:09:51','d7b40bf5-cfa6-4fd6-83f9-ba4022008392',NULL,NULL,NULL,'Delivering an immersive experience is exciting','<p>Immersive experiences—the use of technology, storytelling, and space to convey a message, educate, or entertain—can transport visitors to another time and/or place. Increasingly, companies are recognizing <a href=\"http://theimmersivexperience.com/2018/06/27/realizing-the-roller-coaster-wow-in-the-business-environment/\" target=\"_blank\" rel=\"noreferrer noopener\">immersive experiences</a> as an opportunity to engage with customers in a unique and powerful way. Here are six tips for approaching your first immersive experience project.</p>'),
	(51,75,1,'Packages','2020-12-08 18:17:41','2020-12-08 18:17:41','5f3094cc-121b-49fc-990d-2bc7d1aeac13',NULL,NULL,NULL,'Curated Packages','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
	(52,77,1,'Places','2020-12-08 18:17:56','2020-12-08 18:17:56','48a6e11e-adeb-49c0-8296-0aad3b50bc5f',NULL,NULL,NULL,'Incredible Places','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>'),
	(53,79,1,'Immersive Activities','2020-12-08 18:18:12','2020-12-08 18:18:12','75340ae3-2361-4da4-a825-f105c3ad3ed9',NULL,NULL,NULL,'Delivering an immersive experience is exciting','<p>Immersive experiences—the use of technology, storytelling, and space to convey a message, educate, or entertain—can transport visitors to another time and/or place. Increasingly, companies are recognizing <a href=\"http://theimmersivexperience.com/2018/06/27/realizing-the-roller-coaster-wow-in-the-business-environment/\" target=\"_blank\" rel=\"noreferrer noopener\">immersive experiences</a> as an opportunity to engage with customers in a unique and powerful way. Here are six tips for approaching your first immersive experience project.</p>'),
	(54,81,1,'Home','2020-12-08 20:07:34','2020-12-08 20:07:34','29f8246b-8871-454a-99bc-264b444e0e47',NULL,NULL,NULL,NULL,NULL),
	(55,83,1,'Home','2020-12-09 00:07:30','2020-12-09 00:07:30','49d5a949-dcd7-42d4-85fa-da8735da9324',NULL,NULL,NULL,NULL,NULL),
	(56,86,1,'Home','2020-12-09 07:28:39','2020-12-09 07:28:39','a2635ff9-3e61-4997-840e-581321ae56fd',NULL,NULL,NULL,NULL,NULL),
	(57,89,1,'Home','2020-12-09 07:38:03','2020-12-09 07:38:03','3e29b890-6830-4c09-b897-ca9e85b72d95',NULL,NULL,NULL,NULL,NULL),
	(58,92,1,'Home','2020-12-09 08:06:36','2020-12-09 08:06:36','faf7dc30-40b8-4202-9cc4-4ad50f261fb4',NULL,NULL,NULL,NULL,NULL),
	(59,94,1,'Home','2020-12-09 08:07:13','2020-12-09 08:07:13','c48368dc-0ee4-4b09-b90a-0581fbd2f1fb',NULL,NULL,NULL,NULL,NULL),
	(60,100,1,'Home','2020-12-09 08:10:35','2020-12-09 08:10:35','0f8ef27d-3e88-414d-a622-4e1e4e112ac1',NULL,NULL,NULL,NULL,NULL),
	(61,109,1,'Home','2020-12-09 18:47:32','2020-12-09 18:47:32','643a602c-5e73-4ff0-b06d-1a39b67cc9f8',NULL,NULL,NULL,NULL,NULL),
	(62,118,1,'Home','2020-12-09 19:08:12','2020-12-09 19:08:12','4c5033ea-3c31-4513-b3a5-6b14c5ca1128',NULL,NULL,NULL,NULL,NULL),
	(63,128,1,'Home','2020-12-09 19:11:12','2020-12-09 19:11:12','bccad576-1999-4c41-82e2-cfb312773380',NULL,NULL,NULL,NULL,NULL),
	(64,138,1,'Home','2020-12-09 22:32:48','2020-12-09 22:32:48','246ac68c-35ae-4744-b55d-4f2ca6ca9c1a',NULL,NULL,NULL,NULL,NULL),
	(65,148,1,'Home','2020-12-09 22:35:36','2020-12-09 22:35:36','8d8c359c-cc39-4cc0-8fe0-45436d77a4d4',NULL,NULL,NULL,NULL,NULL),
	(66,158,1,'Home','2020-12-09 22:50:38','2020-12-09 22:50:38','0f251fdf-a9e1-48d8-a454-f88415c628ef',NULL,NULL,NULL,NULL,NULL),
	(67,169,1,'Home','2020-12-09 22:56:06','2020-12-09 22:56:06','acb761ba-8ba6-4558-9fce-6f6e72a926f5',NULL,NULL,NULL,NULL,NULL),
	(68,180,1,'Home','2020-12-09 23:01:03','2020-12-09 23:01:03','d1575653-0153-40bc-8594-1cbf9e7407ab',NULL,NULL,NULL,NULL,NULL),
	(69,191,1,'Home','2020-12-09 23:18:20','2020-12-09 23:18:20','0ebe16c8-de07-4657-aeef-69324d711471',NULL,NULL,NULL,NULL,NULL),
	(70,202,1,'Home','2020-12-09 23:20:49','2020-12-09 23:20:49','3788a03e-fe66-4782-968e-3d1f287f7bbf',NULL,NULL,NULL,NULL,NULL),
	(71,213,1,'Home','2020-12-09 23:58:21','2020-12-09 23:58:21','d3edc66e-a931-448c-ada4-1dbe1a99ede3',NULL,NULL,NULL,NULL,NULL),
	(72,225,1,'Home','2020-12-10 00:00:08','2020-12-10 00:00:08','ae511be1-ba5e-4a5f-ae5e-76322f3badca',NULL,NULL,NULL,NULL,NULL),
	(73,237,1,'Home','2020-12-10 00:08:00','2020-12-10 00:08:00','7d75d64b-9167-474c-a6a5-b47f39be91d1',NULL,NULL,NULL,NULL,NULL),
	(74,249,1,'Home','2020-12-10 00:31:34','2020-12-10 00:31:34','1efdb92c-ec58-40ff-8954-6bb77c20827a',NULL,NULL,NULL,NULL,NULL),
	(75,258,1,'Home','2020-12-10 00:33:07','2020-12-10 00:33:07','75adbb12-ce07-4595-8855-927cb4496125',NULL,NULL,NULL,NULL,NULL),
	(76,267,1,'Home','2020-12-10 00:34:13','2020-12-10 00:34:13','9f53a48f-f255-4c13-856f-6711b982e226',NULL,NULL,NULL,NULL,NULL),
	(77,272,1,'Home','2020-12-10 00:34:53','2020-12-10 00:34:53','09880331-196d-45af-8214-747a52a6d6c0',NULL,NULL,NULL,NULL,NULL),
	(78,277,1,'Home','2020-12-14 23:15:24','2020-12-14 23:15:24','a36c8242-5eaa-4f06-abdf-cdc3f95f042a',NULL,NULL,NULL,NULL,NULL),
	(79,282,1,'Home','2020-12-16 06:04:29','2020-12-16 06:04:29','4e2c600c-9b6a-4904-a8fe-4fc616182974',NULL,NULL,NULL,NULL,NULL),
	(80,287,1,'Home','2020-12-16 06:05:08','2020-12-16 06:05:08','8e4bc166-4ad3-4562-9979-e59b42c6c847',NULL,NULL,NULL,NULL,NULL),
	(81,292,1,'Home','2020-12-16 06:13:57','2020-12-16 06:13:57','ea2caee5-0bf1-4fbd-b942-de145feb1496',NULL,NULL,NULL,NULL,NULL),
	(82,297,1,'Home','2020-12-16 12:18:09','2020-12-16 12:18:09','80f9c995-d3b8-4b73-a73a-90437908adad',NULL,NULL,NULL,NULL,NULL),
	(83,302,1,'Home','2020-12-16 12:19:22','2020-12-16 12:19:22','5be38d01-930c-49b1-87d3-4d3de961e20d',NULL,NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table craftidtokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `craftidtokens`;

CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `craftidtokens_userId_fk` (`userId`),
  CONSTRAINT `craftidtokens_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table deprecationerrors
# ------------------------------------------------------------

DROP TABLE IF EXISTS `deprecationerrors`;

CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` text,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `deprecationerrors_key_fingerprint_unq_idx` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table drafts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `drafts`;

CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `drafts_creatorId_fk` (`creatorId`),
  KEY `drafts_sourceId_fk` (`sourceId`),
  CONSTRAINT `drafts_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `drafts_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;

INSERT INTO `drafts` (`id`, `sourceId`, `creatorId`, `name`, `notes`, `trackChanges`, `dateLastMerged`)
VALUES
	(1,NULL,5,'First draft',NULL,0,NULL),
	(2,NULL,5,'First draft',NULL,0,NULL);

/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table elementindexsettings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `elementindexsettings`;

CREATE TABLE `elementindexsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elementindexsettings_type_unq_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `elementindexsettings` WRITE;
/*!40000 ALTER TABLE `elementindexsettings` DISABLE KEYS */;

INSERT INTO `elementindexsettings` (`id`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'craft\\elements\\Entry','{\"sources\":{\"*\":{\"tableAttributes\":{\"1\":\"section\",\"2\":\"postDate\",\"3\":\"link\",\"4\":\"type\",\"5\":\"slug\"}}}}','2020-12-07 19:29:43','2020-12-07 19:29:43','063aa066-4969-468a-8195-ab601bb38cb0');

/*!40000 ALTER TABLE `elementindexsettings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table elements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `elements`;

CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `elements_dateDeleted_idx` (`dateDeleted`),
  KEY `elements_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `elements_type_idx` (`type`),
  KEY `elements_enabled_idx` (`enabled`),
  KEY `elements_archived_dateCreated_idx` (`archived`,`dateCreated`),
  KEY `elements_archived_dateDeleted_draftId_revisionId_idx` (`archived`,`dateDeleted`,`draftId`,`revisionId`),
  KEY `elements_draftId_fk` (`draftId`),
  KEY `elements_revisionId_fk` (`revisionId`),
  CONSTRAINT `elements_draftId_fk` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `elements_revisionId_fk` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;

INSERT INTO `elements` (`id`, `draftId`, `revisionId`, `fieldLayoutId`, `type`, `enabled`, `archived`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,NULL,NULL,7,'craft\\elements\\Entry',1,0,'2020-12-07 08:31:20','2020-12-16 12:19:22',NULL,'36111991-6dd9-4928-b3e1-98b592712d9f'),
	(2,NULL,1,7,'craft\\elements\\Entry',1,0,'2020-12-07 08:31:20','2020-12-07 08:31:20',NULL,'b6294195-7b9b-45ed-a14c-99d4146eaa14'),
	(3,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2020-12-07 08:31:20','2020-12-07 20:36:27',NULL,'3ef4a8d7-4e31-4059-97b9-629872eb54a2'),
	(4,NULL,2,8,'craft\\elements\\Entry',1,0,'2020-12-07 08:31:20','2020-12-07 08:31:20',NULL,'2fface6e-0d9f-48e8-8b94-5a6d979d7dec'),
	(5,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2020-12-07 08:31:22','2020-12-07 08:31:22',NULL,'5e21aa8a-3065-427b-8267-456cdb9afe30'),
	(6,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:19:19','2020-12-07 19:19:19',NULL,'45c70bd8-b7ad-432e-81d4-4a618689d0d3'),
	(7,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:19:34','2020-12-07 19:19:34',NULL,'a9f36f12-2b71-432a-8d57-312a8575da4f'),
	(8,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:19:40','2020-12-07 19:19:40',NULL,'396c925c-c44c-4a59-922f-d17f7c0aa1ec'),
	(9,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:19:48','2020-12-09 22:59:17',NULL,'3feb6667-f6e9-43da-88b1-39dbd6ca43ee'),
	(10,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:19:53','2020-12-09 22:59:29',NULL,'177e70d8-0e55-42e8-9d77-2b41e1e3b05d'),
	(11,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:19:58','2020-12-09 22:59:40',NULL,'c8905c98-5dc3-4354-aff9-c734b946feb1'),
	(12,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:20:03','2020-12-09 22:59:51',NULL,'bca86aea-333b-4b2d-a15e-e64cb4a13615'),
	(13,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:20:08','2020-12-09 23:00:02',NULL,'14a9bc9d-2d56-4ba4-9de6-0970e3934e7b'),
	(14,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:23:16','2020-12-09 19:10:59',NULL,'62927388-7667-49d2-be4b-d712a3f57e82'),
	(15,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:23:41','2020-12-09 19:10:52',NULL,'e0191a2b-0183-4cab-a2de-65591fe1ce81'),
	(16,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:24:05','2020-12-09 19:10:45',NULL,'d8d96097-3b85-4bc2-9fb3-55b43229cb92'),
	(17,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:24:37','2020-12-09 23:20:40',NULL,'d80238c0-952c-4a7b-9942-18ba0ee5793c'),
	(18,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:25:06','2020-12-09 00:05:00',NULL,'01d0470f-95cf-4a66-a713-36401e9930f5'),
	(19,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:25:21','2020-12-09 00:05:33',NULL,'8db59a13-1186-4cb9-9e73-13eaa50d3419'),
	(20,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:25:50','2020-12-16 12:17:30',NULL,'1a6f5c5b-c3a2-4316-a370-d3dfb20ea592'),
	(21,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:26:07','2020-12-09 00:04:37',NULL,'2529d158-4ba7-4aba-9134-05d7e9892f6e'),
	(22,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2020-12-07 19:26:31','2020-12-09 00:06:15',NULL,'ea336153-1df0-4c6b-9350-897c9d86b09d'),
	(23,NULL,3,7,'craft\\elements\\Entry',1,0,'2020-12-07 19:31:37','2020-12-07 19:31:37',NULL,'c6fd6bf9-1919-4c9c-b815-66793a975a6c'),
	(24,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-07 19:56:43','2020-12-07 19:56:43',NULL,'f8928775-b91d-4ab1-9912-e52b3b5daf0a'),
	(25,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-07 19:56:43','2020-12-07 20:36:27',NULL,'78fbe03b-df0e-492f-8ca8-a439d71ffa0c'),
	(26,NULL,4,8,'craft\\elements\\Entry',1,0,'2020-12-07 19:56:43','2020-12-07 19:56:43',NULL,'1b3ea9ed-b8ed-46e0-9185-332eca8c21c5'),
	(27,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-07 19:56:43','2020-12-07 19:56:43',NULL,'abdea225-0424-4c1d-8a0b-a71d658b5ca2'),
	(28,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-07 19:56:43','2020-12-07 19:56:43',NULL,'59f65059-e075-499f-a5fe-49c4f14753e1'),
	(29,NULL,5,8,'craft\\elements\\Entry',1,0,'2020-12-07 20:14:29','2020-12-07 20:14:29',NULL,'dc071257-7157-4c2b-9166-57d31b82e6e6'),
	(30,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-07 20:14:29','2020-12-07 19:56:43',NULL,'2f031f4c-4a7f-4ec2-a5f3-82a00a0621c9'),
	(31,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-07 20:14:29','2020-12-07 20:14:29',NULL,'67b10735-77ed-4947-93ad-25b399a4757d'),
	(32,NULL,6,8,'craft\\elements\\Entry',1,0,'2020-12-07 20:36:27','2020-12-07 20:36:27',NULL,'f4dc6b87-c37c-4f22-b8b9-0b9a1752f136'),
	(33,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-07 20:36:27','2020-12-07 19:56:43',NULL,'1c9e1085-4a60-44a6-b8c6-4635419bca9a'),
	(34,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-07 20:36:27','2020-12-07 20:36:27',NULL,'e9ecc009-a22e-4510-95ca-961b4931af2a'),
	(36,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2020-12-07 22:23:41','2020-12-07 22:23:41',NULL,'9f520093-d965-4fed-bcf2-a2556e2f0855'),
	(37,NULL,7,6,'craft\\elements\\Entry',1,0,'2020-12-07 22:23:41','2020-12-07 22:23:41',NULL,'c7396c98-0ffc-4b1e-bb57-3ab6541817f3'),
	(39,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2020-12-07 22:25:36','2020-12-07 22:25:36',NULL,'5b52f1f3-99b7-4fd3-a762-7631046ff701'),
	(40,NULL,8,6,'craft\\elements\\Entry',1,0,'2020-12-07 22:25:36','2020-12-07 22:25:36',NULL,'d8963e41-245b-4ecd-bd64-8291fb60dcb8'),
	(41,NULL,9,7,'craft\\elements\\Entry',1,0,'2020-12-08 08:17:18','2020-12-08 08:17:18',NULL,'56d8aa42-38ae-43d6-bf3a-16a937e7d10a'),
	(42,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 08:19:55','2020-12-09 18:47:31','2020-12-10 00:34:13','8ad5b91e-bcde-4a37-b384-8551fa26bf23'),
	(43,NULL,10,7,'craft\\elements\\Entry',1,0,'2020-12-08 08:19:55','2020-12-08 08:19:55',NULL,'5b2276ee-b906-4e0f-a716-4ec7b1fc30bc'),
	(44,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 08:19:55','2020-12-08 08:19:55',NULL,'2f39bd36-511d-4949-8673-54167b795a12'),
	(45,NULL,11,7,'craft\\elements\\Entry',1,0,'2020-12-08 08:20:21','2020-12-08 08:20:21',NULL,'a4e5eb64-c5de-4cee-8f81-654e67bba769'),
	(46,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 08:20:21','2020-12-08 08:19:55',NULL,'04c724de-eec4-46a6-8000-ae8ed746b0e6'),
	(47,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 09:23:25','2020-12-08 09:23:25','2020-12-08 20:07:33','116f783b-7329-4bd5-aa4e-3ed8e21a475f'),
	(48,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 09:23:25','2020-12-08 09:23:25','2020-12-08 20:07:33','b27aa5c1-70f8-4eb6-b486-d7a7c803066f'),
	(49,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 09:23:25','2020-12-08 09:23:25','2020-12-08 20:07:33','0d46b32b-b41c-4a22-a357-ca7b4b305c6d'),
	(50,NULL,12,7,'craft\\elements\\Entry',1,0,'2020-12-08 09:23:25','2020-12-08 09:23:25',NULL,'b3f5b441-1b3d-4984-bfd5-6ac6b7f0f565'),
	(51,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 09:23:25','2020-12-08 09:23:25',NULL,'f3fdd6ae-7123-4523-a185-6379aef074f5'),
	(52,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 09:23:26','2020-12-08 09:23:25',NULL,'37f673c1-cbb7-456a-ab4a-a93572fef6ec'),
	(53,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 09:23:26','2020-12-08 09:23:25',NULL,'0a75741a-7308-4931-ae1f-168f65c03055'),
	(54,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 09:23:26','2020-12-08 09:23:25',NULL,'41e687cf-90fd-48ca-9dcb-ed638ea0eda2'),
	(55,1,NULL,10,'craft\\elements\\Entry',1,0,'2020-12-08 09:58:09','2020-12-08 09:58:09',NULL,'59b798ee-5881-4256-924c-bab9baa62530'),
	(57,NULL,NULL,10,'craft\\elements\\Entry',1,0,'2020-12-08 10:04:35','2020-12-08 18:18:12',NULL,'600af1ab-9570-4c8a-bafd-28fded4421e7'),
	(58,NULL,13,10,'craft\\elements\\Entry',1,0,'2020-12-08 10:04:35','2020-12-08 10:04:35',NULL,'325ca43b-4057-4dd7-a5da-fd5905a33a4a'),
	(59,2,NULL,10,'craft\\elements\\Entry',1,0,'2020-12-08 17:46:30','2020-12-08 17:46:30',NULL,'02770cea-4c3d-4e39-8d58-72ef3dcdd205'),
	(61,NULL,NULL,10,'craft\\elements\\Entry',1,0,'2020-12-08 17:52:27','2020-12-08 18:17:56',NULL,'ff2eb80c-b5ca-4231-a165-0b43e0b95331'),
	(62,NULL,14,10,'craft\\elements\\Entry',1,0,'2020-12-08 17:52:27','2020-12-08 17:52:27',NULL,'70920075-871a-41cd-a581-1e25ca1a3e1d'),
	(64,NULL,NULL,10,'craft\\elements\\Entry',1,0,'2020-12-08 17:54:04','2020-12-08 18:17:40',NULL,'be3b14cd-84e5-4999-ae1b-99768d87d669'),
	(65,NULL,15,10,'craft\\elements\\Entry',1,0,'2020-12-08 17:54:04','2020-12-08 17:54:04',NULL,'3bc49c3e-ef83-4ad7-9803-4ab585158fd8'),
	(66,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 18:08:37','2020-12-09 07:19:41',NULL,'de0391b3-d753-4126-97a3-bf070fc0f3e6'),
	(67,NULL,16,10,'craft\\elements\\Entry',1,0,'2020-12-08 18:08:37','2020-12-08 18:08:37',NULL,'08136293-f265-4a1c-ab99-3634a7876bed'),
	(68,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 18:08:38','2020-12-08 18:08:37',NULL,'a8d9cc94-5ca6-4fed-b900-fdee3a5107e6'),
	(69,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 18:09:16','2020-12-09 07:19:41',NULL,'2d5a9071-3245-409d-acf4-e711ad281763'),
	(70,NULL,17,10,'craft\\elements\\Entry',1,0,'2020-12-08 18:09:15','2020-12-08 18:09:15',NULL,'4c4dcb88-f8b4-4bc2-97c6-c9c5e013281f'),
	(71,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 18:09:16','2020-12-08 18:09:16',NULL,'3d382cea-6742-4a22-b0b1-861d0dc130ee'),
	(72,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 18:09:50','2020-12-09 07:19:41',NULL,'dfb7b258-7caa-4f06-9b13-81420023a692'),
	(73,NULL,18,10,'craft\\elements\\Entry',1,0,'2020-12-08 18:09:50','2020-12-08 18:09:50',NULL,'3b6e954f-76a8-48c7-8114-a462e766e3c7'),
	(74,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 18:09:51','2020-12-08 18:09:50',NULL,'db1791a5-5bf2-41e0-8658-890e2af1efbc'),
	(75,NULL,19,10,'craft\\elements\\Entry',1,0,'2020-12-08 18:17:40','2020-12-08 18:17:40',NULL,'6ce11095-4296-4357-9877-545f4e77e7ab'),
	(76,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 18:17:41','2020-12-08 18:08:37',NULL,'c4af117a-a012-4725-aba7-384a7649031e'),
	(77,NULL,20,10,'craft\\elements\\Entry',1,0,'2020-12-08 18:17:56','2020-12-08 18:17:56',NULL,'b5829b62-4b4f-4a0c-9b63-2a49204032df'),
	(78,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 18:17:56','2020-12-08 18:09:16',NULL,'004b0259-c5be-41d0-8dc8-8ec2afcc16e3'),
	(79,NULL,21,10,'craft\\elements\\Entry',1,0,'2020-12-08 18:18:12','2020-12-08 18:18:12',NULL,'120d66bb-36f9-4ed7-8d89-32d652c62e3e'),
	(80,NULL,NULL,3,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 18:18:12','2020-12-08 18:09:50',NULL,'3d406633-704c-4a3e-b959-2a7ca77a6f14'),
	(81,NULL,22,7,'craft\\elements\\Entry',1,0,'2020-12-08 20:07:33','2020-12-08 20:07:33',NULL,'7b526d7f-aae8-4d26-a099-65e8e770eb5d'),
	(82,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-08 20:07:34','2020-12-08 20:07:33',NULL,'73580187-5621-407a-9d7d-44bc2eeb9162'),
	(83,NULL,23,7,'craft\\elements\\Entry',1,0,'2020-12-09 00:07:29','2020-12-09 00:07:29',NULL,'724d8260-5707-47b7-a643-7e75f9b8ac28'),
	(84,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 00:07:30','2020-12-09 00:07:29',NULL,'54792566-b7a8-4fcd-b4a8-c8861afa4c6e'),
	(85,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 07:28:39','2020-12-09 07:28:39','2020-12-09 08:06:36','9802c94a-0a11-43ed-9da7-cec4b9bab70c'),
	(86,NULL,24,7,'craft\\elements\\Entry',1,0,'2020-12-09 07:28:39','2020-12-09 07:28:39',NULL,'db6503b4-b6a3-44b6-a7a7-3f3afc3846df'),
	(87,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 07:28:39','2020-12-09 07:28:39',NULL,'42e0cd08-a117-4f8f-8ffa-e8d43bb184d7'),
	(88,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 07:28:39','2020-12-09 07:28:39',NULL,'c4494abe-8806-4d31-82e9-bd178829d7a0'),
	(89,NULL,25,7,'craft\\elements\\Entry',1,0,'2020-12-09 07:38:03','2020-12-09 07:38:03',NULL,'e5d676ee-36ba-4147-847e-b72238f54b9d'),
	(90,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 07:38:03','2020-12-09 07:38:03',NULL,'1e8dd09e-be8a-4988-9de6-178f900c343c'),
	(91,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 07:38:03','2020-12-09 07:28:39',NULL,'5eaeadf3-0578-4a9c-955d-deda9937b6b2'),
	(92,NULL,26,7,'craft\\elements\\Entry',1,0,'2020-12-09 08:06:35','2020-12-09 08:06:35',NULL,'f73339b5-e83a-4689-8c82-0875bb5c6db5'),
	(93,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 08:06:36','2020-12-09 08:06:35',NULL,'0182770c-f82f-45ea-ab08-93899d3da84e'),
	(94,NULL,27,7,'craft\\elements\\Entry',1,0,'2020-12-09 08:07:13','2020-12-09 08:07:13',NULL,'806ab92e-1704-494d-82a5-d1db08f0e467'),
	(95,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 08:07:13','2020-12-09 08:06:35',NULL,'d731b2f8-f554-43fb-aa7a-8281f7c42c44'),
	(96,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 08:10:34','2020-12-09 08:10:34','2020-12-10 00:16:06','3dd94123-0f5a-441c-8987-d6936c9c8b65'),
	(97,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 08:10:34','2020-12-09 08:10:34','2020-12-10 00:16:07','e6d3c4bc-8a66-4c73-8454-c05afe540199'),
	(98,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 08:10:34','2020-12-09 08:10:34','2020-12-10 00:16:07','a8f9c4bd-15a2-4e1b-9d13-2285304de738'),
	(99,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 08:10:34','2020-12-09 08:10:34','2020-12-10 00:16:07','06adc398-a963-4e00-b74f-6d2ac3536cca'),
	(100,NULL,28,7,'craft\\elements\\Entry',1,0,'2020-12-09 08:10:34','2020-12-09 08:10:34',NULL,'779b1ab6-fecf-477a-bbfd-f493aebbbbdc'),
	(101,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 08:10:35','2020-12-09 08:06:35',NULL,'47d59d13-9f3f-49d3-8e81-e6575f23a038'),
	(102,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 08:10:35','2020-12-09 08:10:34',NULL,'3b90f235-a28e-4a82-8efb-c895cc2887c9'),
	(103,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 08:10:35','2020-12-09 08:10:34',NULL,'212e8af3-7359-4913-82f0-7e89cfe4e02b'),
	(104,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 08:10:35','2020-12-09 08:10:34',NULL,'709477c3-7fdc-43ba-963d-112bd17a42a7'),
	(105,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 08:10:35','2020-12-09 08:10:34',NULL,'a27bfb99-6587-4fb7-acfc-ece4b0ed6dea'),
	(106,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 18:47:32','2020-12-09 18:47:32','2020-12-10 00:34:13','ea68649b-79a2-4f76-8047-7918be412fa3'),
	(107,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 18:47:32','2020-12-09 18:47:32','2020-12-10 00:34:13','6f25e2b0-bb0b-4b35-8dfe-8efdb82da184'),
	(108,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 18:47:32','2020-12-09 18:47:32','2020-12-10 00:34:13','66e565e2-abfa-4e43-b708-f702f2930134'),
	(109,NULL,29,7,'craft\\elements\\Entry',1,0,'2020-12-09 18:47:31','2020-12-09 18:47:31',NULL,'05b72d51-a1bd-4cc1-8e82-f91c36f1e54c'),
	(110,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 18:47:32','2020-12-09 18:47:31',NULL,'b2cc207c-be8c-41a3-be27-8ea482f554d7'),
	(111,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 18:47:32','2020-12-09 18:47:32',NULL,'7cafcf69-04ff-47b3-bdd3-18afe198e771'),
	(112,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 18:47:32','2020-12-09 18:47:32',NULL,'709dc905-65f8-4407-b3d6-6fbad0a08f48'),
	(113,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 18:47:32','2020-12-09 18:47:32',NULL,'a1f5c650-1081-4c72-a2a0-32aa80c8dbec'),
	(114,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 18:47:32','2020-12-09 08:10:34',NULL,'ff15b162-795f-4927-8497-8c5ddb948445'),
	(115,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 18:47:32','2020-12-09 08:10:34',NULL,'629444e4-57a5-499c-b3ce-7d19b693557a'),
	(116,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 18:47:32','2020-12-09 08:10:34',NULL,'85db0431-cea3-44bb-9810-a5cfb1d39b33'),
	(117,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 18:47:32','2020-12-09 08:10:34',NULL,'2414eba3-9516-42c8-97c5-93a7e5f14ddc'),
	(118,NULL,30,7,'craft\\elements\\Entry',1,0,'2020-12-09 19:08:12','2020-12-09 19:08:12',NULL,'6e73140d-8066-44e2-abfd-9b452eb51a42'),
	(119,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:08:12','2020-12-09 18:47:31',NULL,'9a805938-1345-4fe2-bb72-37b40a626260'),
	(120,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:08:12','2020-12-09 18:47:32',NULL,'5d724d40-0a65-4438-ae22-780b840a29bd'),
	(121,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:08:12','2020-12-09 18:47:32',NULL,'cc90fd54-b572-4bcb-b2a9-8316514a0d03'),
	(122,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:08:13','2020-12-09 18:47:32',NULL,'0b8ee054-8b44-4a6a-a77b-12666bd08b64'),
	(123,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:08:13','2020-12-09 08:10:34',NULL,'023164c6-d159-47a3-868e-0ec0c103eac4'),
	(124,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:08:13','2020-12-09 08:10:34',NULL,'74ae8275-3aca-4dc1-9d72-8adc3e34c533'),
	(125,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:08:13','2020-12-09 08:10:34',NULL,'d384c403-95e5-4666-9bc6-7cee993efa86'),
	(126,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:08:13','2020-12-09 08:10:34',NULL,'ee8d79d8-103f-496f-ae81-2d6ca89afbac'),
	(127,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:11:11','2020-12-14 23:15:24',NULL,'7272e634-7c5e-48af-a050-5f32dbd286d2'),
	(128,NULL,31,7,'craft\\elements\\Entry',1,0,'2020-12-09 19:11:11','2020-12-09 19:11:11',NULL,'429bad46-49f2-4a01-af5d-1edeb9489b99'),
	(129,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:11:12','2020-12-09 19:11:11',NULL,'db1832ec-e3f7-4cac-8e07-3fd628ce70fe'),
	(130,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:11:12','2020-12-09 18:47:31',NULL,'5660e1e7-8081-46c3-9a3f-258f45abd8a1'),
	(131,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:11:12','2020-12-09 18:47:32',NULL,'a55c7da7-2200-4964-970f-5983e3a9d7bf'),
	(132,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:11:12','2020-12-09 18:47:32',NULL,'bb0e6cc5-6d54-4d23-889e-643815943c34'),
	(133,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:11:12','2020-12-09 18:47:32',NULL,'1ef3fe69-6a20-4100-b511-db56ce2f9c57'),
	(134,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:11:12','2020-12-09 08:10:34',NULL,'b2d36847-3468-4259-8f78-334737e2eed8'),
	(135,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:11:12','2020-12-09 08:10:34',NULL,'0022271e-c95b-4a88-b2ec-35aa8b8b4a2b'),
	(136,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:11:12','2020-12-09 08:10:34',NULL,'1201c99d-3a55-443e-9725-6133a18f078e'),
	(137,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 19:11:12','2020-12-09 08:10:34',NULL,'e552a641-bf24-4028-821c-734a5ac7c700'),
	(138,NULL,32,7,'craft\\elements\\Entry',1,0,'2020-12-09 22:32:48','2020-12-09 22:32:48',NULL,'9ef567db-c137-4896-ac70-d080fcff0006'),
	(139,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:32:49','2020-12-09 19:11:11',NULL,'1d327253-78e6-497b-9e81-730cd94bf8fc'),
	(140,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:32:49','2020-12-09 18:47:31',NULL,'a9f4d91c-5e80-4938-88ed-54f71293b25e'),
	(141,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:32:49','2020-12-09 18:47:32',NULL,'4a3eff74-d6c6-4507-b5c4-6efd9202e96c'),
	(142,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:32:49','2020-12-09 18:47:32',NULL,'0bac2c24-cb00-4972-9ca5-53d7803355b6'),
	(143,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:32:49','2020-12-09 18:47:32',NULL,'c9c53a29-af3f-4b0f-8b5a-d39b85c6ab20'),
	(144,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:32:49','2020-12-09 08:10:34',NULL,'3feefaca-4bf9-4d44-a9ff-faf19b200e7d'),
	(145,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:32:49','2020-12-09 08:10:34',NULL,'f6b9d213-4424-445d-a1e0-2ca2b3468d56'),
	(146,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:32:49','2020-12-09 08:10:34',NULL,'5772fede-158d-4ef0-bfd8-79e9c9900983'),
	(147,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:32:49','2020-12-09 08:10:34',NULL,'fc53487e-a9c0-4e0d-ae29-bd52c4de360c'),
	(148,NULL,33,7,'craft\\elements\\Entry',1,0,'2020-12-09 22:35:36','2020-12-09 22:35:36',NULL,'60f3c58a-ee3a-4318-b13c-f8a55d724283'),
	(149,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:35:36','2020-12-09 22:35:36',NULL,'1c9b4209-6c5f-42f8-a470-3e4350574218'),
	(150,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:35:36','2020-12-09 18:47:31',NULL,'810cde93-a6f8-4d1d-b989-8481c39f2d8d'),
	(151,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:35:36','2020-12-09 18:47:32',NULL,'b20b58ac-0954-45d5-9ac6-0756a6de65cb'),
	(152,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:35:36','2020-12-09 18:47:32',NULL,'d87da23b-c65c-4228-8ea9-1b3aa9932550'),
	(153,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:35:36','2020-12-09 18:47:32',NULL,'1ac0f960-d6b2-476e-8165-a8be9be5d57f'),
	(154,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:35:37','2020-12-09 08:10:34',NULL,'afefb366-b6d6-497f-a658-ebdc7b0c7c09'),
	(155,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:35:37','2020-12-09 08:10:34',NULL,'e828d9ec-e055-4635-b0b4-e829a330e319'),
	(156,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:35:37','2020-12-09 08:10:34',NULL,'16a06bcc-9ae6-4366-9b04-b3911d127451'),
	(157,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:35:37','2020-12-09 08:10:34',NULL,'77cb34ee-bc53-48e6-93b7-227922f6b78d'),
	(158,NULL,34,7,'craft\\elements\\Entry',1,0,'2020-12-09 22:50:37','2020-12-09 22:50:37',NULL,'f907bcfd-a516-4280-a5cc-e259dde6fcaa'),
	(159,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:50:38','2020-12-09 22:35:36',NULL,'e6bcd885-177a-46dc-b4cf-a21013bd0755'),
	(160,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:50:38','2020-12-09 18:47:31',NULL,'81aba40e-5568-4a21-9673-ed93b753c055'),
	(161,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:50:38','2020-12-09 18:47:32',NULL,'5b47e453-0e9e-4273-88a2-0cb57dd51ce4'),
	(162,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:50:38','2020-12-09 18:47:32',NULL,'42f696df-5156-49d1-a0ac-06e3d88e4e2c'),
	(163,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:50:38','2020-12-09 18:47:32',NULL,'defd9b97-d0b7-406c-9b4e-5b3578374e7e'),
	(164,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:50:38','2020-12-09 08:10:34',NULL,'46fd38cf-9179-46b0-9eea-e97f330f2b2b'),
	(165,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:50:38','2020-12-09 08:10:34',NULL,'00196748-dbba-4d07-b6f9-c2922a86c662'),
	(166,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:50:38','2020-12-09 08:10:34',NULL,'04650ac7-4477-4839-a25d-5d16675b014d'),
	(167,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:50:38','2020-12-09 08:10:34',NULL,'9ee98b57-82de-4bd6-a2f1-b2cbd28dd841'),
	(168,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:56:06','2020-12-09 23:18:20',NULL,'6d49a5e2-9d7e-4d3b-be4d-240ef521a042'),
	(169,NULL,35,7,'craft\\elements\\Entry',1,0,'2020-12-09 22:56:06','2020-12-09 22:56:06',NULL,'672f005a-bc20-463c-8965-d078ac67b45d'),
	(170,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:56:06','2020-12-09 22:35:36',NULL,'efd79cf9-44d2-4d3e-90ca-2a2be9d41bf8'),
	(171,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:56:06','2020-12-09 22:56:06',NULL,'670c331f-f87b-4bb8-9986-669dabda1a33'),
	(172,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:56:06','2020-12-09 18:47:31',NULL,'bb61d6f3-4c4d-4c16-a270-8b5b0ec0c3a1'),
	(173,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:56:06','2020-12-09 18:47:32',NULL,'3b57a7b7-57ee-40f5-913f-78038eea79b2'),
	(174,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:56:06','2020-12-09 18:47:32',NULL,'04b4e732-5757-44ef-897d-1195b725dcb3'),
	(175,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:56:06','2020-12-09 18:47:32',NULL,'106f4eab-dd42-4c37-9e00-993f0f9ab571'),
	(176,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:56:06','2020-12-09 08:10:34',NULL,'ae147b44-9c3c-4e17-b463-1661df8c0130'),
	(177,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:56:06','2020-12-09 08:10:34',NULL,'c5c67c84-5d6c-49dd-9e8e-d1389ba04d9b'),
	(178,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:56:06','2020-12-09 08:10:34',NULL,'4e01875f-8423-47ed-8f9d-390b5d89cc8d'),
	(179,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 22:56:06','2020-12-09 08:10:34',NULL,'43161f6a-48ac-4814-861b-a0b12c8e1e88'),
	(180,NULL,36,7,'craft\\elements\\Entry',1,0,'2020-12-09 23:01:03','2020-12-09 23:01:03',NULL,'b2e4d2bf-17b2-40e5-a849-5cba5e7ae777'),
	(181,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:01:03','2020-12-09 22:35:36',NULL,'fbd67d87-8f21-4f86-a9ee-682556a3dd1a'),
	(182,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:01:03','2020-12-09 23:01:03',NULL,'3308a5df-b194-41b6-8e2b-19ee09bcc16f'),
	(183,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:01:03','2020-12-09 18:47:31',NULL,'0d3b83a0-db77-47fc-9a98-2e252684e69e'),
	(184,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:01:03','2020-12-09 18:47:32',NULL,'7e2f1338-121b-4623-8277-fc1eb589271e'),
	(185,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:01:03','2020-12-09 18:47:32',NULL,'8f1d4332-ef81-4505-a936-2aef1582b06d'),
	(186,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:01:03','2020-12-09 18:47:32',NULL,'c72dce33-e4fc-422b-981f-5bd6eb70d540'),
	(187,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:01:03','2020-12-09 08:10:34',NULL,'07bba9e0-0ba7-4d53-ba7e-c5bd06983d61'),
	(188,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:01:03','2020-12-09 08:10:34',NULL,'6397b5ca-ec14-40b1-8cd3-89639fff7ae9'),
	(189,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:01:03','2020-12-09 08:10:34',NULL,'989523b1-b759-4896-a795-6af9304e960d'),
	(190,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:01:03','2020-12-09 08:10:34',NULL,'a3e84cae-33d6-4025-a398-73c8bd8784fa'),
	(191,NULL,37,7,'craft\\elements\\Entry',1,0,'2020-12-09 23:18:20','2020-12-09 23:18:20',NULL,'586020e8-c387-432b-b096-cdb8f6c8ccfe'),
	(192,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:18:20','2020-12-09 22:35:36',NULL,'16a57584-1678-4064-b471-a4ee15f22ec8'),
	(193,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:18:20','2020-12-09 23:18:20',NULL,'c9648ad8-82a5-4051-90f0-8ad64b66a5c9'),
	(194,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:18:20','2020-12-09 18:47:31',NULL,'73c5201d-3116-48b1-a3f6-4a79c88e88b7'),
	(195,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:18:20','2020-12-09 18:47:32',NULL,'129af39c-77de-4643-9a2a-bad26fcc776f'),
	(196,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:18:20','2020-12-09 18:47:32',NULL,'15b58e02-a37c-4552-a83f-cea2cdbc946d'),
	(197,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:18:21','2020-12-09 18:47:32',NULL,'40b052e4-0afe-4c6b-bf3d-9b9e6b0b1470'),
	(198,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:18:21','2020-12-09 08:10:34',NULL,'3879ff4b-e367-4501-88fa-9d8bd387981a'),
	(199,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:18:21','2020-12-09 08:10:34',NULL,'4818b660-35c6-4fd1-9c27-e2565fb77636'),
	(200,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:18:21','2020-12-09 08:10:34',NULL,'24fd1972-ccb3-46dc-b50c-6adaa90ce316'),
	(201,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:18:21','2020-12-09 08:10:34',NULL,'eb28b485-7b1e-40df-a731-ecd99ccaac68'),
	(202,NULL,38,7,'craft\\elements\\Entry',1,0,'2020-12-09 23:20:49','2020-12-09 23:20:49',NULL,'3447b775-9e1c-4e24-bad4-110b5075d2eb'),
	(203,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:20:49','2020-12-09 22:35:36',NULL,'06172d3b-15cd-4f7d-9983-2d7681c30d7b'),
	(204,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:20:49','2020-12-09 23:18:20',NULL,'7df427b4-ba28-4aab-845b-9f2c262116fa'),
	(205,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:20:49','2020-12-09 18:47:31',NULL,'2bc80ecd-63d1-4c5d-a15c-2b81f6dff224'),
	(206,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:20:49','2020-12-09 18:47:32',NULL,'78755095-9c3a-40bf-8ec0-01aae54a31b1'),
	(207,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:20:49','2020-12-09 18:47:32',NULL,'f46f5c5a-b923-4e10-8db1-e18faaac2320'),
	(208,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:20:49','2020-12-09 18:47:32',NULL,'89f48d26-d6ac-435a-9a29-46fafbe2731f'),
	(209,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:20:49','2020-12-09 08:10:34',NULL,'822c37b4-5808-40c2-aed0-23419d133b4e'),
	(210,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:20:49','2020-12-09 08:10:34',NULL,'945b9add-e66d-4167-b6c3-5b910b1f27d2'),
	(211,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:20:49','2020-12-09 08:10:34',NULL,'27057f55-63e6-4d5c-8f9b-3e456ac76603'),
	(212,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:20:49','2020-12-09 08:10:34',NULL,'1276f11a-5acf-4841-b836-27a823de9ec8'),
	(213,NULL,39,7,'craft\\elements\\Entry',1,0,'2020-12-09 23:58:20','2020-12-09 23:58:20',NULL,'76802e04-ce65-40ad-8a6f-6079f2f39815'),
	(214,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:58:21','2020-12-09 22:35:36',NULL,'e249b211-98c5-421e-97fc-3c47d0509887'),
	(215,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:58:21','2020-12-09 23:18:20',NULL,'55c35e3f-ecf5-42c0-a925-a8e2368f059c'),
	(216,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:58:21','2020-12-09 18:47:31',NULL,'57033fb3-feb7-4e84-ac21-01c967b2d122'),
	(217,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:58:21','2020-12-09 18:47:32',NULL,'ff1bc2cf-5e31-42ba-98d3-03290f425d2f'),
	(218,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:58:21','2020-12-09 18:47:32',NULL,'5183c162-6e6e-4555-812a-bfe4da4d3e78'),
	(219,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:58:21','2020-12-09 18:47:32',NULL,'adcaaa8f-8b97-421e-bcf2-d33f90d8908e'),
	(220,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:58:21','2020-12-09 08:10:34',NULL,'59f78b44-c68a-458c-9794-db1cd625c179'),
	(221,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:58:21','2020-12-09 08:10:34',NULL,'1778a58d-a108-4bb5-874c-20a8ef14e446'),
	(222,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:58:21','2020-12-09 08:10:34',NULL,'d792f43d-2392-474c-8997-e7f2f4279359'),
	(223,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-09 23:58:21','2020-12-09 08:10:34',NULL,'87ea779c-a54f-4cc4-9986-2b595d47822b'),
	(224,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:00:08','2020-12-16 12:18:08',NULL,'256d0bee-fb92-4e60-b820-3cf72adbd0d1'),
	(225,NULL,40,7,'craft\\elements\\Entry',1,0,'2020-12-10 00:00:08','2020-12-10 00:00:08',NULL,'04f47251-a796-4eaa-92e6-96d0de8d86ec'),
	(226,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:00:08','2020-12-09 22:35:36',NULL,'256e4326-2666-4740-a4bb-fb0bc0542cea'),
	(227,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:00:08','2020-12-09 23:18:20',NULL,'51448687-9853-4228-8282-ff88e22fb984'),
	(228,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:00:08','2020-12-10 00:00:08',NULL,'f26e2568-85f5-442f-891a-9f7b2898b42d'),
	(229,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:00:08','2020-12-09 18:47:31',NULL,'fdd1bdcc-8140-43f8-8e70-9a7f3fd42246'),
	(230,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:00:08','2020-12-09 18:47:32',NULL,'a71258f9-b584-4a15-81c8-a03f78243495'),
	(231,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:00:08','2020-12-09 18:47:32',NULL,'69e971ba-0626-449e-94d8-754904760068'),
	(232,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:00:08','2020-12-09 18:47:32',NULL,'8221dccb-8961-4b57-aa10-0bb888ae4b36'),
	(233,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:00:08','2020-12-09 08:10:34',NULL,'0beecf67-6cb4-42d6-980d-158cd2ab9174'),
	(234,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:00:08','2020-12-09 08:10:34',NULL,'502c75e3-b332-424c-92c6-2aeae4ecf581'),
	(235,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:00:08','2020-12-09 08:10:34',NULL,'ecedb00c-0745-4c7c-9934-c7533393cbe9'),
	(236,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:00:09','2020-12-09 08:10:34',NULL,'ea7bfdb2-08c3-45c9-8c9d-18e83712aafc'),
	(237,NULL,41,7,'craft\\elements\\Entry',1,0,'2020-12-10 00:08:00','2020-12-10 00:08:00',NULL,'33aaf0d3-c2b7-410d-9245-9ba5223cc44b'),
	(238,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:08:00','2020-12-09 22:35:36',NULL,'632c5b03-dd39-4145-8f5e-2990a819174c'),
	(239,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:08:00','2020-12-09 23:18:20',NULL,'69e184e5-8fa6-4ea6-8fbd-e036ae101375'),
	(240,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:08:00','2020-12-10 00:08:00',NULL,'53c3eabd-b27e-4d9b-a48d-48f502e34bb8'),
	(241,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:08:00','2020-12-09 18:47:31',NULL,'479bf5c6-18ce-4a17-8bdc-f1b1a8a642ad'),
	(242,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:08:00','2020-12-09 18:47:32',NULL,'752c6712-d690-4f18-965b-a7e4cbb3b6c4'),
	(243,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:08:00','2020-12-09 18:47:32',NULL,'2b410b14-d57b-4c17-9695-02e340037c2f'),
	(244,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:08:00','2020-12-09 18:47:32',NULL,'1dde35dd-abeb-4424-9c7e-231389061dbd'),
	(245,NULL,NULL,11,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:08:00','2020-12-09 08:10:34',NULL,'f3289d3c-7cad-48bf-bc56-9ddb687287c2'),
	(246,NULL,NULL,12,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:08:00','2020-12-09 08:10:34',NULL,'66813324-87fb-44ca-a7a0-3a6e9369bf34'),
	(247,NULL,NULL,13,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:08:00','2020-12-09 08:10:34',NULL,'ea827189-f5bb-4483-a0bb-3672daf3cce9'),
	(248,NULL,NULL,14,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:08:01','2020-12-09 08:10:34',NULL,'03e7766e-1624-433f-8d94-b93104f94363'),
	(249,NULL,42,7,'craft\\elements\\Entry',1,0,'2020-12-10 00:31:34','2020-12-10 00:31:34',NULL,'fc42a6ac-1b17-4e53-9a38-56334cac1b09'),
	(250,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:31:34','2020-12-09 22:35:36',NULL,'bddb3f6d-4561-43e9-96d7-e7ddf5651f7b'),
	(251,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:31:34','2020-12-09 23:18:20',NULL,'9b7c24b6-f4b5-4f0c-9b3c-fe27d99c0dbc'),
	(252,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:31:34','2020-12-10 00:08:00',NULL,'0317106f-2f38-4575-990e-d9a9f53405db'),
	(253,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:31:34','2020-12-09 18:47:31',NULL,'01dd5bc4-1dc8-46c6-a8c5-888954545ca8'),
	(254,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:31:35','2020-12-09 18:47:32',NULL,'67cca7cc-dd6b-4266-ac31-b4254a5911f9'),
	(255,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:31:35','2020-12-09 18:47:32',NULL,'a142027f-578f-4238-a067-f67291cb72c1'),
	(256,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:31:35','2020-12-09 18:47:32',NULL,'b52d0b3a-8a92-4fe0-be0d-d5c3a4779c91'),
	(257,NULL,NULL,18,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:33:07','2020-12-16 06:05:08',NULL,'049641b8-b391-4616-a70e-694228607aa1'),
	(258,NULL,43,7,'craft\\elements\\Entry',1,0,'2020-12-10 00:33:07','2020-12-10 00:33:07',NULL,'6bd40ad3-242e-4c92-a581-67955a405a3d'),
	(259,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:33:07','2020-12-09 22:35:36',NULL,'43e4ac41-ab1e-47cc-8f71-f48a55287a5c'),
	(260,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:33:07','2020-12-09 23:18:20',NULL,'0fb38528-3f2f-419b-a1b7-93462642de22'),
	(261,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:33:07','2020-12-10 00:08:00',NULL,'7b7d66ba-a93e-4994-b864-f69a84a13f4a'),
	(262,NULL,NULL,18,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:33:07','2020-12-10 00:33:07',NULL,'f8f53d86-45f4-4c1f-aac4-ddc79f15542d'),
	(263,NULL,NULL,9,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:33:07','2020-12-09 18:47:31',NULL,'fcfaf789-86e0-4ee4-a3f2-1c3263906d0e'),
	(264,NULL,NULL,2,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:33:07','2020-12-09 18:47:32',NULL,'a95e8996-637d-46e8-9bab-917087b492b7'),
	(265,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:33:07','2020-12-09 18:47:32',NULL,'088e53cd-c5df-4e10-a75c-40a7b9948266'),
	(266,NULL,NULL,5,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:33:07','2020-12-09 18:47:32',NULL,'88dfed67-c883-42c4-a80f-9e486dfb1a2e'),
	(267,NULL,44,7,'craft\\elements\\Entry',1,0,'2020-12-10 00:34:13','2020-12-10 00:34:13',NULL,'d096f4cf-3517-4af0-aa0a-660f8963f72f'),
	(268,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:34:13','2020-12-09 22:35:36',NULL,'78f10a09-e03b-448d-9599-fde10009681c'),
	(269,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:34:13','2020-12-09 23:18:20',NULL,'5370db40-effd-464e-be7d-104ce0142b75'),
	(270,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:34:13','2020-12-10 00:08:00',NULL,'2724183f-fd60-46d2-80eb-0fe4e1133f98'),
	(271,NULL,NULL,18,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:34:13','2020-12-10 00:33:07',NULL,'2d5e7d92-102b-454d-838a-7d2681687e18'),
	(272,NULL,45,7,'craft\\elements\\Entry',1,0,'2020-12-10 00:34:53','2020-12-10 00:34:53',NULL,'9f70c227-b0e1-41e1-a899-6146e9f52139'),
	(273,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:34:53','2020-12-09 22:35:36',NULL,'263b4c1f-7238-45d3-a532-b986f4a5adbf'),
	(274,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:34:53','2020-12-09 23:18:20',NULL,'a02f957d-8cf9-44a0-a72d-d33163c3ecaa'),
	(275,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:34:54','2020-12-10 00:08:00',NULL,'c13d3bfd-f85e-43b1-b888-1680d3ccf417'),
	(276,NULL,NULL,18,'craft\\elements\\MatrixBlock',1,0,'2020-12-10 00:34:54','2020-12-10 00:33:07',NULL,'73627a0f-6185-478f-9f03-002855d30a4e'),
	(277,NULL,46,7,'craft\\elements\\Entry',1,0,'2020-12-14 23:15:24','2020-12-14 23:15:24',NULL,'c3d345c0-950b-4bc2-b2c4-42198e01090d'),
	(278,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-14 23:15:24','2020-12-14 23:15:24',NULL,'7d451783-9389-4089-b35c-9be6f052e8ec'),
	(279,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-14 23:15:24','2020-12-09 23:18:20',NULL,'1e1682e9-e2d5-4c21-a4f8-48106fa74b61'),
	(280,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-14 23:15:24','2020-12-10 00:08:00',NULL,'bcf6a7a5-d5b9-492e-b899-1b1de5fe08e1'),
	(281,NULL,NULL,18,'craft\\elements\\MatrixBlock',1,0,'2020-12-14 23:15:24','2020-12-14 23:15:24',NULL,'a98b6679-4426-40b8-8d50-c692f9db32bd'),
	(282,NULL,47,7,'craft\\elements\\Entry',1,0,'2020-12-16 06:04:28','2020-12-16 06:04:28',NULL,'ae7fccbd-54fc-4bf1-90e5-6354bf9738ec'),
	(283,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 06:04:29','2020-12-14 23:15:24',NULL,'8abe5c5f-91c4-4658-886e-bd9e6c1860a0'),
	(284,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 06:04:29','2020-12-09 23:18:20',NULL,'3997576d-2e92-4bff-b5bd-c4c99db4bad6'),
	(285,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 06:04:29','2020-12-10 00:08:00',NULL,'bb24d631-5710-483f-b1d5-6acc67a88258'),
	(286,NULL,NULL,18,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 06:04:29','2020-12-16 06:04:29',NULL,'aaf5c3aa-ae04-4dd2-86d9-6fdc70aacefb'),
	(287,NULL,48,7,'craft\\elements\\Entry',1,0,'2020-12-16 06:05:08','2020-12-16 06:05:08',NULL,'32fd9e59-005b-45d6-8729-625c1fa43db0'),
	(288,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 06:05:08','2020-12-14 23:15:24',NULL,'d3ecebff-7107-4f67-a4fd-e18e448dbff4'),
	(289,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 06:05:09','2020-12-09 23:18:20',NULL,'940f0dc6-cbb7-4f1c-813e-9b9909d39828'),
	(290,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 06:05:09','2020-12-10 00:08:00',NULL,'61c6b97f-8b32-4a60-8bd2-59e7ffbaf79d'),
	(291,NULL,NULL,18,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 06:05:09','2020-12-16 06:05:08',NULL,'74508958-9189-4105-ae28-d7b9827c7b79'),
	(292,NULL,49,7,'craft\\elements\\Entry',1,0,'2020-12-16 06:13:57','2020-12-16 06:13:57',NULL,'9360f4dc-ee4f-409c-9df9-ef2870e54e38'),
	(293,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 06:13:57','2020-12-14 23:15:24',NULL,'bf065b02-83b0-470f-95dd-5c72244f765a'),
	(294,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 06:13:58','2020-12-09 23:18:20',NULL,'86458ca1-7fbe-4278-b47b-5e1f2d5c75cd'),
	(295,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 06:13:58','2020-12-10 00:08:00',NULL,'d2a0f604-c6c2-4e6d-8ad6-11ebfef02aa7'),
	(296,NULL,NULL,18,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 06:13:58','2020-12-16 06:05:08',NULL,'b263d7d2-f9f9-4244-bbc2-f0f3a213c795'),
	(297,NULL,50,7,'craft\\elements\\Entry',1,0,'2020-12-16 12:18:08','2020-12-16 12:18:08',NULL,'d7aefba4-2847-448f-a6e7-4da798cea93a'),
	(298,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 12:18:09','2020-12-14 23:15:24',NULL,'e3d22368-2d6f-4028-add1-3d658607664e'),
	(299,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 12:18:09','2020-12-09 23:18:20',NULL,'e6d1453f-3f88-4a44-b30f-5a9104806d26'),
	(300,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 12:18:09','2020-12-16 12:18:08',NULL,'9f6a0631-46ef-4fa4-94c3-d5c9963bc939'),
	(301,NULL,NULL,18,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 12:18:09','2020-12-16 06:05:08',NULL,'14c07608-a837-4f97-b2e9-f70e03834029'),
	(302,NULL,51,7,'craft\\elements\\Entry',1,0,'2020-12-16 12:19:22','2020-12-16 12:19:22',NULL,'bc0405f0-fd02-4295-b067-83199d22604f'),
	(303,NULL,NULL,15,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 12:19:22','2020-12-14 23:15:24',NULL,'4cec02d2-5214-4c0f-834d-884997d25605'),
	(304,NULL,NULL,16,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 12:19:22','2020-12-09 23:18:20',NULL,'a95a89aa-11b0-4274-93ee-3d40c9b636e6'),
	(305,NULL,NULL,17,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 12:19:22','2020-12-16 12:18:08',NULL,'25b6919e-4f21-49a9-8cfb-6fb3a6598643'),
	(306,NULL,NULL,18,'craft\\elements\\MatrixBlock',1,0,'2020-12-16 12:19:23','2020-12-16 06:05:08',NULL,'f3480c3a-6a79-4bc4-90e0-bef4ecfb27f3');

/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table elements_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `elements_sites`;

CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `elements_sites_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `elements_sites_siteId_idx` (`siteId`),
  KEY `elements_sites_slug_siteId_idx` (`slug`,`siteId`),
  KEY `elements_sites_enabled_idx` (`enabled`),
  KEY `elements_sites_uri_siteId_idx` (`uri`,`siteId`),
  CONSTRAINT `elements_sites_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `elements_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;

INSERT INTO `elements_sites` (`id`, `elementId`, `siteId`, `slug`, `uri`, `enabled`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,1,'home','__home__',1,'2020-12-07 08:31:20','2020-12-07 08:31:20','b7828c32-8d80-4d96-965b-b14aa4f2107c'),
	(2,2,1,'home','__home__',1,'2020-12-07 08:31:20','2020-12-07 08:31:20','d31f7e2f-3dde-4d64-bc66-91576563df15'),
	(3,3,1,'about','about',1,'2020-12-07 08:31:20','2020-12-07 08:31:20','1a00b586-467d-4559-8063-fd2e035ec04d'),
	(4,4,1,'about','about',1,'2020-12-07 08:31:20','2020-12-07 08:31:20','a7afbeb5-ece6-499d-8fa2-b930b86b2d93'),
	(5,5,1,NULL,NULL,1,'2020-12-07 08:31:22','2020-12-07 08:31:22','b7f5357b-7d00-4863-88f0-99e294cb8da2'),
	(6,6,1,NULL,NULL,1,'2020-12-07 19:19:19','2020-12-07 19:19:19','842c8a26-da48-41d1-8798-f7666f6b217d'),
	(7,7,1,NULL,NULL,1,'2020-12-07 19:19:34','2020-12-07 19:19:34','5e5c1ea0-6308-401d-9e97-96583d823d53'),
	(8,8,1,NULL,NULL,1,'2020-12-07 19:19:40','2020-12-07 19:19:40','7cf51887-3600-4648-adfd-f5188618ee78'),
	(9,9,1,NULL,NULL,1,'2020-12-07 19:19:48','2020-12-07 19:19:48','ff611e82-3920-49ac-87b8-3236bc2c70f6'),
	(10,10,1,NULL,NULL,1,'2020-12-07 19:19:53','2020-12-07 19:19:53','4b3fa3f4-62d4-48cf-bf7e-03633f23ffc7'),
	(11,11,1,NULL,NULL,1,'2020-12-07 19:19:58','2020-12-07 19:19:58','8278369a-1c33-44cf-8a01-82cb3917efad'),
	(12,12,1,NULL,NULL,1,'2020-12-07 19:20:03','2020-12-07 19:20:03','c1f13abf-d2a9-4dd2-b1ec-998963700455'),
	(13,13,1,NULL,NULL,1,'2020-12-07 19:20:08','2020-12-07 19:20:08','d818e2dc-3384-4fc2-ab4b-c6361d7b54e4'),
	(14,14,1,NULL,NULL,1,'2020-12-07 19:23:16','2020-12-07 19:23:16','f2529889-7bc3-46e6-8f1b-1d24393484a7'),
	(15,15,1,NULL,NULL,1,'2020-12-07 19:23:41','2020-12-07 19:23:41','8e7ec15d-8ffd-4e62-b84d-dc59c9b2d738'),
	(16,16,1,NULL,NULL,1,'2020-12-07 19:24:05','2020-12-07 19:24:05','ef1fb7f8-cc63-44e0-a0a8-f4f165051cbe'),
	(17,17,1,NULL,NULL,1,'2020-12-07 19:24:37','2020-12-07 19:24:37','e6127279-71f1-44ef-82de-0fe626fa1432'),
	(18,18,1,NULL,NULL,1,'2020-12-07 19:25:06','2020-12-07 19:25:06','5fe2d263-7286-4935-9ca9-b2719f5d6d2f'),
	(19,19,1,NULL,NULL,1,'2020-12-07 19:25:21','2020-12-07 19:25:21','a03df14e-139c-46c3-a0b7-af04947aad0b'),
	(20,20,1,NULL,NULL,1,'2020-12-07 19:25:50','2020-12-07 19:25:50','fc7cc104-221e-470f-a52d-3a907fc1a6e4'),
	(21,21,1,NULL,NULL,1,'2020-12-07 19:26:07','2020-12-07 19:26:07','75199724-99a7-4939-9e13-65089a198043'),
	(22,22,1,NULL,NULL,1,'2020-12-07 19:26:31','2020-12-07 19:26:31','c9a9fe11-7c20-4499-97c3-73bd887a7066'),
	(23,23,1,'home','__home__',1,'2020-12-07 19:31:38','2020-12-07 19:31:38','b09b576d-6a1a-4d2d-83a8-fbf7cde5e327'),
	(24,24,1,NULL,NULL,1,'2020-12-07 19:56:43','2020-12-07 19:56:43','4b0a6e3e-d69d-4913-9f74-3e711051ea47'),
	(25,25,1,NULL,NULL,1,'2020-12-07 19:56:43','2020-12-07 19:56:43','444858cb-6e43-4b53-bfa5-0298612a09c1'),
	(26,26,1,'about','about',1,'2020-12-07 19:56:43','2020-12-07 19:56:43','64c41221-af8f-4ab2-9808-9e764b4754f4'),
	(27,27,1,NULL,NULL,1,'2020-12-07 19:56:43','2020-12-07 19:56:43','40f818bc-b89b-4679-9ece-f3d39ac56ad5'),
	(28,28,1,NULL,NULL,1,'2020-12-07 19:56:43','2020-12-07 19:56:43','3e46cdeb-9271-4b56-8159-0e42fc9e3cf9'),
	(29,29,1,'about','about',1,'2020-12-07 20:14:29','2020-12-07 20:14:29','6af4a5ce-7a84-4840-902c-92a1dcc0e963'),
	(30,30,1,NULL,NULL,1,'2020-12-07 20:14:29','2020-12-07 20:14:29','1a756224-9621-4c9d-a549-e058e9327cea'),
	(31,31,1,NULL,NULL,1,'2020-12-07 20:14:29','2020-12-07 20:14:29','4232a78a-44d2-4329-912c-f6f8335de4d8'),
	(32,32,1,'about','about',1,'2020-12-07 20:36:27','2020-12-07 20:36:27','01e19480-1fbb-4df8-9092-f225368e44ba'),
	(33,33,1,NULL,NULL,1,'2020-12-07 20:36:27','2020-12-07 20:36:27','2b7d13fc-acbe-452a-a01a-305c4ec03f3c'),
	(34,34,1,NULL,NULL,1,'2020-12-07 20:36:27','2020-12-07 20:36:27','2f32ca32-3aa1-4f78-bbe5-aae0077e472d'),
	(36,36,1,'guide-to-broome','blog/guide-to-broome',1,'2020-12-07 22:23:41','2020-12-07 22:23:41','58c255ca-ac2a-4a1b-b813-df65e83a3379'),
	(37,37,1,'guide-to-broome','blog/guide-to-broome',1,'2020-12-07 22:23:41','2020-12-07 22:23:41','b1eed298-537d-458a-bd29-65716fe20b4f'),
	(39,39,1,'guide-to-alice-springs','blog/guide-to-alice-springs',1,'2020-12-07 22:25:36','2020-12-07 22:25:36','2c30b06a-0553-407f-95cf-0f2a000053d7'),
	(40,40,1,'guide-to-alice-springs','blog/guide-to-alice-springs',1,'2020-12-07 22:25:36','2020-12-07 22:25:36','05f5bc6b-b79f-45e9-94e3-a59d83fd231a'),
	(41,41,1,'home','__home__',1,'2020-12-08 08:17:19','2020-12-08 08:17:19','240e8ea8-98c2-4810-8568-d356fc2abe7b'),
	(42,42,1,NULL,NULL,1,'2020-12-08 08:19:55','2020-12-08 08:19:55','cbe12fcf-fb46-402a-b0e8-af722b163f6d'),
	(43,43,1,'home','__home__',1,'2020-12-08 08:19:55','2020-12-08 08:19:55','b393edae-d506-49d2-9499-5c6b4f84e84e'),
	(44,44,1,NULL,NULL,1,'2020-12-08 08:19:55','2020-12-08 08:19:55','873a4130-5896-45f7-879c-7ac347d15195'),
	(45,45,1,'home','__home__',1,'2020-12-08 08:20:21','2020-12-08 08:20:21','f8b81c16-d2d4-4155-8956-a5646ca1ddaf'),
	(46,46,1,NULL,NULL,1,'2020-12-08 08:20:21','2020-12-08 08:20:21','bf16a5fa-8af2-48c3-abbf-8d3865f2ad4d'),
	(47,47,1,NULL,NULL,1,'2020-12-08 09:23:25','2020-12-08 09:23:25','8e73907b-b841-4c49-ba94-baf4e8d65e32'),
	(48,48,1,NULL,NULL,1,'2020-12-08 09:23:25','2020-12-08 09:23:25','de12ab04-9be8-4191-b63b-3058a3eed37c'),
	(49,49,1,NULL,NULL,1,'2020-12-08 09:23:25','2020-12-08 09:23:25','c9e81e1f-5607-4343-9196-24d149434fe1'),
	(50,50,1,'home','__home__',1,'2020-12-08 09:23:25','2020-12-08 09:23:25','568e42db-5196-48f9-b614-aad772cb2951'),
	(51,51,1,NULL,NULL,1,'2020-12-08 09:23:25','2020-12-08 09:23:25','ce60be75-815a-466c-ba0c-fd056670fa28'),
	(52,52,1,NULL,NULL,1,'2020-12-08 09:23:26','2020-12-08 09:23:26','fb41ecd4-edfa-4dc5-bc57-330befcff1e0'),
	(53,53,1,NULL,NULL,1,'2020-12-08 09:23:26','2020-12-08 09:23:26','03fab722-8b21-4548-b8d2-5d597d5fde28'),
	(54,54,1,NULL,NULL,1,'2020-12-08 09:23:26','2020-12-08 09:23:26','2b3b7170-326c-41c8-bb25-26bfb8e36fc8'),
	(55,55,1,'__temp_dhawgqgtgfrpxjfdfpcoqwhgutdktxieuyyq','activities/__temp_dhawgqgtgfrpxjfdfpcoqwhgutdktxieuyyq',1,'2020-12-08 09:58:09','2020-12-08 09:58:09','3d51a278-2391-47c1-8a01-083cedd6d704'),
	(57,57,1,'immersive-activities','packages/immersive-activities',1,'2020-12-08 10:04:35','2020-12-09 07:17:29','f1ee11dc-046b-4f82-ba74-620d69422533'),
	(58,58,1,'immersive-activities','activities/immersive-activities',1,'2020-12-08 10:04:35','2020-12-08 10:04:35','537ceefc-c2c7-449f-80f0-2a7b58935ad5'),
	(59,59,1,'__temp_zkdefnyykhfypladwffoqbhgbiugiqdualhi','activities/__temp_zkdefnyykhfypladwffoqbhgbiugiqdualhi',1,'2020-12-08 17:46:30','2020-12-08 17:46:30','48e03fd5-e509-4613-ac4d-92041a5fdeb4'),
	(61,61,1,'places','packages/places',1,'2020-12-08 17:52:27','2020-12-09 07:17:29','de841e8b-b5de-4de0-8318-9e7f2cea9530'),
	(62,62,1,'places','activities/places',1,'2020-12-08 17:52:27','2020-12-08 17:52:27','24ae0152-5dd5-4c8b-8815-7050d90b7b48'),
	(64,64,1,'packages','packages/packages',1,'2020-12-08 17:54:04','2020-12-09 07:17:28','34d16344-c90f-474b-9af9-e51c076f4923'),
	(65,65,1,'packages','activities/packages',1,'2020-12-08 17:54:04','2020-12-08 17:54:04','17d35d4f-bfc2-4035-a3b1-2b4b55885d18'),
	(66,66,1,NULL,NULL,1,'2020-12-08 18:08:37','2020-12-08 18:08:37','e2444042-21fb-4473-8da2-86707b053a20'),
	(67,67,1,'packages','activities/packages',1,'2020-12-08 18:08:38','2020-12-08 18:08:38','1f8ac641-e4dd-43b1-a170-04985296ae30'),
	(68,68,1,NULL,NULL,1,'2020-12-08 18:08:38','2020-12-08 18:08:38','e308ee8e-5660-4a1d-8f6b-6d68ac9f6c0b'),
	(69,69,1,NULL,NULL,1,'2020-12-08 18:09:16','2020-12-08 18:09:16','4d08bb0b-6fd3-44b6-bc70-f71e504643df'),
	(70,70,1,'places','activities/places',1,'2020-12-08 18:09:16','2020-12-08 18:09:16','ccbe19fd-5060-4f5e-9fe2-ff62597deaef'),
	(71,71,1,NULL,NULL,1,'2020-12-08 18:09:16','2020-12-08 18:09:16','a2eb3637-96f5-498a-a059-a9a3bcc48d49'),
	(72,72,1,NULL,NULL,1,'2020-12-08 18:09:50','2020-12-08 18:09:50','0d97f6e7-3248-4fbe-ac46-f248bae7622f'),
	(73,73,1,'immersive-activities','activities/immersive-activities',1,'2020-12-08 18:09:51','2020-12-08 18:09:51','78e95f58-6f4c-4160-b581-dd838463d52a'),
	(74,74,1,NULL,NULL,1,'2020-12-08 18:09:51','2020-12-08 18:09:51','452f99ff-7eb2-4860-9c26-2e3f433d126e'),
	(75,75,1,'packages','activities/packages',1,'2020-12-08 18:17:41','2020-12-08 18:17:41','4b63221e-a181-4f3c-b1c3-cd26fc002ac6'),
	(76,76,1,NULL,NULL,1,'2020-12-08 18:17:41','2020-12-08 18:17:41','a5cb77ce-c8a5-4798-b154-2b7d1ab50776'),
	(77,77,1,'places','activities/places',1,'2020-12-08 18:17:56','2020-12-08 18:17:56','7393757d-2990-487c-a8f6-f5f7d1b3ec07'),
	(78,78,1,NULL,NULL,1,'2020-12-08 18:17:56','2020-12-08 18:17:56','6b002f6b-6bfd-4a86-9336-c87cab3b1275'),
	(79,79,1,'immersive-activities','activities/immersive-activities',1,'2020-12-08 18:18:12','2020-12-08 18:18:12','e9399622-0c19-4fc3-a6bd-104b04bf99f0'),
	(80,80,1,NULL,NULL,1,'2020-12-08 18:18:12','2020-12-08 18:18:12','2420616c-f64e-41e6-8fe9-a256b58e7977'),
	(81,81,1,'home','__home__',1,'2020-12-08 20:07:34','2020-12-08 20:07:34','930504be-a3f5-4fa2-9134-08a605b196c6'),
	(82,82,1,NULL,NULL,1,'2020-12-08 20:07:34','2020-12-08 20:07:34','eb2f5355-0db6-406c-9b11-53fd852a1964'),
	(83,83,1,'home','__home__',1,'2020-12-09 00:07:30','2020-12-09 00:07:30','8118cfa7-5098-400e-aefb-1d5d697c5809'),
	(84,84,1,NULL,NULL,1,'2020-12-09 00:07:30','2020-12-09 00:07:30','d1497a28-cc6e-402c-86bd-0a734e9765ef'),
	(85,85,1,NULL,NULL,1,'2020-12-09 07:28:39','2020-12-09 07:28:39','f803d0e8-c943-4662-a5df-8f274eaf8804'),
	(86,86,1,'home','__home__',1,'2020-12-09 07:28:39','2020-12-09 07:28:39','aeae7c6d-9545-4bc6-9273-32c8db50b296'),
	(87,87,1,NULL,NULL,1,'2020-12-09 07:28:39','2020-12-09 07:28:39','ca25bdae-40cc-4b25-a2e1-9c2e9663609d'),
	(88,88,1,NULL,NULL,1,'2020-12-09 07:28:39','2020-12-09 07:28:39','0479dd01-7120-4dab-a0d8-5361bb651f1f'),
	(89,89,1,'home','__home__',1,'2020-12-09 07:38:03','2020-12-09 07:38:03','823032c4-f7be-47ff-b2c0-d956bb9c787b'),
	(90,90,1,NULL,NULL,1,'2020-12-09 07:38:03','2020-12-09 07:38:03','86bc6968-2425-4ad9-9058-dbdda699fb9f'),
	(91,91,1,NULL,NULL,1,'2020-12-09 07:38:03','2020-12-09 07:38:03','52358940-7fc1-43fa-a9f8-464e80d04c90'),
	(92,92,1,'home','__home__',1,'2020-12-09 08:06:36','2020-12-09 08:06:36','3ce4001d-241e-4c14-8c4e-76fada6bff5a'),
	(93,93,1,NULL,NULL,1,'2020-12-09 08:06:36','2020-12-09 08:06:36','732ce852-ab0e-48a5-8eca-54f2beecd576'),
	(94,94,1,'home','__home__',1,'2020-12-09 08:07:13','2020-12-09 08:07:13','ce6f4251-454a-4322-b590-7f2207c04207'),
	(95,95,1,NULL,NULL,1,'2020-12-09 08:07:13','2020-12-09 08:07:13','b4d69fe5-9a3c-43a4-a514-a2369911e0d5'),
	(96,96,1,NULL,NULL,1,'2020-12-09 08:10:34','2020-12-09 08:10:34','efb1efc3-91e2-4332-96c4-0c6033ee1e46'),
	(97,97,1,NULL,NULL,1,'2020-12-09 08:10:34','2020-12-09 08:10:34','9c8f971b-87ef-4584-aac3-47a1323cb2f9'),
	(98,98,1,NULL,NULL,1,'2020-12-09 08:10:34','2020-12-09 08:10:34','e15d6234-ea95-44f2-8d89-d302250ef2bb'),
	(99,99,1,NULL,NULL,1,'2020-12-09 08:10:34','2020-12-09 08:10:34','dd1106d1-d064-47b6-af11-d92f610c81d6'),
	(100,100,1,'home','__home__',1,'2020-12-09 08:10:35','2020-12-09 08:10:35','6ecff0ba-58af-476b-aed0-1528a8e2f075'),
	(101,101,1,NULL,NULL,1,'2020-12-09 08:10:35','2020-12-09 08:10:35','82707aa4-a923-4986-bb2a-d5e7d419127d'),
	(102,102,1,NULL,NULL,1,'2020-12-09 08:10:35','2020-12-09 08:10:35','cfb7365e-22c4-4769-8052-14eff732b1c6'),
	(103,103,1,NULL,NULL,1,'2020-12-09 08:10:35','2020-12-09 08:10:35','327d40fa-f26f-46c4-84d0-e9de542fd659'),
	(104,104,1,NULL,NULL,1,'2020-12-09 08:10:35','2020-12-09 08:10:35','4f973b44-d076-4bc3-84ed-2f29c603dcec'),
	(105,105,1,NULL,NULL,1,'2020-12-09 08:10:35','2020-12-09 08:10:35','5cbf4831-b87f-4f48-a3c4-27d50e309952'),
	(106,106,1,NULL,NULL,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','31c01ff7-18f0-4fa5-ae64-d75afbe1c11f'),
	(107,107,1,NULL,NULL,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','7761b9b5-71ae-4fe5-ab8f-0c47a2447aa8'),
	(108,108,1,NULL,NULL,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','000b219e-7d83-4543-877d-f5a902f34c89'),
	(109,109,1,'home','__home__',1,'2020-12-09 18:47:32','2020-12-09 18:47:32','1a8bac08-9396-471d-bd19-82f43dcb5135'),
	(110,110,1,NULL,NULL,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','8213ed27-94c6-4a02-a8b6-cb0fc7aa0de5'),
	(111,111,1,NULL,NULL,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','03398b15-470c-4803-9a73-f3477d727ce0'),
	(112,112,1,NULL,NULL,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','7d570792-82b1-4825-92f3-3c82639f84b3'),
	(113,113,1,NULL,NULL,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','09586725-cfa1-4565-8a8d-6616fdfb2a79'),
	(114,114,1,NULL,NULL,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','4c0b4a3d-a772-4369-957f-cf7cdeca63c1'),
	(115,115,1,NULL,NULL,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','dc449182-5339-40c3-b7ac-52fed4b80b54'),
	(116,116,1,NULL,NULL,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','5d4b7a20-dc58-4064-9944-3c791d39ffa8'),
	(117,117,1,NULL,NULL,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','96193b0d-4ed4-4cc4-892d-2f7ad107b421'),
	(118,118,1,'home','__home__',1,'2020-12-09 19:08:12','2020-12-09 19:08:12','3296f6a6-52cc-45c6-ba3e-002aaf9b064b'),
	(119,119,1,NULL,NULL,1,'2020-12-09 19:08:12','2020-12-09 19:08:12','f2f0b0ab-82b3-4eb5-b517-9ba36978a4bd'),
	(120,120,1,NULL,NULL,1,'2020-12-09 19:08:12','2020-12-09 19:08:12','99ea199f-0714-4f10-8d88-4f2f5f138a25'),
	(121,121,1,NULL,NULL,1,'2020-12-09 19:08:13','2020-12-09 19:08:13','b2445752-cef1-4c9c-9fbc-07f0e8cc4b1f'),
	(122,122,1,NULL,NULL,1,'2020-12-09 19:08:13','2020-12-09 19:08:13','af2f75da-484a-4f90-bde7-4d8fafe096ff'),
	(123,123,1,NULL,NULL,1,'2020-12-09 19:08:13','2020-12-09 19:08:13','8b738beb-b0fd-41ee-ab1b-88e41f999033'),
	(124,124,1,NULL,NULL,1,'2020-12-09 19:08:13','2020-12-09 19:08:13','698f27a2-4504-4815-9260-0093a1388f88'),
	(125,125,1,NULL,NULL,1,'2020-12-09 19:08:13','2020-12-09 19:08:13','c8c9da44-4bb3-4458-8185-938b342c0b35'),
	(126,126,1,NULL,NULL,1,'2020-12-09 19:08:13','2020-12-09 19:08:13','1214872a-99a9-4e57-b018-5f6d7977da90'),
	(127,127,1,NULL,NULL,1,'2020-12-09 19:11:11','2020-12-09 19:11:11','c36257b3-364e-4a0b-b2a3-d4734efc6e76'),
	(128,128,1,'home','__home__',1,'2020-12-09 19:11:12','2020-12-09 19:11:12','75658a11-5b63-4039-9deb-17b732eb26a2'),
	(129,129,1,NULL,NULL,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','bd0040c2-3115-4f5c-a08b-a02aec0dd458'),
	(130,130,1,NULL,NULL,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','2e3d45b2-712c-424b-a832-a8ad02a98575'),
	(131,131,1,NULL,NULL,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','1b66c3cd-613d-4bc4-a377-95a47855412a'),
	(132,132,1,NULL,NULL,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','886cfad0-b6ae-4e13-98d7-beffe9b9f09b'),
	(133,133,1,NULL,NULL,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','8a7cac6b-79b6-4a85-81f3-89ea0fbee120'),
	(134,134,1,NULL,NULL,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','48ca299d-d0c2-4311-b59b-4082c4ff9118'),
	(135,135,1,NULL,NULL,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','00a72762-e658-4305-80a2-e65b2b0471f2'),
	(136,136,1,NULL,NULL,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','ba4349a5-42c8-414b-ae22-39c162badae4'),
	(137,137,1,NULL,NULL,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','cfc71383-48db-455b-a832-43215a38e196'),
	(138,138,1,'home','__home__',1,'2020-12-09 22:32:48','2020-12-09 22:32:48','d5617bee-eff6-47ff-a974-1d917dc5ddfa'),
	(139,139,1,NULL,NULL,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','e1f6b68f-9070-4932-a06a-5ba4385c271e'),
	(140,140,1,NULL,NULL,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','b6ede4a6-700f-4884-8c72-b58bb17c72aa'),
	(141,141,1,NULL,NULL,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','e93bb4ce-1209-4bc9-9246-e290b0bf5864'),
	(142,142,1,NULL,NULL,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','9097ac05-e8ea-424b-9e48-604c0e138775'),
	(143,143,1,NULL,NULL,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','f2661fcd-9080-42b8-9e82-e6534567bcd4'),
	(144,144,1,NULL,NULL,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','13b431c3-7011-4e8d-b5a5-ea9c3c56e640'),
	(145,145,1,NULL,NULL,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','cc31cf53-1bbb-4b0f-8155-e69998fc848b'),
	(146,146,1,NULL,NULL,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','eef879d1-5687-4597-b9db-bfbce8a3f3a1'),
	(147,147,1,NULL,NULL,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','b002c476-a3ca-4295-b0a9-8812e1df6430'),
	(148,148,1,'home','__home__',1,'2020-12-09 22:35:36','2020-12-09 22:35:36','ce379d17-d38e-46a2-8e1e-60d96e83cebf'),
	(149,149,1,NULL,NULL,1,'2020-12-09 22:35:36','2020-12-09 22:35:36','dbeba36c-fc55-4a5b-945c-56fa7376949b'),
	(150,150,1,NULL,NULL,1,'2020-12-09 22:35:36','2020-12-09 22:35:36','cf94bc5b-ad14-4d92-8723-47d87d704e9b'),
	(151,151,1,NULL,NULL,1,'2020-12-09 22:35:36','2020-12-09 22:35:36','f89a701e-9e4c-4a90-ab9e-f01060e623af'),
	(152,152,1,NULL,NULL,1,'2020-12-09 22:35:36','2020-12-09 22:35:36','769b304e-da8d-4ce7-8eea-7ee94511e049'),
	(153,153,1,NULL,NULL,1,'2020-12-09 22:35:36','2020-12-09 22:35:36','c14299e7-f96b-4c62-8337-7f6ba5c38ebf'),
	(154,154,1,NULL,NULL,1,'2020-12-09 22:35:37','2020-12-09 22:35:37','0aaf8ee6-69d2-4c2b-bd93-770aa8c2ae2b'),
	(155,155,1,NULL,NULL,1,'2020-12-09 22:35:37','2020-12-09 22:35:37','5f684e1b-4bdd-49d1-9067-d9076ce3c5f6'),
	(156,156,1,NULL,NULL,1,'2020-12-09 22:35:37','2020-12-09 22:35:37','5fcdb1cc-3d07-4d00-b470-1fff663836df'),
	(157,157,1,NULL,NULL,1,'2020-12-09 22:35:37','2020-12-09 22:35:37','874b80bc-2743-4c6b-9be4-767cb5daf6fb'),
	(158,158,1,'home','__home__',1,'2020-12-09 22:50:38','2020-12-09 22:50:38','87542197-5f1c-4b26-8d09-f9493bc3899a'),
	(159,159,1,NULL,NULL,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','52c854f5-5b42-4bf4-bbee-6f3b031103f0'),
	(160,160,1,NULL,NULL,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','aec8ef38-fe58-41c3-a38c-702f364fd8dd'),
	(161,161,1,NULL,NULL,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','cd18f183-3185-4e41-9854-fb83a5654de7'),
	(162,162,1,NULL,NULL,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','aab5859e-526b-4ca2-b2b0-808a6de1bd6e'),
	(163,163,1,NULL,NULL,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','a371089c-3b7e-4df3-9205-7dab731c680d'),
	(164,164,1,NULL,NULL,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','597275c7-bae6-4c24-bc15-7618189d10e1'),
	(165,165,1,NULL,NULL,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','113cc8cb-06b8-43c2-8eb7-d7505245ff5e'),
	(166,166,1,NULL,NULL,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','2d42c539-22c7-45a4-ac94-e852a7794f10'),
	(167,167,1,NULL,NULL,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','4271862b-bc3b-4a06-835f-ce56e0c3edfd'),
	(168,168,1,NULL,NULL,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','80a30ae2-ce63-45bf-a0d2-d7ed1b696ab8'),
	(169,169,1,'home','__home__',1,'2020-12-09 22:56:06','2020-12-09 22:56:06','002bb9d3-eaee-49f7-a3fa-907ee249c273'),
	(170,170,1,NULL,NULL,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','40c589c9-6d5d-4016-bb3e-5d3746b67bbc'),
	(171,171,1,NULL,NULL,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','6b10d7f2-a867-4289-9d6f-7bbf85778dae'),
	(172,172,1,NULL,NULL,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','05046f47-163e-4cff-8ef2-8c29c0939c2c'),
	(173,173,1,NULL,NULL,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','f170ab1c-13cc-4d3c-99dc-34d588dc4a44'),
	(174,174,1,NULL,NULL,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','7c1e926f-6c1b-4184-a978-38d99a227b9d'),
	(175,175,1,NULL,NULL,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','b54c8ad0-2b1c-4e17-a1f6-70ee34eddccf'),
	(176,176,1,NULL,NULL,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','899b3764-b797-4d3a-a9b5-0d6bbbc8c7f1'),
	(177,177,1,NULL,NULL,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','2f08e8b1-ecf5-40d8-a6d1-8ce333e64cab'),
	(178,178,1,NULL,NULL,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','8bc7ea71-6adf-45aa-bee2-021dfd0f330d'),
	(179,179,1,NULL,NULL,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','79943f35-c6d2-4195-887e-1be18a30742f'),
	(180,180,1,'home','__home__',1,'2020-12-09 23:01:03','2020-12-09 23:01:03','a7f49697-a590-4abf-aa46-669dd05ca69f'),
	(181,181,1,NULL,NULL,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','d3792463-374a-41f8-a2e4-d10165e8a552'),
	(182,182,1,NULL,NULL,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','b1d09890-2be0-4eaf-acd3-6d7ada476f48'),
	(183,183,1,NULL,NULL,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','bec04950-8b90-4c21-9252-6c2a1a89f6ec'),
	(184,184,1,NULL,NULL,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','01379a7e-75c3-4153-9a41-45c0f68c8d1d'),
	(185,185,1,NULL,NULL,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','0fea3254-2567-4ba3-ac91-b7ace321acb5'),
	(186,186,1,NULL,NULL,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','169cd5eb-b961-453b-98f2-8a9df0facefb'),
	(187,187,1,NULL,NULL,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','6842a47d-74a7-43b9-9337-2ee965a6f30f'),
	(188,188,1,NULL,NULL,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','789ef30e-1f3f-4d94-a4e4-1520c5f40802'),
	(189,189,1,NULL,NULL,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','1b2b57d2-394b-4bf9-adfa-fc7cdf6a460a'),
	(190,190,1,NULL,NULL,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','a89c5aa4-3921-43a7-bfda-fb3d5ccfe10b'),
	(191,191,1,'home','__home__',1,'2020-12-09 23:18:20','2020-12-09 23:18:20','10c4645f-8bc4-4cfe-90b3-a172996e9224'),
	(192,192,1,NULL,NULL,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','a0db425a-6ccd-49ce-a4d5-45a1e3fd7ecd'),
	(193,193,1,NULL,NULL,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','ade074d8-8a54-43f2-a900-e2274a64e600'),
	(194,194,1,NULL,NULL,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','5b2db720-682d-4a4e-979d-2ae19aa856cc'),
	(195,195,1,NULL,NULL,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','d6233792-e6a3-4602-b96d-3b36987f68d2'),
	(196,196,1,NULL,NULL,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','556608f8-3cb4-487b-bdc1-3628e82e4f50'),
	(197,197,1,NULL,NULL,1,'2020-12-09 23:18:21','2020-12-09 23:18:21','d77a8b79-ea97-4ca2-8ebe-99938a83f600'),
	(198,198,1,NULL,NULL,1,'2020-12-09 23:18:21','2020-12-09 23:18:21','76133bb4-3982-4292-b443-f91b4f69bddb'),
	(199,199,1,NULL,NULL,1,'2020-12-09 23:18:21','2020-12-09 23:18:21','246c7d5c-7559-4ff7-a0c7-7377e8e176fb'),
	(200,200,1,NULL,NULL,1,'2020-12-09 23:18:21','2020-12-09 23:18:21','4908499c-59c7-4370-8e99-96be6d1f5543'),
	(201,201,1,NULL,NULL,1,'2020-12-09 23:18:21','2020-12-09 23:18:21','9fed3ef2-4f27-4633-bb98-869c5bdf645e'),
	(202,202,1,'home','__home__',1,'2020-12-09 23:20:49','2020-12-09 23:20:49','8499e78b-277c-4d40-aef8-f6ebdf1791ce'),
	(203,203,1,NULL,NULL,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','bda71873-c5d5-4213-8d2e-d936d62496f6'),
	(204,204,1,NULL,NULL,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','75a71898-c1e1-48a4-8d22-84cc9f277cbe'),
	(205,205,1,NULL,NULL,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','b229dc1a-0293-4a44-8128-885bbdea811f'),
	(206,206,1,NULL,NULL,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','88706e48-ee5e-4ae3-9015-0dfd5da44a60'),
	(207,207,1,NULL,NULL,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','61bf3898-f621-49a9-bd37-d119d51fcc6f'),
	(208,208,1,NULL,NULL,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','b3e73a9d-abe3-4c17-a893-b3a0f31cc5de'),
	(209,209,1,NULL,NULL,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','482802c0-bc58-47a4-9655-9516cb4fdf80'),
	(210,210,1,NULL,NULL,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','2402a605-8a39-49ec-91ab-7832c8873c16'),
	(211,211,1,NULL,NULL,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','1047bb40-88eb-4deb-b65c-f2c16dec25cd'),
	(212,212,1,NULL,NULL,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','31e2474f-1127-4e9c-83b0-357dec8f05f1'),
	(213,213,1,'home','__home__',1,'2020-12-09 23:58:21','2020-12-09 23:58:21','5213a92a-ed5f-4816-a980-7f3bfbd39064'),
	(214,214,1,NULL,NULL,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','8e158288-6986-47ab-ae1e-db29a4a71802'),
	(215,215,1,NULL,NULL,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','347f830f-15e6-415d-95b3-5ff1bf3bb3b2'),
	(216,216,1,NULL,NULL,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','b8ca01a8-b42e-4efd-af97-6bf1d52422e6'),
	(217,217,1,NULL,NULL,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','ed1329b0-bcac-40eb-ab80-63fded821b8c'),
	(218,218,1,NULL,NULL,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','fa1efa04-5dad-4714-a72b-2aa4f327e6c7'),
	(219,219,1,NULL,NULL,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','ddfcb054-0189-4508-88bb-c03cda2e790b'),
	(220,220,1,NULL,NULL,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','9686412a-363b-4e00-b152-61b0b5d07637'),
	(221,221,1,NULL,NULL,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','c9ae2b77-aa35-4f05-98e5-bbe2cdc4caad'),
	(222,222,1,NULL,NULL,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','693ab3c0-fb17-4cb7-a6d4-a4bfce01685a'),
	(223,223,1,NULL,NULL,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','e7ae9f22-cc57-451e-a0e2-9df42f2d2350'),
	(224,224,1,NULL,NULL,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','b422cdf7-e4a7-4543-b7ef-8229e46cfd7e'),
	(225,225,1,'home','__home__',1,'2020-12-10 00:00:08','2020-12-10 00:00:08','ab7fd57b-f68d-4423-a47c-0de015aebdb5'),
	(226,226,1,NULL,NULL,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','4c1e92e1-66b3-4254-aadb-d6ebbdac7a55'),
	(227,227,1,NULL,NULL,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','0fb6a813-4217-4248-a539-61be2cc1d7ce'),
	(228,228,1,NULL,NULL,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','efdca0ce-1cec-4e22-9e35-0f1f147e5a64'),
	(229,229,1,NULL,NULL,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','2af7e3fd-2d77-4d94-886d-995d7b148b12'),
	(230,230,1,NULL,NULL,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','88d2be70-64bc-4cfc-9a9f-26871a8372b8'),
	(231,231,1,NULL,NULL,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','147fed20-2de0-4738-8985-3a0a93b592b9'),
	(232,232,1,NULL,NULL,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','537840bc-6ea9-4a6a-aa54-7b8a3e060d18'),
	(233,233,1,NULL,NULL,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','7659525c-4c56-4361-a2b0-0d32f2a16bf8'),
	(234,234,1,NULL,NULL,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','5c32c411-77df-4810-b91d-b1ff7c85f18b'),
	(235,235,1,NULL,NULL,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','a00bbe01-1f99-4dfa-b4ca-0598118d228c'),
	(236,236,1,NULL,NULL,1,'2020-12-10 00:00:09','2020-12-10 00:00:09','3340e94d-4d98-4af6-9e14-5dc879ee2490'),
	(237,237,1,'home','__home__',1,'2020-12-10 00:08:00','2020-12-10 00:08:00','ec950158-082c-483e-8438-09eda8b43474'),
	(238,238,1,NULL,NULL,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','9357b6a2-7514-48ca-9583-20632bf1e955'),
	(239,239,1,NULL,NULL,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','61d9cb27-d5c8-4722-a044-5774ea8c4520'),
	(240,240,1,NULL,NULL,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','827be570-4992-4904-8a59-89fdfc326c76'),
	(241,241,1,NULL,NULL,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','f9a1f069-5d89-4740-95ce-c31a999a1190'),
	(242,242,1,NULL,NULL,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','1b430e20-8f79-4a6f-b2dd-d22307c9d074'),
	(243,243,1,NULL,NULL,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','00f8d0ba-7acd-46ef-98d8-75889ecb6be3'),
	(244,244,1,NULL,NULL,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','18389338-8f93-4986-9952-57226d9b7f4e'),
	(245,245,1,NULL,NULL,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','805a2e21-5443-48d3-85a3-472e7847d6d8'),
	(246,246,1,NULL,NULL,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','cbdd5dcf-dea3-4270-972e-442853d481ce'),
	(247,247,1,NULL,NULL,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','2ea70082-dfff-4f49-9d47-3c39b61da57c'),
	(248,248,1,NULL,NULL,1,'2020-12-10 00:08:01','2020-12-10 00:08:01','6265fb7e-43b0-4824-8c4a-aedd3c77e9f6'),
	(249,249,1,'home','__home__',1,'2020-12-10 00:31:34','2020-12-10 00:31:34','49fa0194-2345-433a-ad63-47f62c8528d7'),
	(250,250,1,NULL,NULL,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','bba6d5bc-082a-4d9a-a959-ea571e28dfad'),
	(251,251,1,NULL,NULL,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','519c37f1-0571-4be8-b628-ffd7964ba6f6'),
	(252,252,1,NULL,NULL,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','b5d026b8-b4e0-414f-a173-dde9646cd941'),
	(253,253,1,NULL,NULL,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','f719acf5-b579-44c4-a6a9-7553e0b70e12'),
	(254,254,1,NULL,NULL,1,'2020-12-10 00:31:35','2020-12-10 00:31:35','613d6ce9-b7ec-48e5-9e9c-4601dc9372aa'),
	(255,255,1,NULL,NULL,1,'2020-12-10 00:31:35','2020-12-10 00:31:35','4c9a122e-3d35-44d0-badd-060389833e0c'),
	(256,256,1,NULL,NULL,1,'2020-12-10 00:31:35','2020-12-10 00:31:35','8971cf4c-1303-43e4-bb4e-6536a92c5740'),
	(257,257,1,NULL,NULL,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','7e50b999-c350-475c-b44b-362bcd3a84f4'),
	(258,258,1,'home','__home__',1,'2020-12-10 00:33:07','2020-12-10 00:33:07','49518e0b-c5f6-4a3a-9d55-b1fe3be1b6c4'),
	(259,259,1,NULL,NULL,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','a475d3eb-181b-4e38-80c2-709c9c5e2630'),
	(260,260,1,NULL,NULL,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','b26c5b32-9d9e-4a76-b211-cc45a9469229'),
	(261,261,1,NULL,NULL,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','5f1cd417-ed29-451b-a406-1f4fbda9f548'),
	(262,262,1,NULL,NULL,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','f15c8748-fb39-47cc-8821-1cc9b50076db'),
	(263,263,1,NULL,NULL,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','9ce1a5fb-ab80-4f3c-8a8f-6e8d7692445e'),
	(264,264,1,NULL,NULL,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','17092a13-25a9-4be8-849c-8c58c519a5f8'),
	(265,265,1,NULL,NULL,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','9eb55c72-7c6d-4186-b008-13a6a96e1cf2'),
	(266,266,1,NULL,NULL,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','bf5354c1-41bc-46fb-b6b3-9c520493b959'),
	(267,267,1,'home','__home__',1,'2020-12-10 00:34:13','2020-12-10 00:34:13','e407f96a-4c79-4668-a18b-8066eb664dab'),
	(268,268,1,NULL,NULL,1,'2020-12-10 00:34:13','2020-12-10 00:34:13','addb8559-c0b9-4dd2-9e7e-8d637d7f2d22'),
	(269,269,1,NULL,NULL,1,'2020-12-10 00:34:13','2020-12-10 00:34:13','cd4a4153-5766-4141-b3ad-89659382344d'),
	(270,270,1,NULL,NULL,1,'2020-12-10 00:34:13','2020-12-10 00:34:13','66ce67cf-95bb-4ef0-bea7-624bd8cfc45c'),
	(271,271,1,NULL,NULL,1,'2020-12-10 00:34:13','2020-12-10 00:34:13','da122d92-d339-41df-8047-7f7aade82b0c'),
	(272,272,1,'home','__home__',1,'2020-12-10 00:34:53','2020-12-10 00:34:53','e77e7bf5-0f75-4943-b4ed-293ff1621b9d'),
	(273,273,1,NULL,NULL,1,'2020-12-10 00:34:53','2020-12-10 00:34:53','98a4c0b9-8627-4db0-a793-67d7040f9092'),
	(274,274,1,NULL,NULL,1,'2020-12-10 00:34:53','2020-12-10 00:34:53','a2b6f497-5a3b-4c27-9f84-8dae720af017'),
	(275,275,1,NULL,NULL,1,'2020-12-10 00:34:54','2020-12-10 00:34:54','bcd1e084-a573-46ed-8bdd-ba416246c2bb'),
	(276,276,1,NULL,NULL,1,'2020-12-10 00:34:54','2020-12-10 00:34:54','9a0d0d34-af0e-4070-801a-7021426dd0be'),
	(277,277,1,'home','__home__',1,'2020-12-14 23:15:24','2020-12-14 23:15:24','6c81d0fd-b709-4235-93b5-3be271588b7f'),
	(278,278,1,NULL,NULL,1,'2020-12-14 23:15:24','2020-12-14 23:15:24','13fa507c-feb9-4b41-b50c-2f9437b8abc3'),
	(279,279,1,NULL,NULL,1,'2020-12-14 23:15:24','2020-12-14 23:15:24','172c4330-6a35-4469-87b6-2cfb1ad87b11'),
	(280,280,1,NULL,NULL,1,'2020-12-14 23:15:24','2020-12-14 23:15:24','b2d40b08-5b03-49fb-88a3-349dc45a643e'),
	(281,281,1,NULL,NULL,1,'2020-12-14 23:15:24','2020-12-14 23:15:24','c0774568-fd74-4752-981d-5eedd0bf5955'),
	(282,282,1,'home','__home__',1,'2020-12-16 06:04:29','2020-12-16 06:04:29','48b9a40b-2b74-48f2-aedb-3ec05d2c5785'),
	(283,283,1,NULL,NULL,1,'2020-12-16 06:04:29','2020-12-16 06:04:29','53963034-ac0a-41bc-b80d-881bcbdbe3c5'),
	(284,284,1,NULL,NULL,1,'2020-12-16 06:04:29','2020-12-16 06:04:29','c7b414cd-ea6a-49e9-b850-4bee4481d0de'),
	(285,285,1,NULL,NULL,1,'2020-12-16 06:04:29','2020-12-16 06:04:29','0ba28d7c-de39-4d2a-8b4c-10a363c04205'),
	(286,286,1,NULL,NULL,1,'2020-12-16 06:04:29','2020-12-16 06:04:29','47c8d0e8-7f66-42ac-a52d-f5f8779b91f7'),
	(287,287,1,'home','__home__',1,'2020-12-16 06:05:08','2020-12-16 06:05:08','536dfdca-c2e8-452c-82b2-96cd4eb3aa01'),
	(288,288,1,NULL,NULL,1,'2020-12-16 06:05:08','2020-12-16 06:05:08','7f21cb9c-df70-45ce-88f5-d02e61eb608b'),
	(289,289,1,NULL,NULL,1,'2020-12-16 06:05:09','2020-12-16 06:05:09','598c63b6-fe64-4484-88b1-33aa3a847077'),
	(290,290,1,NULL,NULL,1,'2020-12-16 06:05:09','2020-12-16 06:05:09','81d5375f-f54d-45b7-9915-3f5642759dd5'),
	(291,291,1,NULL,NULL,1,'2020-12-16 06:05:09','2020-12-16 06:05:09','344ed287-d4ba-40e0-ba51-b15604a84e4e'),
	(292,292,1,'home','__home__',1,'2020-12-16 06:13:57','2020-12-16 06:13:57','3716ce7a-0902-4942-abb9-a61fb838580a'),
	(293,293,1,NULL,NULL,1,'2020-12-16 06:13:57','2020-12-16 06:13:57','521ce74d-597e-40fd-9ff3-47fc4fcdd71b'),
	(294,294,1,NULL,NULL,1,'2020-12-16 06:13:58','2020-12-16 06:13:58','81b6d7e6-60c6-49c8-9334-65d60fb6e0c1'),
	(295,295,1,NULL,NULL,1,'2020-12-16 06:13:58','2020-12-16 06:13:58','9363be21-d12e-4bc3-ba8c-72e46dba7c3d'),
	(296,296,1,NULL,NULL,1,'2020-12-16 06:13:58','2020-12-16 06:13:58','f97d1d7b-49df-4867-984a-af5340068535'),
	(297,297,1,'home','__home__',1,'2020-12-16 12:18:09','2020-12-16 12:18:09','e974b5d3-d472-41e8-9a3b-a381273174cb'),
	(298,298,1,NULL,NULL,1,'2020-12-16 12:18:09','2020-12-16 12:18:09','d9656782-62c5-4e8f-ba22-8594d6297085'),
	(299,299,1,NULL,NULL,1,'2020-12-16 12:18:09','2020-12-16 12:18:09','ac518d8e-7b66-4f0a-b042-076281cfd312'),
	(300,300,1,NULL,NULL,1,'2020-12-16 12:18:09','2020-12-16 12:18:09','cd214c0c-4f15-4de2-9164-f89d42d7807b'),
	(301,301,1,NULL,NULL,1,'2020-12-16 12:18:09','2020-12-16 12:18:09','9af25127-ea59-40c3-be99-d962f6450315'),
	(302,302,1,'home','__home__',1,'2020-12-16 12:19:22','2020-12-16 12:19:22','3d9647a0-2d72-456f-83d7-8e0b803a2b30'),
	(303,303,1,NULL,NULL,1,'2020-12-16 12:19:22','2020-12-16 12:19:22','1d418118-4c73-47ac-b91a-87dc03acc74b'),
	(304,304,1,NULL,NULL,1,'2020-12-16 12:19:22','2020-12-16 12:19:22','bfb0c405-14cb-4bba-b8d1-2604c0111aad'),
	(305,305,1,NULL,NULL,1,'2020-12-16 12:19:22','2020-12-16 12:19:22','7b1318e7-a0ad-48fa-8f27-62c059a0279c'),
	(306,306,1,NULL,NULL,1,'2020-12-16 12:19:23','2020-12-16 12:19:23','d83fe985-fb88-40bc-80aa-3baafc1871b5');

/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table entries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `entries`;

CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entries_postDate_idx` (`postDate`),
  KEY `entries_expiryDate_idx` (`expiryDate`),
  KEY `entries_authorId_idx` (`authorId`),
  KEY `entries_sectionId_idx` (`sectionId`),
  KEY `entries_typeId_idx` (`typeId`),
  KEY `entries_parentId_fk` (`parentId`),
  CONSTRAINT `entries_authorId_fk` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entries_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `entries_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;

INSERT INTO `entries` (`id`, `sectionId`, `parentId`, `typeId`, `authorId`, `postDate`, `expiryDate`, `deletedWithEntryType`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-07 08:31:20','2020-12-07 08:31:20','fa3e0c0f-cd86-4945-af8a-5c28d7aeff9c'),
	(2,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-07 08:31:20','2020-12-07 08:31:20','40f323db-3ef3-44e7-8520-ff97217f1eb9'),
	(3,3,NULL,3,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-07 08:31:20','2020-12-07 08:31:20','92f54d80-3d15-488a-bca3-f198d1cbcd64'),
	(4,3,NULL,3,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-07 08:31:20','2020-12-07 08:31:20','f193762d-cbb2-4908-80e8-3ecd47328281'),
	(23,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-07 19:31:38','2020-12-07 19:31:38','3862a28c-032a-456a-9c60-36ff7f71c5a3'),
	(26,3,NULL,3,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-07 19:56:43','2020-12-07 19:56:43','70b0e940-7d6e-4c85-a47d-8b7ecb40fd25'),
	(29,3,NULL,3,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-07 20:14:29','2020-12-07 20:14:29','c6237049-e0cf-4f4b-9d12-38ae801c7cfa'),
	(32,3,NULL,3,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-07 20:36:27','2020-12-07 20:36:27','f5863031-6a59-4af4-9dba-0206a280cedf'),
	(36,1,NULL,1,5,'2020-12-07 22:22:00',NULL,NULL,'2020-12-07 22:23:41','2020-12-07 22:23:41','7d17fb7e-26b8-48e8-8979-e333bd8b5825'),
	(37,1,NULL,1,5,'2020-12-07 22:22:00',NULL,NULL,'2020-12-07 22:23:41','2020-12-07 22:23:41','5ccfbaa1-8117-469f-9259-eac3985deee5'),
	(39,1,NULL,1,5,'2020-12-07 22:25:00',NULL,NULL,'2020-12-07 22:25:36','2020-12-07 22:25:36','3e34873b-433f-4599-af54-8c36f61f49dc'),
	(40,1,NULL,1,5,'2020-12-07 22:25:00',NULL,NULL,'2020-12-07 22:25:36','2020-12-07 22:25:36','c8e0912a-76f3-4824-90da-1c47db169766'),
	(41,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-08 08:17:19','2020-12-08 08:17:19','aa857a61-78f8-46ab-bbf2-3dab1d740880'),
	(43,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-08 08:19:55','2020-12-08 08:19:55','2dda4261-72be-4e5e-92ac-7a2e4c8ce516'),
	(45,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-08 08:20:21','2020-12-08 08:20:21','42c3eee8-d15e-492e-9d16-13339227d027'),
	(50,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-08 09:23:25','2020-12-08 09:23:25','b5e6f5dc-acc5-4e2b-81e2-baff59366da9'),
	(55,4,NULL,4,5,'2020-12-08 09:58:00',NULL,NULL,'2020-12-08 09:58:09','2020-12-08 09:58:09','28c0cab7-8f0f-4d22-84fd-0515ea475bfc'),
	(57,4,NULL,4,5,'2020-12-08 10:01:00',NULL,NULL,'2020-12-08 10:04:35','2020-12-08 10:04:35','2a48dcb5-b757-4e91-8bad-89d610d2bd68'),
	(58,4,NULL,4,5,'2020-12-08 10:01:00',NULL,NULL,'2020-12-08 10:04:35','2020-12-08 10:04:35','9622f9b1-0db0-48c5-84f5-707024b0aa51'),
	(59,4,NULL,4,5,'2020-12-08 17:46:00',NULL,NULL,'2020-12-08 17:46:30','2020-12-08 17:46:30','916ea905-0909-49bf-a868-5112de7a7cd9'),
	(61,4,NULL,4,5,'2020-12-08 17:51:00',NULL,NULL,'2020-12-08 17:52:27','2020-12-08 17:52:27','8992e2ba-3b74-4af0-beb4-461e5b3d6f04'),
	(62,4,NULL,4,5,'2020-12-08 17:51:00',NULL,NULL,'2020-12-08 17:52:27','2020-12-08 17:52:27','5992fbdf-1ab4-48eb-9611-6977f1166bf1'),
	(64,4,NULL,4,5,'2020-12-08 17:53:00',NULL,NULL,'2020-12-08 17:54:04','2020-12-08 17:54:04','a33614c4-0aae-4936-bc24-000f848cf773'),
	(65,4,NULL,4,5,'2020-12-08 17:53:00',NULL,NULL,'2020-12-08 17:54:04','2020-12-08 17:54:04','95b3a836-c9cb-471f-b603-1087535e7d13'),
	(67,4,NULL,4,5,'2020-12-08 17:53:00',NULL,NULL,'2020-12-08 18:08:38','2020-12-08 18:08:38','088a037c-07c3-4c55-b850-e1b5595d71a0'),
	(70,4,NULL,4,5,'2020-12-08 17:51:00',NULL,NULL,'2020-12-08 18:09:16','2020-12-08 18:09:16','00b42b48-ffdf-4cfe-8d83-750c564bae03'),
	(73,4,NULL,4,5,'2020-12-08 10:01:00',NULL,NULL,'2020-12-08 18:09:51','2020-12-08 18:09:51','b3fc85ed-32f3-4445-8f59-068626e912bd'),
	(75,4,NULL,4,5,'2020-12-08 17:53:00',NULL,NULL,'2020-12-08 18:17:41','2020-12-08 18:17:41','d4cae2ba-9863-4fa4-b52e-4241d10bab14'),
	(77,4,NULL,4,5,'2020-12-08 17:51:00',NULL,NULL,'2020-12-08 18:17:56','2020-12-08 18:17:56','764d44e4-7fab-4907-8c2d-86b23dc5d93e'),
	(79,4,NULL,4,5,'2020-12-08 10:01:00',NULL,NULL,'2020-12-08 18:18:12','2020-12-08 18:18:12','3023f7f9-554a-46e9-9935-97c07a88fff7'),
	(81,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-08 20:07:34','2020-12-08 20:07:34','e7317a4f-e49a-4586-8f86-750d37fe8948'),
	(83,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 00:07:30','2020-12-09 00:07:30','e7793d32-a243-486a-8190-dbd8c9f6abe9'),
	(86,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 07:28:39','2020-12-09 07:28:39','e0c6a1a2-5ecf-4149-82fc-9816267b886b'),
	(89,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 07:38:03','2020-12-09 07:38:03','9ede1035-ea4f-4949-97e7-236e34e1895f'),
	(92,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 08:06:36','2020-12-09 08:06:36','5d657528-370b-443f-a5de-e2eaf3e44044'),
	(94,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 08:07:13','2020-12-09 08:07:13','a1783b28-4917-4857-ab6d-534d3c9b1260'),
	(100,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 08:10:35','2020-12-09 08:10:35','f30f18bc-dc94-4ec0-a002-797a3012022f'),
	(109,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 18:47:32','2020-12-09 18:47:32','022c244e-befc-4902-8e65-d4c246b37060'),
	(118,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 19:08:12','2020-12-09 19:08:12','c2289fe5-660f-40c9-a484-428e92a5400d'),
	(128,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 19:11:12','2020-12-09 19:11:12','b4be2913-6827-484a-b478-ba5d652b2360'),
	(138,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 22:32:48','2020-12-09 22:32:48','366ed02d-142a-4254-8377-a8756a3175c8'),
	(148,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 22:35:36','2020-12-09 22:35:36','287b8fc9-de2e-45c5-a293-b15e21d90053'),
	(158,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 22:50:38','2020-12-09 22:50:38','9e02521c-ffb4-4e5f-bb18-a4ec1c176f51'),
	(169,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 22:56:06','2020-12-09 22:56:06','51cbb4e2-b490-4eaf-9f3b-17952c14a691'),
	(180,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 23:01:03','2020-12-09 23:01:03','b40ea28c-25c5-4d74-9e5d-ea975fee21e0'),
	(191,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 23:18:20','2020-12-09 23:18:20','7fd2bc82-a1eb-4857-8468-fee2ebbaf4e2'),
	(202,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 23:20:49','2020-12-09 23:20:49','3062ccc3-2bbd-4864-8991-8f9986cb0b2a'),
	(213,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-09 23:58:21','2020-12-09 23:58:21','a0bda937-a5e6-491f-ba96-34d74948ac0c'),
	(225,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-10 00:00:08','2020-12-10 00:00:08','f4a357cf-f524-4336-8527-1be746db3f57'),
	(237,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-10 00:08:00','2020-12-10 00:08:00','c7c49510-2fe6-412f-bd9d-eecf461c9075'),
	(249,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-10 00:31:34','2020-12-10 00:31:34','1d9fd723-ce0b-4882-b9c1-9c9460b9ce39'),
	(258,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-10 00:33:07','2020-12-10 00:33:07','95068166-939e-483a-bf6f-fe4dede41d3c'),
	(267,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-10 00:34:13','2020-12-10 00:34:13','f2019477-5c58-404a-bc32-57eb1bafa31c'),
	(272,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-10 00:34:53','2020-12-10 00:34:53','36133ac2-e4e3-4a75-9441-d6c73f39a5b8'),
	(277,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-14 23:15:24','2020-12-14 23:15:24','1c54c34a-eb02-4165-bd4e-f53a10fc94c0'),
	(282,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-16 06:04:29','2020-12-16 06:04:29','f662b352-6b97-4783-a72a-335020d25ddb'),
	(287,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-16 06:05:08','2020-12-16 06:05:08','08784519-08c0-44bc-88d3-5be728f65614'),
	(292,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-16 06:13:57','2020-12-16 06:13:57','15f57dbe-d650-45ba-9b3f-a5a0c9ad453e'),
	(297,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-16 12:18:09','2020-12-16 12:18:09','f94ffa28-21d9-4e60-bc7e-fb479804a718'),
	(302,2,NULL,2,NULL,'2020-12-07 08:31:00',NULL,NULL,'2020-12-16 12:19:22','2020-12-16 12:19:22','f7bd1e8e-8c94-4cda-ad1d-36cfbfdab6f5');

/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table entrytypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `entrytypes`;

CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entrytypes_name_sectionId_idx` (`name`,`sectionId`),
  KEY `entrytypes_handle_sectionId_idx` (`handle`,`sectionId`),
  KEY `entrytypes_sectionId_idx` (`sectionId`),
  KEY `entrytypes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `entrytypes_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `entrytypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `entrytypes_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;

INSERT INTO `entrytypes` (`id`, `sectionId`, `fieldLayoutId`, `name`, `handle`, `hasTitleField`, `titleTranslationMethod`, `titleTranslationKeyFormat`, `titleFormat`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,1,6,'Blog','blog',1,'',NULL,'',1,'2020-12-07 08:31:19','2020-12-07 08:31:19',NULL,'bb6d289b-c3cf-4a8d-9324-b98cbd32753b'),
	(2,2,7,'Home','home',0,'',NULL,'{section.name|raw}',1,'2020-12-07 08:31:20','2020-12-07 08:31:20',NULL,'8518a799-a012-4a6c-aa89-6a347cc00c2e'),
	(3,3,8,'About','about',0,'',NULL,'{section.name|raw}',1,'2020-12-07 08:31:20','2020-12-07 08:31:20',NULL,'dbd1be32-5e0d-4483-92a5-cc47aba67dcc'),
	(4,4,10,'Packages','packages',1,'site',NULL,NULL,1,'2020-12-08 09:39:43','2020-12-09 07:19:39',NULL,'e4ada667-7f26-4d24-95f6-a2576ecade28');

/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table fieldgroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fieldgroups`;

CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldgroups_name_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;

INSERT INTO `fieldgroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'Common','2020-12-07 08:31:18','2020-12-07 08:31:18','911477c7-3c92-407b-a9a9-e69ccb74eabb');

/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table fieldlayoutfields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fieldlayoutfields`;

CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fieldlayoutfields_layoutId_fieldId_unq_idx` (`layoutId`,`fieldId`),
  KEY `fieldlayoutfields_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayoutfields_tabId_idx` (`tabId`),
  KEY `fieldlayoutfields_fieldId_idx` (`fieldId`),
  CONSTRAINT `fieldlayoutfields_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fieldlayoutfields_tabId_fk` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;

INSERT INTO `fieldlayoutfields` (`id`, `layoutId`, `tabId`, `fieldId`, `required`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(10,6,6,1,0,1,'2020-12-07 08:31:19','2020-12-07 08:31:19','6207c524-f02d-4984-94a7-8be10ee272e0'),
	(11,6,6,2,0,2,'2020-12-07 08:31:19','2020-12-07 08:31:19','e7196fd8-c4a7-4aeb-acdf-471c3f88b78a'),
	(12,1,7,4,0,0,'2020-12-07 08:31:19','2020-12-07 08:31:19','a6abf9ea-6419-4d9b-99d9-ef87172ff6f0'),
	(13,1,7,3,0,1,'2020-12-07 08:31:19','2020-12-07 08:31:19','ae2d86e2-2e85-46c5-bfc4-7e6a8925bdb0'),
	(15,8,9,2,0,1,'2020-12-07 08:31:20','2020-12-07 08:31:20','02e338ff-2fbc-4c7e-bbf2-f685df566f00'),
	(62,10,34,18,0,1,'2020-12-09 07:19:39','2020-12-09 07:19:39','7f431e32-0aef-4109-bb76-65e8e0958cdf'),
	(63,10,34,19,0,2,'2020-12-09 07:19:39','2020-12-09 07:19:39','8a963985-29ed-4c26-9c4b-126c5fac092f'),
	(64,10,34,2,0,3,'2020-12-09 07:19:39','2020-12-09 07:19:39','d4d1213c-7588-44b3-8b50-91d5e5873f65'),
	(65,10,34,20,0,4,'2020-12-09 07:19:39','2020-12-09 07:19:39','9665de26-cb10-432c-b020-2a7eaf932795'),
	(150,15,75,29,0,0,'2020-12-09 23:48:06','2020-12-09 23:48:06','a77c1e77-b241-4d2d-a684-98ae0cace8c8'),
	(151,15,75,30,0,1,'2020-12-09 23:48:06','2020-12-09 23:48:06','e55b24ad-40e7-4b1a-8899-35829ac16bb4'),
	(152,15,75,31,0,2,'2020-12-09 23:48:06','2020-12-09 23:48:06','8f20a211-43c0-49f5-bdb1-02e71e143f87'),
	(153,16,76,33,0,0,'2020-12-09 23:49:00','2020-12-09 23:49:00','e295145c-edfe-4eb1-aa1d-f0fc21984d09'),
	(154,16,76,34,0,1,'2020-12-09 23:49:00','2020-12-09 23:49:00','d4048c57-850c-450a-805b-314c61f1e3b5'),
	(155,16,76,35,0,2,'2020-12-09 23:49:00','2020-12-09 23:49:00','89a08364-3c30-48c9-9d4d-402582a73d96'),
	(156,16,76,36,0,3,'2020-12-09 23:49:00','2020-12-09 23:49:00','b78c2b3e-d020-45ba-a5d4-865ff2258934'),
	(157,16,76,37,0,4,'2020-12-09 23:49:00','2020-12-09 23:49:00','029f55dd-16e5-45ff-b40b-8a0dc645e4bc'),
	(167,17,79,43,0,0,'2020-12-10 00:06:13','2020-12-10 00:06:13','5ec05319-4d53-48c2-8e6a-f21062d21784'),
	(168,17,79,42,0,1,'2020-12-10 00:06:13','2020-12-10 00:06:13','5e26b286-896e-4333-9d72-de0fbc7537b8'),
	(169,17,79,40,0,2,'2020-12-10 00:06:13','2020-12-10 00:06:13','90406cc5-8e9a-4701-b4cb-91a4e7f29423'),
	(170,17,79,39,0,3,'2020-12-10 00:06:13','2020-12-10 00:06:13','bf3f1aea-65e8-4e9e-8410-1de39b997d38'),
	(171,17,79,41,0,4,'2020-12-10 00:06:13','2020-12-10 00:06:13','1039e17f-5ad8-465d-817a-65511227d477'),
	(172,2,80,6,0,0,'2020-12-10 00:18:25','2020-12-10 00:18:25','6e63f247-ca59-4937-b6c2-8593b41cf1b5'),
	(173,5,81,12,0,0,'2020-12-10 00:18:26','2020-12-10 00:18:26','0abd3448-de69-421b-bb19-b22a5afbba70'),
	(174,5,81,10,0,1,'2020-12-10 00:18:26','2020-12-10 00:18:26','c2428999-f18e-4ca2-be20-4f895232c55c'),
	(175,5,81,11,0,2,'2020-12-10 00:18:26','2020-12-10 00:18:26','676a62ee-0e32-450e-9c5a-c44822da2532'),
	(176,3,82,8,0,0,'2020-12-10 00:18:26','2020-12-10 00:18:26','c96f4407-888f-41b2-af68-6187275d2ea4'),
	(177,3,82,7,0,1,'2020-12-10 00:18:26','2020-12-10 00:18:26','761d6198-56e7-4593-930f-9b7379762dbf'),
	(178,9,83,14,0,0,'2020-12-10 00:18:26','2020-12-10 00:18:26','8095821c-ad3b-4558-a337-47a17eaf34a4'),
	(179,9,83,13,0,1,'2020-12-10 00:18:26','2020-12-10 00:18:26','a4837323-f714-4b30-8ab5-e4d5e95e8fed'),
	(180,9,83,17,0,2,'2020-12-10 00:18:26','2020-12-10 00:18:26','2a0a0eb1-0743-4e45-9063-a06909ee3b56'),
	(181,4,84,9,1,0,'2020-12-10 00:18:26','2020-12-10 00:18:26','877fadac-7f04-42fb-9bc6-9867c705cf46'),
	(182,18,85,45,0,0,'2020-12-10 00:23:05','2020-12-10 00:23:05','364c9c40-43be-4f97-991a-83ca479aca7c'),
	(183,18,85,46,0,1,'2020-12-10 00:23:05','2020-12-10 00:23:05','588a623a-88f1-43e0-ae71-565a019ac736'),
	(184,7,86,28,0,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','c2a8195c-22bc-4272-bc14-283a5009dcfc'),
	(185,7,86,32,0,2,'2020-12-10 00:31:34','2020-12-10 00:31:34','aa8f5177-27ee-4da7-8698-f17cfa5e0a66'),
	(186,7,86,38,0,3,'2020-12-10 00:31:34','2020-12-10 00:31:34','2ba07a1d-22bd-4574-8c9c-1deb3aebadd0'),
	(187,7,86,44,0,4,'2020-12-10 00:31:34','2020-12-10 00:31:34','7b2fb3cc-8b0e-4626-b838-28b872add91e'),
	(188,7,86,2,0,5,'2020-12-10 00:31:34','2020-12-10 00:31:34','f0a2ba85-ac82-4a80-8f6d-ddd9e3f24832');

/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table fieldlayouts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fieldlayouts`;

CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouts_dateDeleted_idx` (`dateDeleted`),
  KEY `fieldlayouts_type_idx` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;

INSERT INTO `fieldlayouts` (`id`, `type`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,'craft\\elements\\Asset','2020-12-07 08:31:18','2020-12-07 08:31:18',NULL,'f6203211-ad03-49ec-8423-3d215898f508'),
	(2,'craft\\elements\\MatrixBlock','2020-12-07 08:31:18','2020-12-07 08:31:18',NULL,'59ffc94b-a1a3-4ecb-98e4-67dbd4317f23'),
	(3,'craft\\elements\\MatrixBlock','2020-12-07 08:31:19','2020-12-07 08:31:19',NULL,'d0baa120-b528-4317-a11e-0a36f80501c3'),
	(4,'craft\\elements\\MatrixBlock','2020-12-07 08:31:19','2020-12-07 08:31:19',NULL,'edfa3f3b-4e3a-4aa8-959c-95de3a10409d'),
	(5,'craft\\elements\\MatrixBlock','2020-12-07 08:31:19','2020-12-07 08:31:19',NULL,'e25f5116-982d-45a0-ac12-9d3a3f1d07e7'),
	(6,'craft\\elements\\Entry','2020-12-07 08:31:19','2020-12-07 08:31:19',NULL,'abfbb4c4-848b-4bbb-a8ab-fa5edb8941b6'),
	(7,'craft\\elements\\Entry','2020-12-07 08:31:20','2020-12-07 08:31:20',NULL,'434b8bff-3f8f-4c04-b4e1-43001b019d73'),
	(8,'craft\\elements\\Entry','2020-12-07 08:31:20','2020-12-07 08:31:20',NULL,'0476a59c-d8e9-40fd-bce3-4ba321daf851'),
	(9,'craft\\elements\\MatrixBlock','2020-12-07 08:31:21','2020-12-07 08:31:21',NULL,'a3b39778-708a-4de0-9501-6b1d37108919'),
	(10,'craft\\elements\\Entry','2020-12-08 09:39:43','2020-12-08 09:39:43',NULL,'6e08a29d-0e72-41b4-aac3-6b49a25d15eb'),
	(11,'craft\\elements\\MatrixBlock','2020-12-09 07:49:08','2020-12-09 07:49:08','2020-12-10 00:16:06','7124170b-d080-4468-8fe4-5d9089124451'),
	(12,'craft\\elements\\MatrixBlock','2020-12-09 07:49:08','2020-12-09 07:49:08','2020-12-10 00:16:07','5d7c2a31-49be-4cc1-bc1c-924b337a1eb6'),
	(13,'craft\\elements\\MatrixBlock','2020-12-09 07:53:14','2020-12-09 07:53:14','2020-12-10 00:16:07','d586a0bd-a08c-4c71-89d1-e3179ce100e5'),
	(14,'craft\\elements\\MatrixBlock','2020-12-09 07:57:38','2020-12-09 07:57:38','2020-12-10 00:16:07','9a2998cd-7deb-448d-8681-469edf5af022'),
	(15,'craft\\elements\\MatrixBlock','2020-12-09 19:05:30','2020-12-09 19:05:30',NULL,'23a9ec3b-ec1c-4293-b023-67ae43be1cf8'),
	(16,'craft\\elements\\MatrixBlock','2020-12-09 22:45:12','2020-12-09 22:45:12',NULL,'39a13f9e-7e80-42aa-8e46-bf24fca50aed'),
	(17,'craft\\elements\\MatrixBlock','2020-12-09 23:57:41','2020-12-09 23:57:41',NULL,'e12e54fd-ab49-4e27-b342-ce149c61d1c3'),
	(18,'craft\\elements\\MatrixBlock','2020-12-10 00:23:05','2020-12-10 00:23:05',NULL,'4c830e39-6813-460b-b225-d6b17d860ea7');

/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table fieldlayouttabs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fieldlayouttabs`;

CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `elements` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fieldlayouttabs_sortOrder_idx` (`sortOrder`),
  KEY `fieldlayouttabs_layoutId_idx` (`layoutId`),
  CONSTRAINT `fieldlayouttabs_layoutId_fk` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;

INSERT INTO `fieldlayouttabs` (`id`, `layoutId`, `name`, `elements`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(6,6,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":\"Title\",\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"5e76b2e3-1eae-4bbc-93f4-122fe4526b02\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"e567b6ab-3855-452b-a337-4c119dac4d62\"}]',1,'2020-12-07 08:31:19','2020-12-07 08:31:19','2bca7f3c-50b4-4ddd-93f7-97bbe4864da9'),
	(7,1,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"cdd377e5-a451-46b0-ae80-bc4cee907d3e\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"db95de40-4dec-44cc-9d17-bba2223c91cf\"}]',1,'2020-12-07 08:31:19','2020-12-07 08:31:19','11f86d00-370d-4c56-bc00-aa69dc813fec'),
	(9,8,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":\"\",\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"e567b6ab-3855-452b-a337-4c119dac4d62\"}]',1,'2020-12-07 08:31:20','2020-12-07 08:31:20','162dec9c-6700-43e7-9c96-c1a4fced22f9'),
	(34,10,'Package Details','[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":\"Package Name\",\"instructions\":\"\",\"tip\":null,\"warning\":null,\"width\":100},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":\"Package Intro\",\"instructions\":\"\",\"tip\":null,\"warning\":null,\"required\":\"\",\"width\":100,\"fieldUid\":\"baf92585-f5fa-4c8f-b0c1-bdf44702738a\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":\"Packages Copy\",\"instructions\":\"\",\"tip\":null,\"warning\":null,\"required\":\"\",\"width\":100,\"fieldUid\":\"967c78dc-e17a-4909-a832-9f5151b2332c\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":\"Package Content\",\"instructions\":\"\",\"tip\":null,\"warning\":null,\"required\":\"\",\"width\":100,\"fieldUid\":\"e567b6ab-3855-452b-a337-4c119dac4d62\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":\"Package Image\",\"instructions\":\"\",\"tip\":null,\"warning\":null,\"required\":\"\",\"width\":100,\"fieldUid\":\"f1609569-63ed-461e-a6dd-ef9bd55265cd\"}]',1,'2020-12-09 07:19:39','2020-12-09 07:19:39','66c7c8cd-3430-451c-8cc4-098ef7a315b9'),
	(56,11,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"40289482-0e35-4a25-a1ce-3dfdb83e92bd\"}]',1,'2020-12-09 08:05:20','2020-12-09 08:05:20','f3ff7a76-9889-42f8-a588-8a31c527173d'),
	(57,12,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"adb830ad-7249-4de3-8489-3fb7c6d976e4\"}]',1,'2020-12-09 08:05:20','2020-12-09 08:05:20','fc343e36-f51f-403c-87e5-2e4dcb9b2460'),
	(58,13,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"4d90dc28-85bb-45e1-8596-71a19eec1c3b\"}]',1,'2020-12-09 08:05:20','2020-12-09 08:05:20','20827baa-1818-4bbd-b3ad-bf6ffe877fc6'),
	(59,14,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"6fa59cba-f1c1-4f28-a62b-2ed00ae0f06c\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"0bda79dd-9c0c-4cce-8489-6fe59120a19f\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"e5e21daf-16c6-4435-91a8-65c5645475b5\"}]',1,'2020-12-09 08:05:20','2020-12-09 08:05:20','86081382-7c7b-4bfd-8d4b-eedb428b5bc0'),
	(75,15,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"3d69ecc2-ebfc-4738-bf23-e680f804b116\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"f3ade68f-0542-4f6c-afbf-1a7a9d628b75\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2\"}]',1,'2020-12-09 23:48:06','2020-12-09 23:48:06','1393aae1-d4fe-48e4-8f84-10ca065f18c2'),
	(76,16,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"cbf2ec30-a090-4597-8978-83fec9be0363\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"50d7c69d-2fa8-428c-b8be-c9727158fe13\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"4b552e7e-8127-494a-89a3-579eeaadcd70\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"d29ea691-1c48-450b-b491-ebe48ca11f64\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"b1858648-d1e3-4189-9f41-9d1f6ce73132\"}]',1,'2020-12-09 23:49:00','2020-12-09 23:49:00','0b253522-7bdd-4d93-8842-2d85bae6a666'),
	(79,17,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"51c7d4c0-45da-4471-bdce-4a8e18dc2e96\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"3a5512ac-b907-450c-badc-45ad3c3b901e\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"62a1a784-5e65-4837-94bf-a4738d632822\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"0041e888-c18e-4ebb-ac05-be517a26ed9e\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"b0249c07-1a4f-4d4f-b948-73106f7ebb2e\"}]',1,'2020-12-10 00:06:13','2020-12-10 00:06:13','c77b391d-ed60-4650-8a6b-4784b2ab5e0f'),
	(80,2,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"df3a27ff-e318-422f-8ff5-d626eda8ce54\"}]',1,'2020-12-10 00:18:25','2020-12-10 00:18:25','f29ecd52-70d5-46fa-8491-39e094b2d335'),
	(81,5,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"a6ca7d80-fa7f-433b-b6ba-fd9f19791f82\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"09c265f3-2ab1-405d-9111-108e6b54f0fb\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb\"}]',1,'2020-12-10 00:18:26','2020-12-10 00:18:26','5b4341c3-0d89-49bb-a7b8-100820fbec3b'),
	(82,3,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"6b203fd7-eca1-4313-8795-efbb5f6a8e63\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"5d2372e2-c220-4af4-80c9-49bb8c85a92e\"}]',1,'2020-12-10 00:18:26','2020-12-10 00:18:26','e3b2c479-5acb-4c03-8672-d8d6f2f19ce2'),
	(83,9,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"a6f02aa5-ab37-46e2-bbd4-3b56930577d5\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"2f6bf496-df01-42e0-9b77-a764f886813d\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"b18e27a7-8264-41c8-9914-70b37afe1e37\"}]',1,'2020-12-10 00:18:26','2020-12-10 00:18:26','f140767f-49e8-4244-a35a-14c9e76c8d7f'),
	(84,4,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"fieldUid\":\"e8fdd2ad-6739-4bab-a689-8a422e18a8f4\"}]',1,'2020-12-10 00:18:26','2020-12-10 00:18:26','dcf3f985-78dd-459f-b145-ebff79bb64a2'),
	(85,18,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"36c68627-dc00-4d86-a012-7482704054a9\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969\"}]',1,'2020-12-10 00:23:05','2020-12-10 00:23:05','a8e6bbda-2f38-40ee-bebf-ff07090e1e31'),
	(86,7,'Content','[{\"type\":\"craft\\\\fieldlayoutelements\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":\"\",\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":\"Hero\",\"instructions\":\"\",\"tip\":null,\"warning\":null,\"required\":\"\",\"width\":100,\"fieldUid\":\"5b3791ab-899f-4db6-b8d9-912a0aa18d87\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"5078004c-4379-4cfc-8931-f386cbe3dbbc\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"2f2878ed-1f33-4e42-a96d-66215377c511\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"d8a19f7f-5bcc-4035-89a4-c0b3befd9f96\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"fieldUid\":\"e567b6ab-3855-452b-a337-4c119dac4d62\"}]',1,'2020-12-10 00:31:34','2020-12-10 00:31:34','ac19ffaa-338c-4819-8848-ac394d44e0f8');

/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table fields
# ------------------------------------------------------------

DROP TABLE IF EXISTS `fields`;

CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fields_handle_context_idx` (`handle`,`context`),
  KEY `fields_groupId_idx` (`groupId`),
  KEY `fields_context_idx` (`context`),
  CONSTRAINT `fields_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;

INSERT INTO `fields` (`id`, `groupId`, `name`, `handle`, `context`, `instructions`, `searchable`, `translationMethod`, `translationKeyFormat`, `type`, `settings`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,'Summary','summary','global','Summary for the blog index',1,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"\",\"cleanupHtml\":true,\"columnType\":\"text\",\"purifierConfig\":\"\",\"purifyHtml\":\"1\",\"redactorConfig\":\"\",\"removeEmptyTags\":\"1\",\"removeInlineStyles\":\"1\",\"removeNbsp\":\"1\"}','2020-12-07 08:31:18','2020-12-07 08:31:18','5e76b2e3-1eae-4bbc-93f4-122fe4526b02'),
	(2,1,'Body Content','bodyContent','global','',1,'site',NULL,'craft\\fields\\Matrix','{\"contentTable\":\"{{%matrixcontent_bodycontent}}\",\"maxBlocks\":\"\",\"minBlocks\":\"\",\"propagationMethod\":\"all\"}','2020-12-07 08:31:18','2020-12-07 08:31:18','e567b6ab-3855-452b-a337-4c119dac4d62'),
	(3,1,'Image Alt','imageAlt','global','Optional text for the `<img>` tag `alt` attribute.',1,'none',NULL,'craft\\fields\\PlainText','{\"charLimit\":\"\",\"code\":\"\",\"columnType\":\"text\",\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\"}','2020-12-07 08:31:18','2020-12-07 08:31:18','db95de40-4dec-44cc-9d17-bba2223c91cf'),
	(4,1,'Caption','caption','global','',1,'none',NULL,'craft\\fields\\PlainText','{\"charLimit\":\"\",\"code\":\"\",\"columnType\":\"text\",\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\"}','2020-12-07 08:31:18','2020-12-07 08:31:18','cdd377e5-a451-46b0-ae80-bc4cee907d3e'),
	(6,NULL,'Rich Text','richText','matrixBlockType:0c98f9b9-84bf-4766-af63-a3568b46c0a6','',1,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"cleanupHtml\":true,\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":\"\",\"purifyHtml\":\"1\",\"redactorConfig\":\"Standard.json\",\"removeEmptyTags\":\"1\",\"removeInlineStyles\":\"1\",\"removeNbsp\":\"1\",\"showHtmlButtonForNonAdmins\":\"1\",\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":true,\"uiMode\":\"enlarged\"}','2020-12-07 08:31:18','2020-12-07 20:13:17','df3a27ff-e318-422f-8ff5-d626eda8ce54'),
	(7,NULL,'Position','position','matrixBlockType:28d5c036-8cb0-4a14-b553-0167ee34efbe','',1,'none',NULL,'craft\\fields\\Dropdown','{\"optgroups\":true,\"options\":[{\"label\":\"Wide\",\"value\":\"wide\",\"default\":\"1\"},{\"label\":\"Center\",\"value\":\"center\",\"default\":\"\"},{\"label\":\"Left\",\"value\":\"left\",\"default\":\"\"},{\"label\":\"Right\",\"value\":\"right\",\"default\":\"\"}]}','2020-12-07 08:31:18','2020-12-07 20:13:18','5d2372e2-c220-4af4-80c9-49bb8c85a92e'),
	(8,NULL,'Image','image','matrixBlockType:28d5c036-8cb0-4a14-b553-0167ee34efbe','Double-click the image thumbnail to apply a caption to an image.',1,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"defaultUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"defaultUploadLocationSubpath\":\"\",\"limit\":\"1\",\"localizeRelations\":false,\"previewMode\":\"full\",\"restrictFiles\":\"1\",\"selectionLabel\":\"Add an image\",\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":true,\"singleUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"singleUploadLocationSubpath\":\"\",\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"useSingleFolder\":false,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2020-12-07 08:31:19','2020-12-10 00:18:26','6b203fd7-eca1-4313-8795-efbb5f6a8e63'),
	(9,NULL,'Embed','embed','matrixBlockType:fb2f8912-57ad-4b4e-887d-e55f22a6d348','',0,'none',NULL,'wrav\\oembed\\fields\\OembedField','{\"url\":\"\"}','2020-12-07 08:31:19','2020-12-07 08:31:19','e8fdd2ad-6739-4bab-a689-8a422e18a8f4'),
	(10,NULL,'Quote','quote','matrixBlockType:a121b8e6-70e6-421b-9629-c664d2949934','',1,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"cleanupHtml\":true,\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":\"\",\"purifyHtml\":\"1\",\"redactorConfig\":\"Simple.json\",\"removeEmptyTags\":\"1\",\"removeInlineStyles\":\"1\",\"removeNbsp\":\"1\",\"showHtmlButtonForNonAdmins\":\"1\",\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":true,\"uiMode\":\"enlarged\"}','2020-12-07 08:31:19','2020-12-07 20:13:17','09c265f3-2ab1-405d-9111-108e6b54f0fb'),
	(11,NULL,'Attribution','attribution','matrixBlockType:a121b8e6-70e6-421b-9629-c664d2949934','',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":\"text\",\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2020-12-07 08:31:19','2020-12-07 20:13:17','5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb'),
	(12,NULL,'Style','style','matrixBlockType:a121b8e6-70e6-421b-9629-c664d2949934','',1,'none',NULL,'craft\\fields\\Dropdown','{\"optgroups\":true,\"options\":[{\"label\":\"Blockquote\",\"value\":\"blockquote\",\"default\":\"1\"},{\"label\":\"Pullquote\",\"value\":\"pullquote\",\"default\":\"\"}]}','2020-12-07 08:31:19','2020-12-07 20:13:17','a6ca7d80-fa7f-433b-b6ba-fd9f19791f82'),
	(13,NULL,'Aspect Ratio','aspectRatio','matrixBlockType:7e401ee6-3575-42de-b3b4-cedae706f392','',1,'none',NULL,'craft\\fields\\Dropdown','{\"optgroups\":true,\"options\":[{\"label\":\"16:9\",\"value\":\"16:9\",\"default\":\"1\"},{\"label\":\"4:3\",\"value\":\"4:3\",\"default\":\"\"},{\"label\":\"3:2\",\"value\":\"3:2\",\"default\":\"\"}]}','2020-12-07 08:31:21','2020-12-07 20:13:18','2f6bf496-df01-42e0-9b77-a764f886813d'),
	(14,NULL,'Images','images','matrixBlockType:7e401ee6-3575-42de-b3b4-cedae706f392','Double-click an image thumbnail to apply a caption to an image.',1,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"defaultUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"defaultUploadLocationSubpath\":\"images\",\"limit\":\"\",\"localizeRelations\":false,\"previewMode\":\"full\",\"restrictFiles\":\"1\",\"selectionLabel\":\"Add an image\",\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":true,\"singleUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"singleUploadLocationSubpath\":\"\",\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"useSingleFolder\":false,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2020-12-07 08:31:21','2020-12-07 20:13:18','a6f02aa5-ab37-46e2-bbd4-3b56930577d5'),
	(17,NULL,'Title','imagesTitle','matrixBlockType:7e401ee6-3575-42de-b3b4-cedae706f392','Enter Title',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2020-12-07 20:13:18','2020-12-07 20:13:18','b18e27a7-8264-41c8-9914-70b37afe1e37'),
	(18,1,'Introduction','introduction','global','Short text on top of section',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2020-12-08 09:50:56','2020-12-08 09:50:56','baf92585-f5fa-4c8f-b0c1-bdf44702738a'),
	(19,1,'Page Copy','pageCopy','global','',1,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"cleanupHtml\":true,\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":\"\",\"purifyHtml\":\"1\",\"redactorConfig\":\"Standard.json\",\"removeEmptyTags\":\"1\",\"removeInlineStyles\":\"1\",\"removeNbsp\":\"1\",\"showHtmlButtonForNonAdmins\":\"\",\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}','2020-12-08 09:53:11','2020-12-08 09:53:11','967c78dc-e17a-4909-a832-9f5151b2332c'),
	(20,1,'Image Pic','imagePic','global','',1,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowUploads\":true,\"allowedKinds\":null,\"defaultUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"defaultUploadLocationSubpath\":\"\",\"limit\":\"\",\"localizeRelations\":false,\"previewMode\":\"full\",\"restrictFiles\":\"\",\"selectionLabel\":\"\",\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"singleUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"singleUploadLocationSubpath\":\"\",\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"useSingleFolder\":false,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2020-12-08 18:15:40','2020-12-08 18:16:43','f1609569-63ed-461e-a6dd-ef9bd55265cd'),
	(28,1,'Hero','hero','global','',1,'site',NULL,'craft\\fields\\Matrix','{\"contentTable\":\"{{%matrixcontent_hero}}\",\"maxBlocks\":\"\",\"minBlocks\":\"\",\"propagationMethod\":\"all\"}','2020-12-09 19:05:30','2020-12-09 22:38:50','5b3791ab-899f-4db6-b8d9-912a0aa18d87'),
	(29,NULL,'images','images','matrixBlockType:b8af96bb-780f-4207-bd37-5975ec6038a3','Double-click an image thumbnail to apply a caption to an image.',1,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"defaultUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"defaultUploadLocationSubpath\":\"\",\"limit\":\"\",\"localizeRelations\":false,\"previewMode\":\"full\",\"restrictFiles\":\"1\",\"selectionLabel\":\"Add an image\",\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":true,\"singleUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"singleUploadLocationSubpath\":\"\",\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"useSingleFolder\":false,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2020-12-09 19:05:30','2020-12-09 19:06:49','3d69ecc2-ebfc-4738-bf23-e680f804b116'),
	(30,NULL,'Aspect Ratio','aspectRatio','matrixBlockType:b8af96bb-780f-4207-bd37-5975ec6038a3','',1,'none',NULL,'craft\\fields\\Dropdown','{\"optgroups\":true,\"options\":[{\"label\":\"16:9\",\"value\":\"169\",\"default\":\"\"},{\"label\":\"4:3\",\"value\":\"43\",\"default\":\"\"},{\"label\":\"3:2\",\"value\":\"32\",\"default\":\"\"},{\"label\":\"2:5\",\"value\":\"13\",\"default\":\"1\"}]}','2020-12-09 19:05:30','2020-12-09 22:16:30','f3ade68f-0542-4f6c-afbf-1a7a9d628b75'),
	(31,NULL,'Title','imagesTitle','matrixBlockType:b8af96bb-780f-4207-bd37-5975ec6038a3','Enter Title',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2020-12-09 19:06:49','2020-12-09 19:06:49','1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2'),
	(32,1,'Listing','listing','global','',1,'site',NULL,'craft\\fields\\Matrix','{\"contentTable\":\"{{%matrixcontent_listing}}\",\"maxBlocks\":\"\",\"minBlocks\":\"\",\"propagationMethod\":\"all\"}','2020-12-09 22:45:12','2020-12-09 22:45:12','5078004c-4379-4cfc-8931-f386cbe3dbbc'),
	(33,NULL,'images','images','matrixBlockType:73224dba-c124-4f91-9f5a-de0bb4843c02','Double-click an image thumbnail to apply a caption to an image.',1,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowUploads\":true,\"allowedKinds\":[\"html\",\"image\"],\"defaultUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"defaultUploadLocationSubpath\":\"\",\"limit\":\"\",\"localizeRelations\":false,\"previewMode\":\"full\",\"restrictFiles\":\"1\",\"selectionLabel\":\"Add an icon\",\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":true,\"singleUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"singleUploadLocationSubpath\":\"\",\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"useSingleFolder\":false,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2020-12-09 22:45:12','2020-12-09 22:46:48','cbf2ec30-a090-4597-8978-83fec9be0363'),
	(34,NULL,'Aspect Ratio','aspectRatio','matrixBlockType:73224dba-c124-4f91-9f5a-de0bb4843c02','',0,'none',NULL,'craft\\fields\\Dropdown','{\"optgroups\":true,\"options\":[{\"label\":\"16:9\",\"value\":\"169\",\"default\":\"1\"},{\"label\":\"4:3\",\"value\":\"43\",\"default\":\"\"},{\"label\":\"3:2\",\"value\":\"32\",\"default\":\"\"},{\"label\":\"2:5\",\"value\":\"25\",\"default\":\"\"}]}','2020-12-09 22:46:48','2020-12-09 22:46:48','50d7c69d-2fa8-428c-b8be-c9727158fe13'),
	(35,NULL,'Listing Title','listingTitle','matrixBlockType:73224dba-c124-4f91-9f5a-de0bb4843c02','Enter Title',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2020-12-09 22:48:02','2020-12-09 22:48:02','4b552e7e-8127-494a-89a3-579eeaadcd70'),
	(36,NULL,'Listing Copy','listingCopy','matrixBlockType:73224dba-c124-4f91-9f5a-de0bb4843c02','Enter Copy',0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"cleanupHtml\":true,\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":\"\",\"purifyHtml\":\"1\",\"redactorConfig\":\"\",\"removeEmptyTags\":\"1\",\"removeInlineStyles\":\"1\",\"removeNbsp\":\"1\",\"showHtmlButtonForNonAdmins\":\"1\",\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":true,\"uiMode\":\"enlarged\"}','2020-12-09 22:49:34','2020-12-09 22:49:34','d29ea691-1c48-450b-b491-ebe48ca11f64'),
	(37,NULL,'Listing Image','listingImage','matrixBlockType:73224dba-c124-4f91-9f5a-de0bb4843c02','Double-click the image thumbnail to apply a caption to an image.',1,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"defaultUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"defaultUploadLocationSubpath\":\"\",\"limit\":\"\",\"localizeRelations\":false,\"previewMode\":\"full\",\"restrictFiles\":\"1\",\"selectionLabel\":\"Add an image\",\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":true,\"singleUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"singleUploadLocationSubpath\":\"\",\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"useSingleFolder\":false,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2020-12-09 23:17:16','2020-12-09 23:44:24','b1858648-d1e3-4189-9f41-9d1f6ce73132'),
	(38,1,'Cards','cards','global','',1,'site',NULL,'craft\\fields\\Matrix','{\"contentTable\":\"{{%matrixcontent_cards}}\",\"maxBlocks\":\"\",\"minBlocks\":\"\",\"propagationMethod\":\"all\"}','2020-12-09 23:57:41','2020-12-09 23:57:41','2f2878ed-1f33-4e42-a96d-66215377c511'),
	(39,NULL,'Aspect Ratio','aspectRatio','matrixBlockType:d9c7c085-cbae-4086-8b3f-04b598277c3e','',1,'none',NULL,'craft\\fields\\Dropdown','{\"optgroups\":true,\"options\":[{\"label\":\"16:9\",\"value\":\"169\",\"default\":\"\"},{\"label\":\"4:3\",\"value\":\"43\",\"default\":\"\"},{\"label\":\"3:2\",\"value\":\"32\",\"default\":\"\"},{\"label\":\"2:3\",\"value\":\"23\",\"default\":\"\"}]}','2020-12-09 23:57:41','2020-12-09 23:57:41','0041e888-c18e-4ebb-ac05-be517a26ed9e'),
	(40,NULL,'Images','images','matrixBlockType:d9c7c085-cbae-4086-8b3f-04b598277c3e','Double-click an image thumbnail to apply a caption to an image.',1,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"defaultUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"defaultUploadLocationSubpath\":\"\",\"limit\":\"\",\"localizeRelations\":false,\"previewMode\":\"full\",\"restrictFiles\":\"1\",\"selectionLabel\":\"Add an image\",\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":true,\"singleUploadLocationSource\":\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\",\"singleUploadLocationSubpath\":\"\",\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"useSingleFolder\":false,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2020-12-09 23:57:41','2020-12-10 00:06:13','62a1a784-5e65-4837-94bf-a4738d632822'),
	(41,NULL,'Button Label','buttonLabel','matrixBlockType:d9c7c085-cbae-4086-8b3f-04b598277c3e','',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"normal\"}','2020-12-09 23:57:41','2020-12-10 00:06:13','b0249c07-1a4f-4d4f-b948-73106f7ebb2e'),
	(42,NULL,'Cards Section','cardsSection','matrixBlockType:d9c7c085-cbae-4086-8b3f-04b598277c3e','',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"enlarged\"}','2020-12-10 00:06:13','2020-12-10 00:06:13','3a5512ac-b907-450c-badc-45ad3c3b901e'),
	(43,NULL,'Cards Title','cardsTitle','matrixBlockType:d9c7c085-cbae-4086-8b3f-04b598277c3e','',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"enlarged\"}','2020-12-10 00:06:13','2020-12-10 00:06:13','51c7d4c0-45da-4471-bdce-4a8e18dc2e96'),
	(44,1,'Centred Content','centredContent','global','',0,'site',NULL,'craft\\fields\\Matrix','{\"contentTable\":\"{{%matrixcontent_centredcontent}}\",\"maxBlocks\":\"\",\"minBlocks\":\"\",\"propagationMethod\":\"all\"}','2020-12-10 00:23:05','2020-12-10 00:23:05','d8a19f7f-5bcc-4035-89a4-c0b3befd9f96'),
	(45,NULL,'Centred Title','centredTitle','matrixBlockType:2f43fde9-8649-458c-ac99-490e41bf1f03','',1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":\"\",\"columnType\":null,\"initialRows\":\"4\",\"multiline\":\"\",\"placeholder\":\"\",\"uiMode\":\"enlarged\"}','2020-12-10 00:23:05','2020-12-10 00:23:05','36c68627-dc00-4d86-a012-7482704054a9'),
	(46,NULL,'Centred Copy','centredCopy','matrixBlockType:2f43fde9-8649-458c-ac99-490e41bf1f03','',0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"cleanupHtml\":true,\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":\"\",\"purifyHtml\":\"1\",\"redactorConfig\":\"\",\"removeEmptyTags\":\"1\",\"removeInlineStyles\":\"1\",\"removeNbsp\":\"1\",\"showHtmlButtonForNonAdmins\":\"1\",\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":true,\"uiMode\":\"enlarged\"}','2020-12-10 00:23:05','2020-12-10 00:23:05','4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969');

/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table globalsets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `globalsets`;

CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `globalsets_name_idx` (`name`),
  KEY `globalsets_handle_idx` (`handle`),
  KEY `globalsets_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `globalsets_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `globalsets_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table gqlschemas
# ------------------------------------------------------------

DROP TABLE IF EXISTS `gqlschemas`;

CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;

INSERT INTO `gqlschemas` (`id`, `name`, `scope`, `isPublic`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'Gatsby','[\"sections.5a80053a-6435-4fd2-8a47-53e409d994ad:read\",\"entrytypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc:read\",\"sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd:read\",\"entrytypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b:read\",\"sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5:read\",\"entrytypes.8518a799-a012-4a6c-aa89-6a347cc00c2e:read\",\"volumes.101a70a1-d200-4629-91e5-3425a0937c0e:read\",\"usergroups.everyone:read\",\"gatsby:read\"]',0,'2020-12-07 08:31:19','2020-12-07 08:31:19','55cd92b3-363e-4573-ad2c-04650483ba64'),
	(2,'Public Schema','[]',1,'2020-12-07 08:31:19','2020-12-07 08:31:19','265d76a5-d5a9-4c82-bee4-2f8450aacd0a');

/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table gqltokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `gqltokens`;

CREATE TABLE `gqltokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `gqltokens_accessToken_unq_idx` (`accessToken`),
  UNIQUE KEY `gqltokens_name_unq_idx` (`name`),
  KEY `gqltokens_schemaId_fk` (`schemaId`),
  CONSTRAINT `gqltokens_schemaId_fk` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;

INSERT INTO `gqltokens` (`id`, `name`, `accessToken`, `enabled`, `expiryDate`, `lastUsed`, `schemaId`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'Public Token','__PUBLIC__',1,NULL,NULL,2,'2020-12-07 08:31:21','2020-12-07 08:31:21','8bd363fd-6eef-45cf-9070-b15e36e86f45');

/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table info
# ------------------------------------------------------------

DROP TABLE IF EXISTS `info`;

CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;

INSERT INTO `info` (`id`, `version`, `schemaVersion`, `maintenance`, `configVersion`, `fieldVersion`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'3.5.16','3.5.13',0,'ugoxxwnzoqyr','iipdkzdzjlok','2020-12-07 08:31:17','2020-12-14 02:56:51','942a7e58-f063-4add-929e-d2ab3f16799b');

/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table matrixblocks
# ------------------------------------------------------------

DROP TABLE IF EXISTS `matrixblocks`;

CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `matrixblocks_ownerId_idx` (`ownerId`),
  KEY `matrixblocks_fieldId_idx` (`fieldId`),
  KEY `matrixblocks_typeId_idx` (`typeId`),
  KEY `matrixblocks_sortOrder_idx` (`sortOrder`),
  CONSTRAINT `matrixblocks_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_ownerId_fk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocks_typeId_fk` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;

INSERT INTO `matrixblocks` (`id`, `ownerId`, `fieldId`, `typeId`, `sortOrder`, `deletedWithOwner`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(24,3,2,2,1,NULL,'2020-12-07 19:56:43','2020-12-07 19:56:43','4b10d799-e529-4c8f-b180-85da79589515'),
	(25,3,2,5,2,NULL,'2020-12-07 19:56:43','2020-12-07 19:56:43','c9cc1805-9733-4874-a7d8-a07c97e7e455'),
	(27,26,2,2,1,NULL,'2020-12-07 19:56:43','2020-12-07 19:56:43','909a3706-30f6-412d-8a21-ebb9edcfe22f'),
	(28,26,2,5,2,NULL,'2020-12-07 19:56:43','2020-12-07 19:56:43','4ec92d24-9852-4ef5-864b-85cc5c8981c9'),
	(30,29,2,2,1,NULL,'2020-12-07 20:14:29','2020-12-07 20:14:29','ee2525bc-2a01-4d7c-adae-3fe32caae1f0'),
	(31,29,2,5,2,NULL,'2020-12-07 20:14:29','2020-12-07 20:14:29','4fbc100b-5de9-4f4c-ac1f-dbd457abe1d1'),
	(33,32,2,2,1,NULL,'2020-12-07 20:36:27','2020-12-07 20:36:27','699ea8be-65a9-4e99-8095-e21bbc340f55'),
	(34,32,2,5,2,NULL,'2020-12-07 20:36:27','2020-12-07 20:36:27','02e5bf64-0f60-4689-b50e-dece6a40e5af'),
	(42,1,2,5,1,0,'2020-12-08 08:19:55','2020-12-08 08:19:55','bec41b21-13ff-43a0-92f8-018cadc8894b'),
	(44,43,2,5,1,NULL,'2020-12-08 08:19:55','2020-12-08 08:19:55','e8bc43ae-1ed7-4304-a9b8-0a85ea9a42ed'),
	(46,45,2,5,1,NULL,'2020-12-08 08:20:21','2020-12-08 08:20:21','b05c9ee8-7828-4c88-aa87-0b71cb777b96'),
	(47,1,2,2,2,0,'2020-12-08 09:23:25','2020-12-08 09:23:25','7fa8e72d-5cf2-46ee-8224-24ddf23e8748'),
	(48,1,2,2,3,0,'2020-12-08 09:23:25','2020-12-08 09:23:25','22c128b3-e451-45eb-af88-0a1d660db82f'),
	(49,1,2,2,4,0,'2020-12-08 09:23:25','2020-12-08 09:23:25','f7392a1a-60a4-4c9c-9bc5-90f396011cec'),
	(51,50,2,5,1,NULL,'2020-12-08 09:23:25','2020-12-08 09:23:25','ecc3a189-a511-48c3-8309-492e6e9ad886'),
	(52,50,2,2,2,NULL,'2020-12-08 09:23:26','2020-12-08 09:23:26','a6e2d04a-0701-4d70-bc71-8e6368d90737'),
	(53,50,2,2,3,NULL,'2020-12-08 09:23:26','2020-12-08 09:23:26','ae363cbc-0df6-44bc-8d13-9dd719598d47'),
	(54,50,2,2,4,NULL,'2020-12-08 09:23:26','2020-12-08 09:23:26','2ee92ffd-8b9b-4984-9f8d-aba99c192f0d'),
	(66,64,2,2,1,NULL,'2020-12-08 18:08:38','2020-12-08 18:08:38','4ebf2028-9ee2-4024-aece-a54b404bbed1'),
	(68,67,2,2,1,NULL,'2020-12-08 18:08:38','2020-12-08 18:08:38','a46d3c4e-bba5-431f-a3eb-1552bc147d6c'),
	(69,61,2,2,1,NULL,'2020-12-08 18:09:16','2020-12-08 18:09:16','00a6ca72-a428-42ee-af2e-def75c4b1c2d'),
	(71,70,2,2,1,NULL,'2020-12-08 18:09:16','2020-12-08 18:09:16','5fc16983-299e-453a-98da-57ad52e46790'),
	(72,57,2,2,1,NULL,'2020-12-08 18:09:50','2020-12-08 18:09:50','e83b2762-b0ea-4ed1-bae5-1899057e8b7d'),
	(74,73,2,2,1,NULL,'2020-12-08 18:09:51','2020-12-08 18:09:51','1b30a74a-7706-439e-ace3-4929ca359d29'),
	(76,75,2,2,1,NULL,'2020-12-08 18:17:41','2020-12-08 18:17:41','8fb43499-d5bb-45f4-ae22-2bdcad537a23'),
	(78,77,2,2,1,NULL,'2020-12-08 18:17:56','2020-12-08 18:17:56','83ad5cd4-34b2-4e43-966c-3125998c9376'),
	(80,79,2,2,1,NULL,'2020-12-08 18:18:12','2020-12-08 18:18:12','a428d602-76d8-455a-aa72-781132b4d3ce'),
	(82,81,2,5,1,NULL,'2020-12-08 20:07:34','2020-12-08 20:07:34','be4dd310-5fa0-44dd-8d25-63091392be6d'),
	(84,83,2,5,1,NULL,'2020-12-09 00:07:30','2020-12-09 00:07:30','f2fecb0a-1771-4b2a-8849-8003a43d847b'),
	(85,1,2,5,2,0,'2020-12-09 07:28:39','2020-12-09 07:28:39','35831d65-9e31-4373-a694-0c2352b74f13'),
	(87,86,2,5,1,NULL,'2020-12-09 07:28:39','2020-12-09 07:28:39','b2af5db8-da3e-423d-9a2a-93e0977269b8'),
	(88,86,2,5,2,NULL,'2020-12-09 07:28:39','2020-12-09 07:28:39','1a98354b-e90e-4267-9d18-6377f7a72b1d'),
	(90,89,2,5,1,NULL,'2020-12-09 07:38:03','2020-12-09 07:38:03','92bd1d37-0167-48e8-a287-66c8c06c1e9b'),
	(91,89,2,5,2,NULL,'2020-12-09 07:38:03','2020-12-09 07:38:03','d8b9f4ab-2d9a-48ab-909e-b4905061448a'),
	(93,92,2,5,1,NULL,'2020-12-09 08:06:36','2020-12-09 08:06:36','34fd789d-0904-4e41-9054-487dea07b2b0'),
	(95,94,2,5,1,NULL,'2020-12-09 08:07:13','2020-12-09 08:07:13','c5f47b94-83b8-4ffa-aea7-42d986642f8f'),
	(101,100,2,5,1,NULL,'2020-12-09 08:10:35','2020-12-09 08:10:35','f644189b-a256-45f0-93ed-69143b7765d2'),
	(106,1,2,1,2,0,'2020-12-09 18:47:32','2020-12-09 18:47:32','de67bde9-e3e8-4a89-8d79-06857ff67305'),
	(107,1,2,4,3,0,'2020-12-09 18:47:32','2020-12-09 18:47:32','0c0b9794-22f4-4f2e-bf96-1e459d85b426'),
	(108,1,2,4,4,0,'2020-12-09 18:47:32','2020-12-09 18:47:32','bb92ae7b-798e-4f38-bb71-603847c38e5b'),
	(110,109,2,5,1,NULL,'2020-12-09 18:47:32','2020-12-09 18:47:32','1b665f91-ae7e-4994-a748-9c552ee8ada1'),
	(111,109,2,1,2,NULL,'2020-12-09 18:47:32','2020-12-09 18:47:32','e2343e53-c82d-4a23-a6d4-a401648686b3'),
	(112,109,2,4,3,NULL,'2020-12-09 18:47:32','2020-12-09 18:47:32','84f19553-1791-4e12-9835-fe4e9715dff7'),
	(113,109,2,4,4,NULL,'2020-12-09 18:47:32','2020-12-09 18:47:32','44134f1c-1d01-40e2-b75f-f2b0c4b40f8d'),
	(119,118,2,5,1,NULL,'2020-12-09 19:08:12','2020-12-09 19:08:12','584ba2bd-5015-4244-a1d5-7c0ee7415750'),
	(120,118,2,1,2,NULL,'2020-12-09 19:08:12','2020-12-09 19:08:12','20e8863b-9936-45eb-9997-4c92da728d7e'),
	(121,118,2,4,3,NULL,'2020-12-09 19:08:13','2020-12-09 19:08:13','7f76a0f0-afda-4a31-9a36-050bc70d6e15'),
	(122,118,2,4,4,NULL,'2020-12-09 19:08:13','2020-12-09 19:08:13','b0aa5097-a8df-4825-90e0-6a43763d7b39'),
	(127,1,28,10,1,NULL,'2020-12-09 19:11:11','2020-12-09 19:11:11','2dfb0e91-b52c-45bf-9e4e-3b055e6ff249'),
	(129,128,28,10,1,NULL,'2020-12-09 19:11:12','2020-12-09 19:11:12','e079d535-1296-436b-b175-71983a354dc7'),
	(130,128,2,5,1,NULL,'2020-12-09 19:11:12','2020-12-09 19:11:12','681b138c-9ec9-45b1-bc8d-a3d108282ff8'),
	(131,128,2,1,2,NULL,'2020-12-09 19:11:12','2020-12-09 19:11:12','3c77f590-c4dc-4987-8e7b-d8ef65ba0c46'),
	(132,128,2,4,3,NULL,'2020-12-09 19:11:12','2020-12-09 19:11:12','f6fb53b6-4499-45e5-8f14-e2d223020da6'),
	(133,128,2,4,4,NULL,'2020-12-09 19:11:12','2020-12-09 19:11:12','0e204ce9-a602-466f-8fcf-27df4f62b365'),
	(139,138,28,10,1,NULL,'2020-12-09 22:32:49','2020-12-09 22:32:49','9337e108-cadf-4fb4-b9c4-f155dc278f44'),
	(140,138,2,5,1,NULL,'2020-12-09 22:32:49','2020-12-09 22:32:49','babc57f5-695e-4c89-93fe-3f187846a3eb'),
	(141,138,2,1,2,NULL,'2020-12-09 22:32:49','2020-12-09 22:32:49','daafeab2-a954-4d7b-8cd1-9cbe2adbdf00'),
	(142,138,2,4,3,NULL,'2020-12-09 22:32:49','2020-12-09 22:32:49','3a2e0e6e-e592-4a15-86a7-23a693585666'),
	(143,138,2,4,4,NULL,'2020-12-09 22:32:49','2020-12-09 22:32:49','806b91b5-5bae-42c3-a39d-796a7833e601'),
	(149,148,28,10,1,NULL,'2020-12-09 22:35:36','2020-12-09 22:35:36','45edf62e-b59a-4ad2-a7b1-716f079ee998'),
	(150,148,2,5,1,NULL,'2020-12-09 22:35:36','2020-12-09 22:35:36','b3dd9055-5816-46c8-ae9b-e16840ab8afb'),
	(151,148,2,1,2,NULL,'2020-12-09 22:35:36','2020-12-09 22:35:36','6ec7c48f-ec17-4710-89dc-fabd8dda7d1b'),
	(152,148,2,4,3,NULL,'2020-12-09 22:35:36','2020-12-09 22:35:36','1d351a4a-50d8-423d-b350-2641c53f9ac8'),
	(153,148,2,4,4,NULL,'2020-12-09 22:35:36','2020-12-09 22:35:36','032d4b36-30ab-4756-93ea-5ccfe0608e00'),
	(159,158,28,10,1,NULL,'2020-12-09 22:50:38','2020-12-09 22:50:38','8f022dec-28a8-4733-851f-ccc902600a41'),
	(160,158,2,5,1,NULL,'2020-12-09 22:50:38','2020-12-09 22:50:38','b93eed2f-20a2-4e91-898b-e10a3a5b2302'),
	(161,158,2,1,2,NULL,'2020-12-09 22:50:38','2020-12-09 22:50:38','39328cec-79e8-4e95-88a4-37b9eed41369'),
	(162,158,2,4,3,NULL,'2020-12-09 22:50:38','2020-12-09 22:50:38','760f769d-1f62-4e06-8786-9649cf926202'),
	(163,158,2,4,4,NULL,'2020-12-09 22:50:38','2020-12-09 22:50:38','258d4b45-2785-490d-94db-16ad42021e7a'),
	(168,1,32,11,1,NULL,'2020-12-09 22:56:06','2020-12-09 22:56:06','85dad6a7-1124-411e-9f1a-33a092b697b9'),
	(170,169,28,10,1,NULL,'2020-12-09 22:56:06','2020-12-09 22:56:06','4ab00c13-c93d-462d-90b8-605124cb146d'),
	(171,169,32,11,1,NULL,'2020-12-09 22:56:06','2020-12-09 22:56:06','36cbb029-bed1-4dc6-91aa-a56401ade563'),
	(172,169,2,5,1,NULL,'2020-12-09 22:56:06','2020-12-09 22:56:06','169dda13-a8dc-4c6c-ab2c-3557f5b7a610'),
	(173,169,2,1,2,NULL,'2020-12-09 22:56:06','2020-12-09 22:56:06','db191172-87bf-411f-83df-71cf0f2c05fd'),
	(174,169,2,4,3,NULL,'2020-12-09 22:56:06','2020-12-09 22:56:06','1a17f185-4cd9-4493-a0b4-87c3e4f092f4'),
	(175,169,2,4,4,NULL,'2020-12-09 22:56:06','2020-12-09 22:56:06','b8016afb-06be-466f-9c8a-bdf41c6dd67f'),
	(181,180,28,10,1,NULL,'2020-12-09 23:01:03','2020-12-09 23:01:03','f46ceeba-b236-40e2-a559-ade28a10bd6c'),
	(182,180,32,11,1,NULL,'2020-12-09 23:01:03','2020-12-09 23:01:03','6e8a3827-f3d9-44cf-9984-c55de136581e'),
	(183,180,2,5,1,NULL,'2020-12-09 23:01:03','2020-12-09 23:01:03','0150fa0b-df5c-42e7-bf25-1ac5977c73f4'),
	(184,180,2,1,2,NULL,'2020-12-09 23:01:03','2020-12-09 23:01:03','5ef9e67e-b647-4e86-896a-3eb585cd9c00'),
	(185,180,2,4,3,NULL,'2020-12-09 23:01:03','2020-12-09 23:01:03','18b13739-f461-4472-94f7-2389eda5dde3'),
	(186,180,2,4,4,NULL,'2020-12-09 23:01:03','2020-12-09 23:01:03','cd9902d8-afd8-4d6b-8f25-e420a6c2ca90'),
	(192,191,28,10,1,NULL,'2020-12-09 23:18:20','2020-12-09 23:18:20','920838a4-eb72-4dc8-86b6-71da22a113f8'),
	(193,191,32,11,1,NULL,'2020-12-09 23:18:20','2020-12-09 23:18:20','2e38c646-03fd-40fc-ab52-2e7405e7ea19'),
	(194,191,2,5,1,NULL,'2020-12-09 23:18:20','2020-12-09 23:18:20','c507ab58-63ce-457e-a607-7239ad9a4313'),
	(195,191,2,1,2,NULL,'2020-12-09 23:18:20','2020-12-09 23:18:20','70797ae9-d536-48a4-a441-c94f6c161236'),
	(196,191,2,4,3,NULL,'2020-12-09 23:18:20','2020-12-09 23:18:20','6859401e-23f2-4857-aef5-41c32da89477'),
	(197,191,2,4,4,NULL,'2020-12-09 23:18:21','2020-12-09 23:18:21','a06cdc5d-9ee6-4419-a50b-40371facb92e'),
	(203,202,28,10,1,NULL,'2020-12-09 23:20:49','2020-12-09 23:20:49','d8833c3c-569e-4d78-9fc3-2d30257caa1d'),
	(204,202,32,11,1,NULL,'2020-12-09 23:20:49','2020-12-09 23:20:49','8a0a5443-47e5-49c0-bf4f-6839c86a6b59'),
	(205,202,2,5,1,NULL,'2020-12-09 23:20:49','2020-12-09 23:20:49','b6be41fc-e99a-4636-993f-4dd1f48a262d'),
	(206,202,2,1,2,NULL,'2020-12-09 23:20:49','2020-12-09 23:20:49','6766c254-a8cb-40a0-b6d5-5a0afe5f4a7c'),
	(207,202,2,4,3,NULL,'2020-12-09 23:20:49','2020-12-09 23:20:49','09f06d1c-e478-4022-a261-f348c4c16834'),
	(208,202,2,4,4,NULL,'2020-12-09 23:20:49','2020-12-09 23:20:49','af0ad6fc-020f-42e9-92c2-d908974e7a35'),
	(214,213,28,10,1,NULL,'2020-12-09 23:58:21','2020-12-09 23:58:21','41aa5115-4c92-4b7c-ad5d-ddd7c0b2096a'),
	(215,213,32,11,1,NULL,'2020-12-09 23:58:21','2020-12-09 23:58:21','6facc4c9-4780-4d01-8086-211cb21dc83a'),
	(216,213,2,5,1,NULL,'2020-12-09 23:58:21','2020-12-09 23:58:21','f5646488-c13c-4e5f-ba06-e473a3971042'),
	(217,213,2,1,2,NULL,'2020-12-09 23:58:21','2020-12-09 23:58:21','dda3b560-f8ba-4cde-bff9-3d7ea10506ac'),
	(218,213,2,4,3,NULL,'2020-12-09 23:58:21','2020-12-09 23:58:21','180172be-0384-4523-b196-169baaceb7ac'),
	(219,213,2,4,4,NULL,'2020-12-09 23:58:21','2020-12-09 23:58:21','60e664a1-6d26-4c22-ad98-7d16ec48fd7e'),
	(224,1,38,12,1,NULL,'2020-12-10 00:00:08','2020-12-10 00:00:08','b6152546-4d52-43d1-b694-ff2016c5d4ab'),
	(226,225,28,10,1,NULL,'2020-12-10 00:00:08','2020-12-10 00:00:08','e8dc0e63-83c8-4afe-9f46-801a703d5bae'),
	(227,225,32,11,1,NULL,'2020-12-10 00:00:08','2020-12-10 00:00:08','30becb1a-6417-4b69-a771-1525fb989e68'),
	(228,225,38,12,1,NULL,'2020-12-10 00:00:08','2020-12-10 00:00:08','d8c7828c-daa5-4070-b8c8-17df59cac2e9'),
	(229,225,2,5,1,NULL,'2020-12-10 00:00:08','2020-12-10 00:00:08','18b47f6d-2f07-4326-925a-a839284d590c'),
	(230,225,2,1,2,NULL,'2020-12-10 00:00:08','2020-12-10 00:00:08','8b833fa3-84a0-4fc0-8f8d-047b1fa04b60'),
	(231,225,2,4,3,NULL,'2020-12-10 00:00:08','2020-12-10 00:00:08','606e79e0-54b3-409c-ac6b-3be0a786fa9b'),
	(232,225,2,4,4,NULL,'2020-12-10 00:00:08','2020-12-10 00:00:08','0d569277-e7aa-45ca-9208-b31cde041db3'),
	(238,237,28,10,1,NULL,'2020-12-10 00:08:00','2020-12-10 00:08:00','1f34a3c8-823b-430e-94ff-9f0404216e34'),
	(239,237,32,11,1,NULL,'2020-12-10 00:08:00','2020-12-10 00:08:00','e4a5b34c-44b6-4d1f-b4c9-90f409ce3e7d'),
	(240,237,38,12,1,NULL,'2020-12-10 00:08:00','2020-12-10 00:08:00','2f7b8fbc-12ac-4a40-b537-0e0630cbb50c'),
	(241,237,2,5,1,NULL,'2020-12-10 00:08:00','2020-12-10 00:08:00','fb06948a-72ee-485d-974c-561ecebb5988'),
	(242,237,2,1,2,NULL,'2020-12-10 00:08:00','2020-12-10 00:08:00','078019ee-03cf-455a-8acd-4e4fb5eff6b9'),
	(243,237,2,4,3,NULL,'2020-12-10 00:08:00','2020-12-10 00:08:00','49391742-e131-43ab-8a26-12b2a9c240cc'),
	(244,237,2,4,4,NULL,'2020-12-10 00:08:00','2020-12-10 00:08:00','a02d0a86-96e0-4e17-952a-ccd2600d7f53'),
	(250,249,28,10,1,NULL,'2020-12-10 00:31:34','2020-12-10 00:31:34','30865282-7c8d-45fd-80a6-6bfd1a6badad'),
	(251,249,32,11,1,NULL,'2020-12-10 00:31:34','2020-12-10 00:31:34','9b36062b-78ea-4e9c-8759-676b3a816f7f'),
	(252,249,38,12,1,NULL,'2020-12-10 00:31:34','2020-12-10 00:31:34','a13cdd58-1a93-449d-80e8-59fd1f5d38ab'),
	(253,249,2,5,1,NULL,'2020-12-10 00:31:34','2020-12-10 00:31:34','59babafc-b91c-4171-b439-13a5994a8b5f'),
	(254,249,2,1,2,NULL,'2020-12-10 00:31:35','2020-12-10 00:31:35','72fa4001-9b4b-484a-aad7-a7f15cea49d7'),
	(255,249,2,4,3,NULL,'2020-12-10 00:31:35','2020-12-10 00:31:35','9db8eea4-7d0a-4692-bbcf-e5f9fa15dfc6'),
	(256,249,2,4,4,NULL,'2020-12-10 00:31:35','2020-12-10 00:31:35','eb1d0287-fa17-42cf-bbfc-f2f3ddeb43ec'),
	(257,1,44,13,1,NULL,'2020-12-10 00:33:07','2020-12-10 00:33:07','2a3f7951-5444-43ad-bf49-a9062a723a79'),
	(259,258,28,10,1,NULL,'2020-12-10 00:33:07','2020-12-10 00:33:07','5505dbbb-a1e2-4200-a235-623f449a70ad'),
	(260,258,32,11,1,NULL,'2020-12-10 00:33:07','2020-12-10 00:33:07','dd853825-0bdc-465e-8df1-fe45b0b95d5b'),
	(261,258,38,12,1,NULL,'2020-12-10 00:33:07','2020-12-10 00:33:07','b576e6f0-eb11-490d-b8c1-88701fcc94d4'),
	(262,258,44,13,1,NULL,'2020-12-10 00:33:07','2020-12-10 00:33:07','20be7c32-874f-4326-b40e-6b0e9fcf03d7'),
	(263,258,2,5,1,NULL,'2020-12-10 00:33:07','2020-12-10 00:33:07','afc33539-7f04-457a-8a97-5c2aa850ed13'),
	(264,258,2,1,2,NULL,'2020-12-10 00:33:07','2020-12-10 00:33:07','2ecf514a-7bf8-401d-961b-9fd1b9e5280a'),
	(265,258,2,4,3,NULL,'2020-12-10 00:33:07','2020-12-10 00:33:07','512a6098-e327-4ce1-910f-745fc36c7332'),
	(266,258,2,4,4,NULL,'2020-12-10 00:33:07','2020-12-10 00:33:07','0560b3f1-0700-4891-8648-0c585f4cb9f6'),
	(268,267,28,10,1,NULL,'2020-12-10 00:34:13','2020-12-10 00:34:13','4e15808e-7604-4bb8-bc01-6d96fd74fcc9'),
	(269,267,32,11,1,NULL,'2020-12-10 00:34:13','2020-12-10 00:34:13','f977a5a7-18a5-435a-9647-7b8fc0ddc046'),
	(270,267,38,12,1,NULL,'2020-12-10 00:34:13','2020-12-10 00:34:13','fb71bbe0-0a0a-458a-8950-fa5d515e7e04'),
	(271,267,44,13,1,NULL,'2020-12-10 00:34:13','2020-12-10 00:34:13','65dc29ca-d06a-4577-aa33-bd8a292f5d5d'),
	(273,272,28,10,1,NULL,'2020-12-10 00:34:53','2020-12-10 00:34:53','802dc30d-57d6-4b6d-bce2-d727eef21544'),
	(274,272,32,11,1,NULL,'2020-12-10 00:34:53','2020-12-10 00:34:53','6a84766e-bf26-4c11-8395-554549fc5bc3'),
	(275,272,38,12,1,NULL,'2020-12-10 00:34:54','2020-12-10 00:34:54','2dd8d095-e022-4bd4-8e93-9f7461398feb'),
	(276,272,44,13,1,NULL,'2020-12-10 00:34:54','2020-12-10 00:34:54','de69b16b-5369-4596-ad37-6d983be0b5c7'),
	(278,277,28,10,1,NULL,'2020-12-14 23:15:24','2020-12-14 23:15:24','3ec75363-b6d7-4f16-ab70-dd670f6920c8'),
	(279,277,32,11,1,NULL,'2020-12-14 23:15:24','2020-12-14 23:15:24','1e248ecb-cd40-4aad-8027-92ebba4bbe7d'),
	(280,277,38,12,1,NULL,'2020-12-14 23:15:24','2020-12-14 23:15:24','82b977bc-d960-46eb-b7bd-170b1f37235e'),
	(281,277,44,13,1,NULL,'2020-12-14 23:15:24','2020-12-14 23:15:24','71724540-ac33-41b4-9dbb-4c929dba86fe'),
	(283,282,28,10,1,NULL,'2020-12-16 06:04:29','2020-12-16 06:04:29','094c0f68-6bce-4abc-9e4b-deb13b60ff3f'),
	(284,282,32,11,1,NULL,'2020-12-16 06:04:29','2020-12-16 06:04:29','6e7710ab-cb9d-4279-b86c-a6efe8aa0106'),
	(285,282,38,12,1,NULL,'2020-12-16 06:04:29','2020-12-16 06:04:29','e06f078b-39bb-4d6b-bee3-f4353dddb891'),
	(286,282,44,13,1,NULL,'2020-12-16 06:04:29','2020-12-16 06:04:29','29850b92-f0c7-4076-bf6a-0bce3457b84b'),
	(288,287,28,10,1,NULL,'2020-12-16 06:05:08','2020-12-16 06:05:08','66a5f688-31a3-45c3-a530-774f625ccf48'),
	(289,287,32,11,1,NULL,'2020-12-16 06:05:09','2020-12-16 06:05:09','3b9bcbbb-3745-484d-be87-680c84b56aa8'),
	(290,287,38,12,1,NULL,'2020-12-16 06:05:09','2020-12-16 06:05:09','8d706806-d49e-44f6-9b7c-ced57095da0c'),
	(291,287,44,13,1,NULL,'2020-12-16 06:05:09','2020-12-16 06:05:09','70121bb7-ec06-406c-8bc1-325716aca80c'),
	(293,292,28,10,1,NULL,'2020-12-16 06:13:57','2020-12-16 06:13:57','914daab8-fe8e-49c3-9d14-cb53a5015b37'),
	(294,292,32,11,1,NULL,'2020-12-16 06:13:58','2020-12-16 06:13:58','1fe44626-7f6f-4b1e-8104-b9830c4a9320'),
	(295,292,38,12,1,NULL,'2020-12-16 06:13:58','2020-12-16 06:13:58','96f6cfc9-570e-4413-893b-befa261acc4f'),
	(296,292,44,13,1,NULL,'2020-12-16 06:13:58','2020-12-16 06:13:58','92cb38f3-b1f5-470a-8fb1-db35aa736b4f'),
	(298,297,28,10,1,NULL,'2020-12-16 12:18:09','2020-12-16 12:18:09','055e850b-fe72-47c8-84d6-2470fbb28ec0'),
	(299,297,32,11,1,NULL,'2020-12-16 12:18:09','2020-12-16 12:18:09','501384f0-4755-4823-a7ed-d92a0e11c176'),
	(300,297,38,12,1,NULL,'2020-12-16 12:18:09','2020-12-16 12:18:09','f8982240-c7c6-49de-bade-2340973277e2'),
	(301,297,44,13,1,NULL,'2020-12-16 12:18:09','2020-12-16 12:18:09','529b3b10-a503-4be3-8837-879f3825c793'),
	(303,302,28,10,1,NULL,'2020-12-16 12:19:22','2020-12-16 12:19:22','1bed51fc-9fd1-4251-a69b-4dde34247a76'),
	(304,302,32,11,1,NULL,'2020-12-16 12:19:22','2020-12-16 12:19:22','b2c2c52d-f3a0-428b-8014-e09f30d166c9'),
	(305,302,38,12,1,NULL,'2020-12-16 12:19:22','2020-12-16 12:19:22','5e6c899d-cb6a-4e8a-92ae-c91892f9c961'),
	(306,302,44,13,1,NULL,'2020-12-16 12:19:23','2020-12-16 12:19:23','4f438f4f-cb4b-4ae9-897f-c411882de7f4');

/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table matrixblocktypes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `matrixblocktypes`;

CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `matrixblocktypes_name_fieldId_idx` (`name`,`fieldId`),
  KEY `matrixblocktypes_handle_fieldId_idx` (`handle`,`fieldId`),
  KEY `matrixblocktypes_fieldId_idx` (`fieldId`),
  KEY `matrixblocktypes_fieldLayoutId_idx` (`fieldLayoutId`),
  CONSTRAINT `matrixblocktypes_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixblocktypes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;

INSERT INTO `matrixblocktypes` (`id`, `fieldId`, `fieldLayoutId`, `name`, `handle`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,2,2,'Rich Text','richText',1,'2020-12-07 08:31:18','2020-12-07 08:31:18','0c98f9b9-84bf-4766-af63-a3568b46c0a6'),
	(2,2,3,'Image','image',3,'2020-12-07 08:31:19','2020-12-07 08:31:19','28d5c036-8cb0-4a14-b553-0167ee34efbe'),
	(3,2,4,'Embed','embed',5,'2020-12-07 08:31:19','2020-12-07 08:31:19','fb2f8912-57ad-4b4e-887d-e55f22a6d348'),
	(4,2,5,'Quote','quote',2,'2020-12-07 08:31:19','2020-12-07 08:31:19','a121b8e6-70e6-421b-9629-c664d2949934'),
	(5,2,9,'Image Carousel','imageCarousel',4,'2020-12-07 08:31:21','2020-12-07 08:31:21','7e401ee6-3575-42de-b3b4-cedae706f392'),
	(10,28,15,'Hero','hero',1,'2020-12-09 19:05:30','2020-12-09 23:48:06','b8af96bb-780f-4207-bd37-5975ec6038a3'),
	(11,32,16,'Listing','listing',1,'2020-12-09 22:45:12','2020-12-09 23:49:00','73224dba-c124-4f91-9f5a-de0bb4843c02'),
	(12,38,17,'Cards','cards',1,'2020-12-09 23:57:41','2020-12-09 23:57:41','d9c7c085-cbae-4086-8b3f-04b598277c3e'),
	(13,44,18,'Centred Content','centredContent',1,'2020-12-10 00:23:05','2020-12-10 00:23:05','2f43fde9-8649-458c-ac99-490e41bf1f03');

/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table matrixcontent_bodycontent
# ------------------------------------------------------------

DROP TABLE IF EXISTS `matrixcontent_bodycontent`;

CREATE TABLE `matrixcontent_bodycontent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_richText_richText` text,
  `field_image_position` varchar(255) DEFAULT NULL,
  `field_embed_embed` text,
  `field_quote_quote` text,
  `field_quote_attribution` text,
  `field_quote_style` varchar(255) DEFAULT NULL,
  `field_imageCarousel_aspectRatio` varchar(255) DEFAULT NULL,
  `field_imageCarousel_imagesTitle` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixcontent_bodycontent_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `matrixcontent_bodycontent_siteId_fk` (`siteId`),
  CONSTRAINT `matrixcontent_bodycontent_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixcontent_bodycontent_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `matrixcontent_bodycontent` WRITE;
/*!40000 ALTER TABLE `matrixcontent_bodycontent` DISABLE KEYS */;

INSERT INTO `matrixcontent_bodycontent` (`id`, `elementId`, `siteId`, `dateCreated`, `dateUpdated`, `uid`, `field_richText_richText`, `field_image_position`, `field_embed_embed`, `field_quote_quote`, `field_quote_attribution`, `field_quote_style`, `field_imageCarousel_aspectRatio`, `field_imageCarousel_imagesTitle`)
VALUES
	(1,24,1,'2020-12-07 19:56:43','2020-12-07 19:56:43','885ab34f-4001-4ae1-a070-a0bb87c03fc6',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(2,25,1,'2020-12-07 19:56:43','2020-12-07 20:36:27','d4da63e4-4957-4e1b-a351-1abc829c6d00',NULL,NULL,NULL,NULL,NULL,NULL,'4:3','Tours & Packages'),
	(3,27,1,'2020-12-07 19:56:43','2020-12-07 19:56:43','293882b7-5fa2-4914-bfcd-645663a4980f',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(4,28,1,'2020-12-07 19:56:43','2020-12-07 19:56:43','013d64b1-e58f-439e-a053-7d48ea4ab411',NULL,NULL,NULL,NULL,NULL,NULL,'4:3',NULL),
	(5,30,1,'2020-12-07 20:14:29','2020-12-07 20:14:29','94d8f3a8-8e4e-41aa-8c3d-a4993a22905b',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(6,31,1,'2020-12-07 20:14:29','2020-12-07 20:14:29','d0960807-3d3d-426f-9bcd-d175dd631271',NULL,NULL,NULL,NULL,NULL,NULL,'4:3','Title'),
	(7,33,1,'2020-12-07 20:36:27','2020-12-07 20:36:27','8c3f139d-2cc8-465c-9993-98c30683f0ad',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(8,34,1,'2020-12-07 20:36:27','2020-12-07 20:36:27','fc99ff0c-b5a7-4f0b-a30d-c4ccb527ca12',NULL,NULL,NULL,NULL,NULL,NULL,'4:3','Tours & Packages'),
	(9,42,1,'2020-12-08 08:19:55','2020-12-09 18:47:31','a16afae2-22a2-40cf-a36f-f3b53d17a0d3',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(10,44,1,'2020-12-08 08:19:55','2020-12-08 08:19:55','fbd6b637-5310-4e7e-9812-701e6e93eac4',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(11,46,1,'2020-12-08 08:20:21','2020-12-08 08:20:21','5bf8b8bb-d0f8-4a33-8bd7-6cf85e48b7cc',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(12,47,1,'2020-12-08 09:23:25','2020-12-08 09:23:25','515dd318-61f3-4c27-813a-2613e8bd7329',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(13,48,1,'2020-12-08 09:23:25','2020-12-08 09:23:25','90c39cb6-bfd1-444b-98e6-903e65cd6ad1',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(14,49,1,'2020-12-08 09:23:25','2020-12-08 09:23:25','bde5326a-e538-4fb5-8132-73caa2185783',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(15,51,1,'2020-12-08 09:23:25','2020-12-08 09:23:25','f2b84f0f-cfd7-4465-9af9-71eec8ba410f',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(16,52,1,'2020-12-08 09:23:26','2020-12-08 09:23:26','63e3a56f-7521-458b-af76-3fe0058e95aa',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(17,53,1,'2020-12-08 09:23:26','2020-12-08 09:23:26','1cdb1adb-e9b3-4058-8f7d-43b6df41c7a0',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(18,54,1,'2020-12-08 09:23:26','2020-12-08 09:23:26','86521498-ce01-4571-a412-caf964648ead',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(19,66,1,'2020-12-08 18:08:37','2020-12-09 07:19:41','8301e10d-6472-45c9-886d-79b8b7999f2c',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(20,68,1,'2020-12-08 18:08:38','2020-12-08 18:08:38','82bc4f1b-b598-45b8-b157-8db9ff1fb854',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(21,69,1,'2020-12-08 18:09:16','2020-12-09 07:19:41','70d9010b-c716-4ddd-a4d9-c5e1a2ed6158',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(22,71,1,'2020-12-08 18:09:16','2020-12-08 18:09:16','7024257f-c994-4d15-8499-b67fb8167ea5',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(23,72,1,'2020-12-08 18:09:50','2020-12-09 07:19:41','089bcc43-7d01-4537-8439-b4c2a3acbd14',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(24,74,1,'2020-12-08 18:09:51','2020-12-08 18:09:51','4a0b9a37-b9a4-4ab3-920f-f4f74953d20d',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(25,76,1,'2020-12-08 18:17:41','2020-12-08 18:17:41','5912fd5b-a4d2-450f-92c3-2dc3a1c7bacc',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(26,78,1,'2020-12-08 18:17:56','2020-12-08 18:17:56','b9f8082a-db8b-40a5-93a5-1cd4d20e046e',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(27,80,1,'2020-12-08 18:18:12','2020-12-08 18:18:12','2d600ea7-4415-40e5-9c6a-73b51b17d66b',NULL,'wide',NULL,NULL,NULL,NULL,NULL,NULL),
	(28,82,1,'2020-12-08 20:07:34','2020-12-08 20:07:34','b495b60e-55b9-4649-837c-90eae69629c0',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(29,84,1,'2020-12-09 00:07:30','2020-12-09 00:07:30','0ca09d2a-ad6a-44e5-9bad-143991b12b84',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(30,85,1,'2020-12-09 07:28:39','2020-12-09 07:28:39','c3e556d5-b170-473d-97eb-2f87b79a4662',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(31,87,1,'2020-12-09 07:28:39','2020-12-09 07:28:39','5a97fe27-a1e8-4593-8555-6f2511852fac',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(32,88,1,'2020-12-09 07:28:39','2020-12-09 07:28:39','9834cc6d-3fc5-48fb-84c5-347b032cdfc0',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(33,90,1,'2020-12-09 07:38:03','2020-12-09 07:38:03','62a50c9b-8cad-4fe2-936f-23db293e689d',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(34,91,1,'2020-12-09 07:38:03','2020-12-09 07:38:03','69b39eed-a8ac-4244-8749-77c4abce9ca1',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(35,93,1,'2020-12-09 08:06:36','2020-12-09 08:06:36','9e3eabcc-0148-4063-8bda-a88d11594d6e',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(36,95,1,'2020-12-09 08:07:13','2020-12-09 08:07:13','af99b67f-f03f-4322-8efd-8fae467be43b',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(37,101,1,'2020-12-09 08:10:35','2020-12-09 08:10:35','eb82ef39-37c5-476d-8038-2895b273a11d',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(38,106,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','0bc337af-2846-42e1-8725-678f310b9166',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(39,107,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','4b4da6b0-6795-4801-9b4e-063574ae48bf',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(40,108,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','f17fb16e-ce3d-462e-8654-141d82e00551',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(41,110,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','d6eca903-4661-4999-96fc-7ebaf3b5b924',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(42,111,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','18821e65-6e4d-4452-9824-0822c456baef',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(43,112,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','887ddd98-dbff-4cf9-9c0b-91a41774da21',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(44,113,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','dce6102d-e297-440a-8b49-e18365522b3e',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(45,119,1,'2020-12-09 19:08:12','2020-12-09 19:08:12','60591b0d-55d1-4596-bc28-ef8a020a682f',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(46,120,1,'2020-12-09 19:08:12','2020-12-09 19:08:12','cb820e58-a102-4d9a-81b1-f97da1cd3c11',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(47,121,1,'2020-12-09 19:08:13','2020-12-09 19:08:13','dd313d0b-92f2-43bb-96d5-fcd8bce43a26',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(48,122,1,'2020-12-09 19:08:13','2020-12-09 19:08:13','5f47fbd5-2197-4f73-a84b-e0aa6b1a77de',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(49,130,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','d085e913-e3c5-4f3a-b815-4bd36a183add',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(50,131,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','a1597a8f-892a-4db0-8e5e-77f1cbf4a03b',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(51,132,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','25b1e16a-3cb3-4186-ab21-8de8d0eea8e0',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(52,133,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','3c7cd3b7-35a9-4b37-ab7e-df5e45026cbf',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(53,140,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','21857e3e-f8bc-4056-a96f-921efb27f36d',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(54,141,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','992e8228-7c87-46d5-93c7-5d8a05dbfe52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(55,142,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','05f11cbb-04c6-4176-9a3e-7595c4959e2f',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(56,143,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','832942dc-3f4f-4b64-8bb6-3c24e9e2304b',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(57,150,1,'2020-12-09 22:35:36','2020-12-09 22:35:36','8a3e4adb-53c3-4f09-9a8d-87b9258f8b9a',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(58,151,1,'2020-12-09 22:35:36','2020-12-09 22:35:36','8ad72943-1dec-4a0d-81e0-67a761aa13af',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(59,152,1,'2020-12-09 22:35:36','2020-12-09 22:35:36','24a3c7de-8bc6-4fe0-a543-5e13cd0d21f8',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(60,153,1,'2020-12-09 22:35:36','2020-12-09 22:35:36','4cad1166-ea0f-4d3d-8dbb-a69b4965a718',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(61,160,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','991396ba-e1d4-4fa7-91e7-dada11beb61c',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(62,161,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','0ec674bf-f3e5-4c20-802a-dc85bde02d72',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(63,162,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','f31b5fba-0021-429c-81d7-d58e489adc6d',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(64,163,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','be0754a9-308e-476c-9fb0-323849e25874',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(65,172,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','ee4ed11a-e8e0-4565-abd9-f6d11485ebb1',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(66,173,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','e3ebadbf-606e-4b62-8e5b-e8d88229f440',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(67,174,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','aedb750e-ae02-40e4-abe2-8ca4e0e116c7',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(68,175,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','06db01fb-261d-4a19-9ac5-e2133b1ada2e',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(69,183,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','6893e4e9-f9d1-4bce-b869-65ef3dacd31d',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(70,184,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','f8cd85d8-faaa-4897-9a00-d8bd5fe6d79c',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(71,185,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','ade3204e-cdad-4dd5-a904-fafbead09348',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(72,186,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','b10640f7-0c31-45b7-a0d2-e957e01b84d3',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(73,194,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','e708efd6-f945-4386-86c0-1d77ef3b0c99',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(74,195,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','bcddbf58-484b-4947-91fb-bd39a4d1b9a5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(75,196,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','b8580d19-3bd5-47da-87b3-2fad4cf585a4',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(76,197,1,'2020-12-09 23:18:21','2020-12-09 23:18:21','7cbb737e-b7ca-4d38-8f84-876f2f52cf81',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(77,205,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','965d265e-ff6c-48fb-a1f6-465154bbdf92',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(78,206,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','9fb307f3-b79c-40b5-9fca-5ec723f164cb',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(79,207,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','28218881-df27-4bfa-8fa4-349592719aaa',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(80,208,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','5e2f581e-6b6d-4c57-84a9-15263a928d9e',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(81,216,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','dff1c8f6-0b5e-4135-8db6-b2559ed6fe1c',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(82,217,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','dc282e2e-8fda-4e2c-ad16-bd1f67f1e765',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(83,218,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','fa36a1a4-11eb-4833-ae01-3d8b8393c438',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(84,219,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','57936233-050d-46dc-b7d5-2fb32cf9c193',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(85,229,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','4e0af225-e0f5-4cf6-8670-121335c24bea',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(86,230,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','264db742-7666-468f-89dc-ce279ea394cd',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(87,231,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','13ae1843-d429-4205-890f-249dcb7066b0',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(88,232,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','c64e1aba-f199-441f-a5a2-44594b106076',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(89,241,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','a7ad1625-bc7f-47de-8b4e-97a756673b39',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(90,242,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','a0fd03ba-ed1b-4429-9d89-bf37d78bc58a',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(91,243,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','2883a3ed-5585-43c5-aaaf-e138e9129d05',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(92,244,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','767d0437-f625-487a-9598-c822a0e5dee4',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(93,253,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','84ac5184-6071-498d-91d6-21819e57a152',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(94,254,1,'2020-12-10 00:31:35','2020-12-10 00:31:35','357b564d-f42d-4587-9d29-5752e78c2cda',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(95,255,1,'2020-12-10 00:31:35','2020-12-10 00:31:35','3f29e679-73c8-497d-9f62-27bbff1a3cb8',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(96,256,1,'2020-12-10 00:31:35','2020-12-10 00:31:35','fe082d7f-a93b-4f9e-8125-34bb487f63f6',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL),
	(97,263,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','12cfb51f-e064-4c1e-8828-7a5e178a355d',NULL,NULL,NULL,NULL,NULL,NULL,'16:9',NULL),
	(98,264,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','df1ff4a4-b2a3-4671-a96a-c16859cd371a',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(99,265,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','4c6251a5-886a-44cf-a284-72c8c4702b50',NULL,NULL,NULL,NULL,NULL,'blockquote',NULL,NULL),
	(100,266,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','a55368f3-11fa-45c7-b6a1-c6c2c900088c',NULL,NULL,NULL,'<p>Block Quote TEst message</p>','Attribution','blockquote',NULL,NULL);

/*!40000 ALTER TABLE `matrixcontent_bodycontent` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table matrixcontent_cards
# ------------------------------------------------------------

DROP TABLE IF EXISTS `matrixcontent_cards`;

CREATE TABLE `matrixcontent_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_cards_aspectRatio` varchar(255) DEFAULT NULL,
  `field_cards_buttonLabel` text,
  `field_cards_cardsSection` text,
  `field_cards_cardsTitle` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixcontent_cards_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `matrixcontent_cards_siteId_fk` (`siteId`),
  CONSTRAINT `matrixcontent_cards_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixcontent_cards_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `matrixcontent_cards` WRITE;
/*!40000 ALTER TABLE `matrixcontent_cards` DISABLE KEYS */;

INSERT INTO `matrixcontent_cards` (`id`, `elementId`, `siteId`, `dateCreated`, `dateUpdated`, `uid`, `field_cards_aspectRatio`, `field_cards_buttonLabel`, `field_cards_cardsSection`, `field_cards_cardsTitle`)
VALUES
	(1,224,1,'2020-12-10 00:00:08','2020-12-16 12:18:08','7cafe262-a663-4a85-a9a6-3dfc5f3ceafa','169','Explore Details','Section A','Tours & Packages'),
	(2,228,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','0abb6682-4c9a-49c7-9121-28c79d4e0056','169','Explore Details',NULL,NULL),
	(3,240,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','5acbb1e7-f245-4e3a-a9f6-7b73dde26630','169','Explore Details','Section A','Tours & Packages'),
	(4,252,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','01fb4153-cb5d-45c8-95f2-7c527d49c3d1','169','Explore Details','Section A','Tours & Packages'),
	(5,261,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','a07607a7-0ae3-442a-9bdf-ba511258a404','169','Explore Details','Section A','Tours & Packages'),
	(6,270,1,'2020-12-10 00:34:13','2020-12-10 00:34:13','63f8a290-44a7-4aa0-a62b-2936f00dde29','169','Explore Details','Section A','Tours & Packages'),
	(7,275,1,'2020-12-10 00:34:54','2020-12-10 00:34:54','d432c91e-73f0-4a3a-91d1-25f149d1c9ac','169','Explore Details','Section A','Tours & Packages'),
	(8,280,1,'2020-12-14 23:15:24','2020-12-14 23:15:24','f05d89a1-e6cb-4350-bab0-d4ccfc706032','169','Explore Details','Section A','Tours & Packages'),
	(9,285,1,'2020-12-16 06:04:29','2020-12-16 06:04:29','21c85100-b05e-4ae3-9a63-8f166fd6e7be','169','Explore Details','Section A','Tours & Packages'),
	(10,290,1,'2020-12-16 06:05:09','2020-12-16 06:05:09','e228a6a5-12c6-4dda-8cb7-abf211ba62f0','169','Explore Details','Section A','Tours & Packages'),
	(11,295,1,'2020-12-16 06:13:58','2020-12-16 06:13:58','f71d03af-052d-446d-ab73-925ab83e10bf','169','Explore Details','Section A','Tours & Packages'),
	(12,300,1,'2020-12-16 12:18:09','2020-12-16 12:18:09','61a18903-c1f0-4d08-a360-ff02e18d1345','169','Explore Details','Section A','Tours & Packages'),
	(13,305,1,'2020-12-16 12:19:22','2020-12-16 12:19:22','2e1fabe0-8da2-496d-ba44-e5984712e540','169','Explore Details','Section A','Tours & Packages');

/*!40000 ALTER TABLE `matrixcontent_cards` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table matrixcontent_centredcontent
# ------------------------------------------------------------

DROP TABLE IF EXISTS `matrixcontent_centredcontent`;

CREATE TABLE `matrixcontent_centredcontent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_centredContent_centredTitle` text,
  `field_centredContent_centredCopy` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixcontent_centredcontent_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `matrixcontent_centredcontent_siteId_fk` (`siteId`),
  CONSTRAINT `matrixcontent_centredcontent_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixcontent_centredcontent_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `matrixcontent_centredcontent` WRITE;
/*!40000 ALTER TABLE `matrixcontent_centredcontent` DISABLE KEYS */;

INSERT INTO `matrixcontent_centredcontent` (`id`, `elementId`, `siteId`, `dateCreated`, `dateUpdated`, `uid`, `field_centredContent_centredTitle`, `field_centredContent_centredCopy`)
VALUES
	(1,257,1,'2020-12-10 00:33:07','2020-12-16 06:05:08','e63fb4bf-9eb8-4aff-90fd-46dfed19a6d3','Ready to start your adventure?','<p>Start by picking your desired <a href=\"#activity\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">activity</a>, <a href=\"#destination\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">destination</a>, <a href=\"#package\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">package</a> or <a href=\"#contact%20us\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">contact us</a> and we\'ll tailor something really special that perfectly suits your needs. This is my test message!</p>'),
	(2,262,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','703c4bc2-a57c-4bc2-abd1-2850d174a0de','Ready to start your adventure?',' Start by picking your desired <a href=\"#activity\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">activity</a>, <a href=\"#destination\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">destination</a>, <a href=\"#package\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">package</a> or <a href=\"#contact%20us\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">contact us</a> and we\'ll tailor something really speail that perfectly suits your needs'),
	(3,271,1,'2020-12-10 00:34:13','2020-12-10 00:34:13','e2f7b772-2174-4e2a-99d1-dfb4dedc8ba9','Ready to start your adventure?',' Start by picking your desired <a href=\"#activity\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">activity</a>, <a href=\"#destination\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">destination</a>, <a href=\"#package\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">package</a> or <a href=\"#contact%20us\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">contact us</a> and we\'ll tailor something really speail that perfectly suits your needs'),
	(4,276,1,'2020-12-10 00:34:54','2020-12-10 00:34:54','db39d5a8-a96e-48bf-bad6-a344f87af110','Ready to start your adventure?',' Start by picking your desired <a href=\"#activity\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">activity</a>, <a href=\"#destination\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">destination</a>, <a href=\"#package\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">package</a> or <a href=\"#contact%20us\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">contact us</a> and we\'ll tailor something really speail that perfectly suits your needs'),
	(5,281,1,'2020-12-14 23:15:24','2020-12-14 23:15:24','40a1722f-db39-4ef4-9713-961e48cc3cb8','Ready to start your adventure?','<p>Start by picking your desired <a href=\"#activity\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">activity</a>, <a href=\"#destination\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">destination</a>, <a href=\"#package\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">package</a> or <a href=\"#contact%20us\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">contact us</a> and we\'ll tailor something really speail that perfectly suits your needs. This is my test</p>'),
	(6,286,1,'2020-12-16 06:04:29','2020-12-16 06:04:29','d051fb19-d2f3-4d58-a010-c16c3d57977b','Ready to start your adventure?','<p>Start by picking your desired <a href=\"#activity\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">activity</a>, <a href=\"#destination\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">destination</a>, <a href=\"#package\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">package</a> or <a href=\"#contact%20us\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">contact us</a> and we\'ll tailor something really speail that perfectly suits your needs. This is my test message!</p>'),
	(7,291,1,'2020-12-16 06:05:09','2020-12-16 06:05:09','b352c6c5-9270-4842-9c22-d5e459e423be','Ready to start your adventure?','<p>Start by picking your desired <a href=\"#activity\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">activity</a>, <a href=\"#destination\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">destination</a>, <a href=\"#package\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">package</a> or <a href=\"#contact%20us\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">contact us</a> and we\'ll tailor something really special that perfectly suits your needs. This is my test message!</p>'),
	(8,296,1,'2020-12-16 06:13:58','2020-12-16 06:13:58','4ddae72e-1ba6-42e3-b8f0-47d02d10fa2f','Ready to start your adventure?','<p>Start by picking your desired <a href=\"#activity\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">activity</a>, <a href=\"#destination\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">destination</a>, <a href=\"#package\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">package</a> or <a href=\"#contact%20us\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">contact us</a> and we\'ll tailor something really special that perfectly suits your needs. This is my test message!</p>'),
	(9,301,1,'2020-12-16 12:18:09','2020-12-16 12:18:09','aec8f71b-b3f9-4f0f-b2b8-3329b6fcafed','Ready to start your adventure?','<p>Start by picking your desired <a href=\"#activity\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">activity</a>, <a href=\"#destination\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">destination</a>, <a href=\"#package\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">package</a> or <a href=\"#contact%20us\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">contact us</a> and we\'ll tailor something really special that perfectly suits your needs. This is my test message!</p>'),
	(10,306,1,'2020-12-16 12:19:23','2020-12-16 12:19:23','c637039f-3fd6-4032-a046-e071fff95dab','Ready to start your adventure?','<p>Start by picking your desired <a href=\"#activity\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">activity</a>, <a href=\"#destination\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">destination</a>, <a href=\"#package\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">package</a> or <a href=\"#contact%20us\" class=\"text-orange-600 border-b-2 border-orange-600 border-dotted hover:border-orange-700 hover:text-orange-700 transition duration-500 ease-in-out\">contact us</a> and we\'ll tailor something really special that perfectly suits your needs. This is my test message!</p>');

/*!40000 ALTER TABLE `matrixcontent_centredcontent` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table matrixcontent_hero
# ------------------------------------------------------------

DROP TABLE IF EXISTS `matrixcontent_hero`;

CREATE TABLE `matrixcontent_hero` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_hero_aspectRatio` varchar(255) DEFAULT NULL,
  `field_hero_imagesTitle` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixcontent_hero_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `matrixcontent_hero_siteId_fk` (`siteId`),
  CONSTRAINT `matrixcontent_hero_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixcontent_hero_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `matrixcontent_hero` WRITE;
/*!40000 ALTER TABLE `matrixcontent_hero` DISABLE KEYS */;

INSERT INTO `matrixcontent_hero` (`id`, `elementId`, `siteId`, `dateCreated`, `dateUpdated`, `uid`, `field_hero_aspectRatio`, `field_hero_imagesTitle`)
VALUES
	(1,127,1,'2020-12-09 19:11:11','2020-12-14 23:15:24','47a68baf-3d7e-4009-861e-9a2a6d68fabe','13','This is my hero :)'),
	(2,129,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','41fe563e-bbb8-4547-8466-491af07978ba','13',NULL),
	(3,139,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','c3daf9e6-f9f7-43c5-9f6c-ac8081cc5946','13',NULL),
	(4,149,1,'2020-12-09 22:35:36','2020-12-09 22:35:36','d36530f2-94a7-4656-9552-3fdbaa23c11b','13','This is my hero :)'),
	(5,159,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','31d49a64-d933-474e-b250-308945992478','13','This is my hero :)'),
	(6,170,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','7620a274-a9b1-4e10-9512-e3e37e4f0387','13','This is my hero :)'),
	(7,181,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','a247acbe-88b5-404c-b910-05ef7479d3f3','13','This is my hero :)'),
	(8,192,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','eeb40738-9a40-4e59-82cf-2bd53474581e','13','This is my hero :)'),
	(9,203,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','26885e57-eb93-405d-9187-d800b76baf31','13','This is my hero :)'),
	(10,214,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','74cb0b88-0bbd-40f6-8116-481a1a8e5b3b','13','This is my hero :)'),
	(11,226,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','72c7d061-2259-41fc-981f-adcef87370ea','13','This is my hero :)'),
	(12,238,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','59b37f59-ce75-47bd-a8bf-f0220d4010de','13','This is my hero :)'),
	(13,250,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','a48d738f-f009-488b-84a5-533528cf61b4','13','This is my hero :)'),
	(14,259,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','01695221-3205-430d-9698-6c9da7e68236','13','This is my hero :)'),
	(15,268,1,'2020-12-10 00:34:13','2020-12-10 00:34:13','7d79708a-d74f-4a94-b070-a2d18af3d847','13','This is my hero :)'),
	(16,273,1,'2020-12-10 00:34:53','2020-12-10 00:34:53','bc39a249-999f-4ef5-ad1a-6e48e9c6506e','13','This is my hero :)'),
	(17,278,1,'2020-12-14 23:15:24','2020-12-14 23:15:24','815cb27f-07c7-403d-bb82-de081055d7f5','13','This is my hero :)'),
	(18,283,1,'2020-12-16 06:04:29','2020-12-16 06:04:29','42c0406d-3401-49c6-bb73-da3113690dc3','13','This is my hero :)'),
	(19,288,1,'2020-12-16 06:05:08','2020-12-16 06:05:08','70bcf224-9513-47ae-9144-59e1cfda5eb5','13','This is my hero :)'),
	(20,293,1,'2020-12-16 06:13:57','2020-12-16 06:13:57','b9a10ad0-34ea-46d7-b6e9-2dface408820','13','This is my hero :)'),
	(21,298,1,'2020-12-16 12:18:09','2020-12-16 12:18:09','44239d1f-9f5d-4f35-b7ac-8acd52b973a4','13','This is my hero :)'),
	(22,303,1,'2020-12-16 12:19:22','2020-12-16 12:19:22','a59f8bf1-c146-4919-bce4-0919457987d7','13','This is my hero :)');

/*!40000 ALTER TABLE `matrixcontent_hero` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table matrixcontent_listing
# ------------------------------------------------------------

DROP TABLE IF EXISTS `matrixcontent_listing`;

CREATE TABLE `matrixcontent_listing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_listing_aspectRatio` varchar(255) DEFAULT NULL,
  `field_listing_listingTitle` text,
  `field_listing_listingCopy` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matrixcontent_listing_elementId_siteId_unq_idx` (`elementId`,`siteId`),
  KEY `matrixcontent_listing_siteId_fk` (`siteId`),
  CONSTRAINT `matrixcontent_listing_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matrixcontent_listing_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `matrixcontent_listing` WRITE;
/*!40000 ALTER TABLE `matrixcontent_listing` DISABLE KEYS */;

INSERT INTO `matrixcontent_listing` (`id`, `elementId`, `siteId`, `dateCreated`, `dateUpdated`, `uid`, `field_listing_aspectRatio`, `field_listing_listingTitle`, `field_listing_listingCopy`)
VALUES
	(1,168,1,'2020-12-09 22:56:06','2020-12-09 23:18:20','4b29b4ce-f194-4d09-8764-61a5c7ceeab6','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(2,171,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','82206d24-b040-4807-9b7e-e3624f3849f1','169',NULL,NULL),
	(3,182,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','c9e53b9a-30ce-4579-91bb-1378d985fff0','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(4,193,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','d582ab7a-5a3b-4e1c-a645-770db8021a80','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(5,204,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','c160f4d9-2f18-4e2a-9321-e9c798c1dd7c','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(6,215,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','e406b84d-33a3-41be-bcd7-a6a741a3c9d2','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(7,227,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','905427e6-c34f-4b17-937b-7329b070707e','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(8,239,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','f4cc9c44-b548-4f1f-b01d-8d0ff7918e29','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(9,251,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','7f84ae3f-694e-4a85-9836-8ef3640bc372','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(10,260,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','629c62e5-54b2-4ae0-b1f2-9d1e2ffbaef9','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(11,269,1,'2020-12-10 00:34:13','2020-12-10 00:34:13','cedb56fb-79d2-4843-899d-15aec8206b4a','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(12,274,1,'2020-12-10 00:34:53','2020-12-10 00:34:53','10296544-a03a-420d-9e53-d4eea0d617c2','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(13,279,1,'2020-12-14 23:15:24','2020-12-14 23:15:24','76d53d95-210d-4114-b018-c9772be7f2a4','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(14,284,1,'2020-12-16 06:04:29','2020-12-16 06:04:29','014d6969-1893-43b4-b11c-dfb0fee70adb','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(15,289,1,'2020-12-16 06:05:09','2020-12-16 06:05:09','63fcd5b2-d6e8-4a8b-a9c1-779e3056c2da','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(16,294,1,'2020-12-16 06:13:58','2020-12-16 06:13:58','bfa13bd9-3d5c-4fb7-a512-d6780372d67b','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(17,299,1,'2020-12-16 12:18:09','2020-12-16 12:18:09','1849d713-93f5-4d73-8897-3ca9bb6b8a4d','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>'),
	(18,304,1,'2020-12-16 12:19:22','2020-12-16 12:19:22','4af99db3-c224-4e41-8766-4543f82c5dc2','169','Connecting people and places through amazing','<p>We harness the power of nature and travel to help people get rebalanced, reinvigorated and reconnect with what really matters in life. <br /></p>\n<p> Our main goal is to take you out of the grind of daily life and help you experience exceptional places, incredible moments and life changing connections.</p>');

/*!40000 ALTER TABLE `matrixcontent_listing` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `migrations_track_name_unq_idx` (`track`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;

INSERT INTO `migrations` (`id`, `track`, `name`, `applyTime`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(3,'plugin:redactor','m180430_204710_remove_old_plugins','2020-12-07 08:31:18','2020-12-07 08:31:18','2020-12-07 08:31:18','f73458af-1003-4057-ae92-3a58775224a7'),
	(4,'plugin:redactor','Install','2020-12-07 08:31:18','2020-12-07 08:31:18','2020-12-07 08:31:18','33c2b8ae-8c5e-4157-86d6-301560c8981d'),
	(5,'plugin:redactor','m190225_003922_split_cleanup_html_settings','2020-12-07 08:31:18','2020-12-07 08:31:18','2020-12-07 08:31:18','6b070472-3f6e-4bbe-aa8d-845de04d605a'),
	(6,'craft','Install','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','901ea9c8-7e05-4bfe-b3bc-74e238fda40d'),
	(7,'craft','m150403_183908_migrations_table_changes','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','b187c2de-45b4-4e9d-b4b7-79024fe3ff46'),
	(8,'craft','m150403_184247_plugins_table_changes','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','7c6add69-1936-4bb4-81ab-365558f7c9eb'),
	(9,'craft','m150403_184533_field_version','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','ddb62451-29cf-4315-b93a-4e559f256d80'),
	(10,'craft','m150403_184729_type_columns','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','1a169d49-0c77-4d86-bb2e-4431c90d74b7'),
	(11,'craft','m150403_185142_volumes','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','94d695e7-d03a-4c35-b62b-100d70db120d'),
	(12,'craft','m150428_231346_userpreferences','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','ad47fb20-5085-4436-9aba-da1853133ecc'),
	(13,'craft','m150519_150900_fieldversion_conversion','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','1bfc8ec1-2c79-46ba-9b6c-1c272b13a848'),
	(14,'craft','m150617_213829_update_email_settings','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','fcdc5072-bab2-4d0a-af77-b2614987c860'),
	(15,'craft','m150721_124739_templatecachequeries','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','07afc419-85c9-40b8-a26b-1dcb4b220abe'),
	(16,'craft','m150724_140822_adjust_quality_settings','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','cce922be-027f-4357-b9c2-1a005bc9373b'),
	(17,'craft','m150815_133521_last_login_attempt_ip','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','4f7a937a-c900-426b-84c9-1e5d6fae6afb'),
	(18,'craft','m151002_095935_volume_cache_settings','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','4b83e5a2-941d-4ba0-823a-6f3c7b16485f'),
	(19,'craft','m151005_142750_volume_s3_storage_settings','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','8650dd8a-b22f-4401-8fc7-07244ecd083a'),
	(20,'craft','m151016_133600_delete_asset_thumbnails','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','e9a0dacb-df65-4180-9541-c405e7d9dd59'),
	(21,'craft','m151209_000000_move_logo','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','b263181a-a1ef-4816-9415-1e32e585f626'),
	(22,'craft','m151211_000000_rename_fileId_to_assetId','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','cbc90808-4490-49e2-92d3-2e712c69c3cf'),
	(23,'craft','m151215_000000_rename_asset_permissions','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','91996775-3075-478f-aa9d-f3531ef0277a'),
	(24,'craft','m160707_000001_rename_richtext_assetsource_setting','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','9e8b0206-05c5-43f0-8e34-dae3165cb0dc'),
	(25,'craft','m160708_185142_volume_hasUrls_setting','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','7d45054e-8628-42bd-bedd-54b67d74b61d'),
	(26,'craft','m160714_000000_increase_max_asset_filesize','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','ac69319f-bb9d-40f9-a508-ea84645e3d09'),
	(27,'craft','m160727_194637_column_cleanup','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','bebcc082-611a-450b-aa87-eb051fbb77cc'),
	(28,'craft','m160804_110002_userphotos_to_assets','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','54058e5c-d3a8-46e4-ad16-74550b50d6be'),
	(29,'craft','m160807_144858_sites','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','90684b83-f452-4703-a78e-0f3b9e100547'),
	(30,'craft','m160829_000000_pending_user_content_cleanup','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','abae3771-07fb-4305-bd9c-3bf09a9120c9'),
	(31,'craft','m160830_000000_asset_index_uri_increase','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','f9e9e1b8-2280-4628-a5ab-f36bb7d2d7f0'),
	(32,'craft','m160912_230520_require_entry_type_id','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','83fc5be8-b12b-479d-85dc-449d23a35322'),
	(33,'craft','m160913_134730_require_matrix_block_type_id','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','0c8f3d0b-60d1-42e4-a76f-54718a927e5b'),
	(34,'craft','m160920_174553_matrixblocks_owner_site_id_nullable','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','e6ba254c-fb4d-44f9-8b63-29bf9c6a8313'),
	(35,'craft','m160920_231045_usergroup_handle_title_unique','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','ede5fcff-5d76-47cc-9afe-78b36a7b2679'),
	(36,'craft','m160925_113941_route_uri_parts','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','1fb33db8-8449-40f6-93ec-16b4a8e9af44'),
	(37,'craft','m161006_205918_schemaVersion_not_null','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','e2f33742-713e-4956-b28c-e977b5b1ae97'),
	(38,'craft','m161007_130653_update_email_settings','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','221e6c0a-b219-4baa-941d-0cb657da97ed'),
	(39,'craft','m161013_175052_newParentId','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','4557d32a-0b75-4633-85e0-febe81964162'),
	(40,'craft','m161021_102916_fix_recent_entries_widgets','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','be2dd6e7-93ca-4cad-8b75-11b02e49fbc8'),
	(41,'craft','m161021_182140_rename_get_help_widget','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','0383876a-f873-4ccc-9374-e8f8496f91a6'),
	(42,'craft','m161025_000000_fix_char_columns','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','50ab0541-0821-4288-94b3-18ef0ede13f0'),
	(43,'craft','m161029_124145_email_message_languages','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','140639df-18be-4dd8-bb7d-2d63b911ac67'),
	(44,'craft','m161108_000000_new_version_format','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','7838fada-a01c-4914-a9fc-410bb420b91e'),
	(45,'craft','m161109_000000_index_shuffle','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','26c022cb-392a-488f-b22e-956ca9967bac'),
	(46,'craft','m161122_185500_no_craft_app','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','fa117527-e035-422d-b052-02345e5cc1ed'),
	(47,'craft','m161125_150752_clear_urlmanager_cache','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','317897b9-e122-42ad-8083-886e7c1d0f21'),
	(48,'craft','m161220_000000_volumes_hasurl_notnull','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','dabdac82-5615-46c4-90ed-2cf7bbeea459'),
	(49,'craft','m170114_161144_udates_permission','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','378ac33a-bd56-444c-8687-c2484ec0d4ab'),
	(50,'craft','m170120_000000_schema_cleanup','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','3d577a28-f1e0-4fa9-8423-6d147c8202a3'),
	(51,'craft','m170126_000000_assets_focal_point','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','9ead378a-284e-4664-812c-458358a6e2c4'),
	(52,'craft','m170206_142126_system_name','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','fe3186f7-60a4-4dcb-93a3-c484c3a35434'),
	(53,'craft','m170217_044740_category_branch_limits','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','a7b68663-b99d-4771-9f26-8f1b68ecb114'),
	(54,'craft','m170217_120224_asset_indexing_columns','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','207c98a6-e438-4524-90ad-b7ca2cfd9e93'),
	(55,'craft','m170223_224012_plain_text_settings','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','b764c176-07b3-4512-a5df-7d1f4fc046f3'),
	(56,'craft','m170227_120814_focal_point_percentage','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','1ba08508-1888-4c09-925f-6406fbffb29c'),
	(57,'craft','m170228_171113_system_messages','2020-12-07 08:31:23','2020-12-07 08:31:23','2020-12-07 08:31:23','979f9f98-92f9-4c2f-ad8a-c3253607e4f8'),
	(58,'craft','m170303_140500_asset_field_source_settings','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','d581f20a-d08f-4d8b-bf34-aa41f8c30734'),
	(59,'craft','m170306_150500_asset_temporary_uploads','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','83782a26-7922-44e5-9fff-568f1b3c4683'),
	(60,'craft','m170523_190652_element_field_layout_ids','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','f175bf89-d837-4adc-99c2-dcb4211a589f'),
	(61,'craft','m170621_195237_format_plugin_handles','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','8be334e6-5f5e-4b7c-b567-75ae9de283cc'),
	(62,'craft','m170630_161027_deprecation_line_nullable','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','3c921fa2-fb18-4727-a444-3bd5cc2be42d'),
	(63,'craft','m170630_161028_deprecation_changes','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','b5b6b76d-f104-4a73-b994-f91b8acdf0c2'),
	(64,'craft','m170703_181539_plugins_table_tweaks','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','2d717a7d-7f67-4c0a-995d-45ae5e685a69'),
	(65,'craft','m170704_134916_sites_tables','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','e80f03f7-e1cd-431a-9ec2-b60f3d4b7146'),
	(66,'craft','m170706_183216_rename_sequences','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','1ad2a8a5-0338-4b7b-84a1-c87f1af69ffb'),
	(67,'craft','m170707_094758_delete_compiled_traits','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','1cf7d208-5ad5-49b5-bcb6-6dce94847c72'),
	(68,'craft','m170731_190138_drop_asset_packagist','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','9b808c5c-aaa9-48e0-b732-a50dc53fd8c2'),
	(69,'craft','m170810_201318_create_queue_table','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','7d676d27-f897-44c3-805a-21dd034aa61b'),
	(70,'craft','m170903_192801_longblob_for_queue_jobs','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','4cf7c86f-3202-4da7-8e1f-2980b2d71082'),
	(71,'craft','m170914_204621_asset_cache_shuffle','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','4daa20a4-7cde-4c4d-9de9-276cf134f6d4'),
	(72,'craft','m171011_214115_site_groups','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','1f42340e-f24f-4b2b-8fab-10410b791ef2'),
	(73,'craft','m171012_151440_primary_site','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','a768e830-eb67-43e2-b8d2-7cb15196f621'),
	(74,'craft','m171013_142500_transform_interlace','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','58c35f04-5afb-46cc-885e-2e110225510d'),
	(75,'craft','m171016_092553_drop_position_select','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','10a22611-0ada-4a56-9806-e543113fe80b'),
	(76,'craft','m171016_221244_less_strict_translation_method','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','75b813d4-6f8a-4b1a-9db3-70f15ffdbc81'),
	(77,'craft','m171107_000000_assign_group_permissions','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','2eaf0509-d835-4678-a487-2d8787428bcd'),
	(78,'craft','m171117_000001_templatecache_index_tune','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','40561d78-14dc-4921-a44c-0aeaaf115f23'),
	(79,'craft','m171126_105927_disabled_plugins','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','a2db0d9a-bb6a-4533-88fb-744b63f6712c'),
	(80,'craft','m171130_214407_craftidtokens_table','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','5bfd493a-cc97-48e8-8beb-ed41229948a4'),
	(81,'craft','m171202_004225_update_email_settings','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','9a69bfaa-feb5-4ced-a9c0-4658b4e735b4'),
	(82,'craft','m171204_000001_templatecache_index_tune_deux','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','b01a2cbc-a36f-488a-9613-40d34f167f1c'),
	(83,'craft','m171205_130908_remove_craftidtokens_refreshtoken_column','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','8fa0e470-f7ff-4169-9df4-927ceb0869a5'),
	(84,'craft','m171218_143135_longtext_query_column','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','b6e08529-3203-44f1-8b15-df4519328ba9'),
	(85,'craft','m171231_055546_environment_variables_to_aliases','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','54016dc1-7916-45ea-b41b-56023d77c882'),
	(86,'craft','m180113_153740_drop_users_archived_column','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','ee63b1b2-ef32-4285-b3e8-8fb11e5c4f0b'),
	(87,'craft','m180122_213433_propagate_entries_setting','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','d846f9f2-6336-438e-8d68-a1e9c4cb34cf'),
	(88,'craft','m180124_230459_fix_propagate_entries_values','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','50790c0b-fc4b-406f-a4a9-02f57d336103'),
	(89,'craft','m180128_235202_set_tag_slugs','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','62883c72-9367-48c2-a93e-09da826ef4ab'),
	(90,'craft','m180202_185551_fix_focal_points','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','28ccba0d-e5aa-43e2-8838-0813d57fd6be'),
	(91,'craft','m180217_172123_tiny_ints','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','dadb7389-a83e-4237-871f-17a9d937068b'),
	(92,'craft','m180321_233505_small_ints','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','1257c70b-67db-4cd3-9745-63a3107abab9'),
	(93,'craft','m180328_115523_new_license_key_statuses','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','3ce55495-7974-4af4-8707-790abf1bcafc'),
	(94,'craft','m180404_182320_edition_changes','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','496d84b4-2096-4f40-b320-2d0c02789908'),
	(95,'craft','m180411_102218_fix_db_routes','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','61edebf6-57d9-473b-82e9-48a9530867f7'),
	(96,'craft','m180416_205628_resourcepaths_table','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','35edfcd0-36e0-46b5-a044-0efe8fef6567'),
	(97,'craft','m180418_205713_widget_cleanup','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','4c0ec962-71f9-4ff2-a3b1-f0f78c39b105'),
	(98,'craft','m180425_203349_searchable_fields','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','f45d984c-75d6-4f47-b829-283c32c60b3b'),
	(99,'craft','m180516_153000_uids_in_field_settings','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','fe1989a5-e138-41ce-90fb-79b93063aeb2'),
	(100,'craft','m180517_173000_user_photo_volume_to_uid','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','79c356c2-51e7-47b9-b8fc-41b2be540408'),
	(101,'craft','m180518_173000_permissions_to_uid','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','17676e3d-cfa7-425a-95d3-abbd7ca548c6'),
	(102,'craft','m180520_173000_matrix_context_to_uids','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','eccfef20-29d0-4d3e-84d6-833f08ae4739'),
	(103,'craft','m180521_172900_project_config_table','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','03b2486f-b099-442d-a34e-05e1171a2043'),
	(104,'craft','m180521_173000_initial_yml_and_snapshot','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','a732b26e-acaa-4ee4-888f-42c2e5deffa4'),
	(105,'craft','m180731_162030_soft_delete_sites','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','204fd4cb-e89d-41f6-93e0-bb19c25f03b7'),
	(106,'craft','m180810_214427_soft_delete_field_layouts','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','6e71795b-da05-4bf2-9b15-448f7e435005'),
	(107,'craft','m180810_214439_soft_delete_elements','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','6f89c9bb-8ab6-45d5-956c-6c8f13f8e93d'),
	(108,'craft','m180824_193422_case_sensitivity_fixes','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','c1c6981c-738f-4bea-bdc0-ccb7ac632515'),
	(109,'craft','m180901_151639_fix_matrixcontent_tables','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','7b90f3d7-195b-4fdc-869e-aedce2a195c7'),
	(110,'craft','m180904_112109_permission_changes','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','b89c4adf-da7d-4beb-b459-5a77eda9036c'),
	(111,'craft','m180910_142030_soft_delete_sitegroups','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','5c97606f-7fc1-4b9f-87a7-a8174c2bcb16'),
	(112,'craft','m181011_160000_soft_delete_asset_support','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','59e9db07-6849-42d4-9d11-140716b8b06b'),
	(113,'craft','m181016_183648_set_default_user_settings','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','9f42f2e6-1dbe-421d-a670-f835699ea404'),
	(114,'craft','m181017_225222_system_config_settings','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','b5fd9c4d-fb78-4bf4-8b18-0de09e2b7de7'),
	(115,'craft','m181018_222343_drop_userpermissions_from_config','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','1c02b1cd-0412-4e5f-8cc3-3e410d522f7e'),
	(116,'craft','m181029_130000_add_transforms_routes_to_config','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','cf1417e0-c662-41b8-a82a-ae5b4c535df7'),
	(117,'craft','m181112_203955_sequences_table','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','785e0c5a-ab9c-469c-9b37-ae3c37de821e'),
	(118,'craft','m181121_001712_cleanup_field_configs','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','7d083368-3d9a-4438-9697-5d53e83bb0ea'),
	(119,'craft','m181128_193942_fix_project_config','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','019bc65c-efff-4026-bfeb-ffe7d0aa4acd'),
	(120,'craft','m181130_143040_fix_schema_version','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','3a354264-3da2-40e1-a981-0bb18b49eb03'),
	(121,'craft','m181211_143040_fix_entry_type_uids','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','db038051-1c10-49a3-9785-e8a578fb1950'),
	(122,'craft','m181217_153000_fix_structure_uids','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','5bf3a0e7-880a-40f5-b451-b00e9977a57c'),
	(123,'craft','m190104_152725_store_licensed_plugin_editions','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','2eb5343b-6325-4c43-88d0-3d5f13bb6752'),
	(124,'craft','m190108_110000_cleanup_project_config','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','f5d6fd63-bcba-4263-b5bd-8aa419a67373'),
	(125,'craft','m190108_113000_asset_field_setting_change','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','fb0448eb-9d9f-495c-9f2f-2cd8099ab0db'),
	(126,'craft','m190109_172845_fix_colspan','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','c64b1230-1002-49ce-bb02-cb7480e1e5bb'),
	(127,'craft','m190110_150000_prune_nonexisting_sites','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','1da411ed-40ae-4e32-a6f7-07b18e027256'),
	(128,'craft','m190110_214819_soft_delete_volumes','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','1e972808-2db6-4b0e-8d08-bfb60e08d102'),
	(129,'craft','m190112_124737_fix_user_settings','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','3757a714-c231-4701-974e-efa7313e2ad2'),
	(130,'craft','m190112_131225_fix_field_layouts','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','ed03ab0a-a747-488d-9825-8e2ef4fe27f1'),
	(131,'craft','m190112_201010_more_soft_deletes','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','bce1a9b2-ea3a-40b2-b472-6a3dcc82be76'),
	(132,'craft','m190114_143000_more_asset_field_setting_changes','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','26928b1f-5acc-4ee1-92e7-f1eaff9b793e'),
	(133,'craft','m190121_120000_rich_text_config_setting','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','ccf29477-6452-4526-aa05-3a963ef637f7'),
	(134,'craft','m190125_191628_fix_email_transport_password','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','5b596fe0-953f-4b93-b1e0-6979a3e35cf3'),
	(135,'craft','m190128_181422_cleanup_volume_folders','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','b12543b9-8968-4552-bcf6-b736340583af'),
	(136,'craft','m190205_140000_fix_asset_soft_delete_index','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','b29aa834-7aaf-42eb-8afb-70d871d6b600'),
	(137,'craft','m190218_143000_element_index_settings_uid','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','aa431f6a-4128-4f30-a755-ff160953f3ca'),
	(138,'craft','m190312_152740_element_revisions','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','2f216f90-cc70-48da-a91a-cba432861106'),
	(139,'craft','m190327_235137_propagation_method','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','87471095-9715-46b7-b467-0275f193bb1a'),
	(140,'craft','m190401_223843_drop_old_indexes','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','594cde0c-8e08-46f7-90e6-c56db93f8ae3'),
	(141,'craft','m190416_014525_drop_unique_global_indexes','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','098e763d-4254-44c3-bc48-b8a438abf6cf'),
	(142,'craft','m190417_085010_add_image_editor_permissions','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','0362f233-bf5b-4847-9b2a-0519ffc3b3a3'),
	(143,'craft','m190502_122019_store_default_user_group_uid','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','c88ff1e5-7f51-4b94-956b-ec4df7ef8dc1'),
	(144,'craft','m190504_150349_preview_targets','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','3adc302c-a065-4b83-85be-b09c66e99494'),
	(145,'craft','m190516_184711_job_progress_label','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','7311b969-77ac-4a2b-9a98-d484b95d6249'),
	(146,'craft','m190523_190303_optional_revision_creators','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','47f2bb96-1ef7-45eb-a4bb-a43fe9c4d576'),
	(147,'craft','m190529_204501_fix_duplicate_uids','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','aa25b2d4-f7ce-4c10-9619-d0c656cf2187'),
	(148,'craft','m190605_223807_unsaved_drafts','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','c166594b-503d-4080-b1c7-4611266a7a8b'),
	(149,'craft','m190607_230042_entry_revision_error_tables','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','2c77207b-c313-459b-9d49-1947f0067afd'),
	(150,'craft','m190608_033429_drop_elements_uid_idx','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','61486b32-e201-467e-a903-ee82cf930400'),
	(151,'craft','m190617_164400_add_gqlschemas_table','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','bb437c1f-46d7-4959-8587-9ed9eecbe08d'),
	(152,'craft','m190624_234204_matrix_propagation_method','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','e6b93db1-b55d-44d2-beef-94374d0c5355'),
	(153,'craft','m190711_153020_drop_snapshots','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','ba6449df-4a86-46e2-9740-59673fe6ad24'),
	(154,'craft','m190712_195914_no_draft_revisions','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','e5932a8d-bc3d-4656-ad2d-9ca02c1ce536'),
	(155,'craft','m190723_140314_fix_preview_targets_column','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','7ed4f368-c4b6-4d39-b55e-9e66d8d0583f'),
	(156,'craft','m190820_003519_flush_compiled_templates','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','66d155b6-9389-4241-a1e9-8bfa02ce8a2b'),
	(157,'craft','m190823_020339_optional_draft_creators','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','dfb2c3a4-520c-4a75-89de-9f6d896f9a6d'),
	(158,'craft','m190913_152146_update_preview_targets','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','a85e4f92-1dd4-40cd-a0f2-540e09479b7f'),
	(159,'craft','m191107_122000_add_gql_project_config_support','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','82a5cdb7-fa8c-4e33-8af5-ad6014357110'),
	(160,'craft','m191204_085100_pack_savable_component_settings','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','cfef390d-12d9-4216-a238-6e626bf9fc92'),
	(161,'craft','m191206_001148_change_tracking','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','3ab4b361-fbda-42ee-a3f0-320f75033cff'),
	(162,'craft','m191216_191635_asset_upload_tracking','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','ad150c66-2842-4bdc-8b08-e4e6f8e10b6a'),
	(163,'craft','m191222_002848_peer_asset_permissions','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','fd72daff-d3dc-42b5-b530-8458eeb646b7'),
	(164,'craft','m200127_172522_queue_channels','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','3b39443f-7e25-4617-8302-2c627dc8a354'),
	(165,'craft','m200211_175048_truncate_element_query_cache','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','985773dd-6f14-4f75-8009-8c532ff0c0b6'),
	(166,'craft','m200213_172522_new_elements_index','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','e337772a-5623-4c8a-86e4-58bdfdc19ccc'),
	(167,'craft','m200228_195211_long_deprecation_messages','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','a4bf7542-2c2c-4a0f-81c1-8bc2d968ef6d'),
	(168,'craft','m200306_054652_disabled_sites','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','438c08a2-2205-4d80-a2ce-6d20f36e9572'),
	(169,'craft','m200522_191453_clear_template_caches','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','d506f29a-dbaa-473c-812f-9264e9287ad0'),
	(170,'craft','m200606_231117_migration_tracks','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','4f85d71f-4cc1-476d-922e-b99efefccba9'),
	(171,'craft','m200619_215137_title_translation_method','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','9d17ee89-0a45-4f17-bca5-5cf24d1190a5'),
	(172,'craft','m200620_005028_user_group_descriptions','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','b6a8ad0b-057a-40f9-9409-1c4f26d3217c'),
	(173,'craft','m200620_230205_field_layout_changes','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','706175ca-67c3-4d19-a113-d6e7c36bf006'),
	(174,'craft','m200625_131100_move_entrytypes_to_top_project_config','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','a66f8130-1146-4a04-9363-7a46412e1291'),
	(175,'craft','m200629_112700_remove_project_config_legacy_files','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','73a0fb09-113a-4dc9-b722-c7a633245a91'),
	(176,'craft','m200630_183000_drop_configmap','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','d04de943-1f6c-4279-b80f-83b86b04ee48'),
	(177,'craft','m200715_113400_transform_index_error_flag','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','f2aad6a3-ee78-497b-ba84-7dd186e03103'),
	(178,'craft','m200716_110900_replace_file_asset_permissions','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','bdbdd351-8334-44c9-85ae-b6ca79a3efb2'),
	(179,'craft','m200716_153800_public_token_settings_in_project_config','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','889ee858-d5ac-4efb-8e7b-922be835f648'),
	(180,'craft','m200720_175543_drop_unique_constraints','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','48c53824-52e7-4631-a21d-f5edd8f088bc'),
	(181,'craft','m200825_051217_project_config_version','2020-12-07 08:31:24','2020-12-07 08:31:24','2020-12-07 08:31:24','115f3645-90be-45a9-ab75-6bb843f1713d');

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table plugins
# ------------------------------------------------------------

DROP TABLE IF EXISTS `plugins`;

CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `plugins_handle_unq_idx` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;

INSERT INTO `plugins` (`id`, `handle`, `version`, `schemaVersion`, `licenseKeyStatus`, `licensedEdition`, `installDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,'assetrev','6.0.2','1.0.0','unknown',NULL,'2020-12-07 08:31:18','2020-12-07 08:31:18','2021-01-02 22:43:51','f52e0eb9-868c-4a0e-8003-f82bac0c3513'),
	(3,'oembed','1.3.6','1.0.1','unknown',NULL,'2020-12-07 08:31:18','2020-12-07 08:31:18','2021-01-02 22:43:51','0f1cf44d-c7c5-4fd0-bc1c-e586f893e937'),
	(4,'redactor','2.8.4','2.3.0','unknown',NULL,'2020-12-07 08:31:18','2020-12-07 08:31:18','2021-01-02 22:43:51','b3991bbc-9169-4023-9b95-48af7f876f76'),
	(5,'typogrify','1.1.18','1.0.0','unknown',NULL,'2020-12-07 08:31:18','2020-12-07 08:31:18','2021-01-02 22:43:51','97489dbd-40ae-4ca4-9e2b-d08b1e4ca341');

/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table projectconfig
# ------------------------------------------------------------

DROP TABLE IF EXISTS `projectconfig`;

CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;

INSERT INTO `projectconfig` (`path`, `value`)
VALUES
	('dateModified','1607560294'),
	('email.fromEmail','\"sam@craftcms.com\"'),
	('email.fromName','\"Craft Blog\"'),
	('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.autocapitalize','true'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.autocomplete','false'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.autocorrect','true'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.class','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.disabled','false'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.id','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.instructions','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.label','\"\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.max','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.min','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.name','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.orientation','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.placeholder','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.readonly','false'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.requirable','false'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.size','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.step','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.tip','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.title','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\EntryTitleField\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.warning','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.0.width','100'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.1.fieldUid','\"5b3791ab-899f-4db6-b8d9-912a0aa18d87\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.1.instructions','\"\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.1.label','\"Hero\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.1.required','\"\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.1.tip','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.1.warning','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.1.width','100'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.2.fieldUid','\"5078004c-4379-4cfc-8931-f386cbe3dbbc\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.2.instructions','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.2.label','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.2.required','false'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.2.tip','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.2.warning','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.2.width','100'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.3.fieldUid','\"2f2878ed-1f33-4e42-a96d-66215377c511\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.3.instructions','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.3.label','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.3.required','false'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.3.tip','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.3.warning','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.3.width','100'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.4.fieldUid','\"d8a19f7f-5bcc-4035-89a4-c0b3befd9f96\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.4.instructions','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.4.label','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.4.required','false'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.4.tip','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.4.warning','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.4.width','100'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.5.fieldUid','\"e567b6ab-3855-452b-a337-4c119dac4d62\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.5.instructions','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.5.label','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.5.required','false'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.5.tip','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.5.warning','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.elements.5.width','100'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.name','\"Content\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.fieldLayouts.434b8bff-3f8f-4c04-b4e1-43001b019d73.tabs.0.sortOrder','1'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.handle','\"home\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.hasTitleField','false'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.name','\"Home\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.section','\"4593234a-cdd0-4c54-9931-4eb606b9e7f5\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.sortOrder','1'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.titleFormat','\"{section.name|raw}\"'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.titleTranslationKeyFormat','null'),
	('entryTypes.8518a799-a012-4a6c-aa89-6a347cc00c2e.titleTranslationMethod','\"\"'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.fieldLayouts.abfbb4c4-848b-4bbb-a8ab-fa5edb8941b6.tabs.0.elements.0.instructions','null'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.fieldLayouts.abfbb4c4-848b-4bbb-a8ab-fa5edb8941b6.tabs.0.elements.0.label','\"Title\"'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.fieldLayouts.abfbb4c4-848b-4bbb-a8ab-fa5edb8941b6.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\EntryTitleField\"'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.fieldLayouts.abfbb4c4-848b-4bbb-a8ab-fa5edb8941b6.tabs.0.elements.1.fieldUid','\"5e76b2e3-1eae-4bbc-93f4-122fe4526b02\"'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.fieldLayouts.abfbb4c4-848b-4bbb-a8ab-fa5edb8941b6.tabs.0.elements.1.required','false'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.fieldLayouts.abfbb4c4-848b-4bbb-a8ab-fa5edb8941b6.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.fieldLayouts.abfbb4c4-848b-4bbb-a8ab-fa5edb8941b6.tabs.0.elements.2.fieldUid','\"e567b6ab-3855-452b-a337-4c119dac4d62\"'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.fieldLayouts.abfbb4c4-848b-4bbb-a8ab-fa5edb8941b6.tabs.0.elements.2.required','false'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.fieldLayouts.abfbb4c4-848b-4bbb-a8ab-fa5edb8941b6.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.fieldLayouts.abfbb4c4-848b-4bbb-a8ab-fa5edb8941b6.tabs.0.name','\"Content\"'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.fieldLayouts.abfbb4c4-848b-4bbb-a8ab-fa5edb8941b6.tabs.0.sortOrder','1'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.handle','\"blog\"'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.hasTitleField','true'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.name','\"Blog\"'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.section','\"db2dff45-19b4-479c-8cba-ab88e7e7d2fd\"'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.sortOrder','1'),
	('entryTypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b.titleFormat','\"\"'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.fieldLayouts.0476a59c-d8e9-40fd-bce3-4ba321daf851.tabs.0.elements.0.instructions','null'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.fieldLayouts.0476a59c-d8e9-40fd-bce3-4ba321daf851.tabs.0.elements.0.label','\"\"'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.fieldLayouts.0476a59c-d8e9-40fd-bce3-4ba321daf851.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\EntryTitleField\"'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.fieldLayouts.0476a59c-d8e9-40fd-bce3-4ba321daf851.tabs.0.elements.1.fieldUid','\"e567b6ab-3855-452b-a337-4c119dac4d62\"'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.fieldLayouts.0476a59c-d8e9-40fd-bce3-4ba321daf851.tabs.0.elements.1.required','false'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.fieldLayouts.0476a59c-d8e9-40fd-bce3-4ba321daf851.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.fieldLayouts.0476a59c-d8e9-40fd-bce3-4ba321daf851.tabs.0.name','\"Content\"'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.fieldLayouts.0476a59c-d8e9-40fd-bce3-4ba321daf851.tabs.0.sortOrder','1'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.handle','\"about\"'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.hasTitleField','false'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.name','\"About\"'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.section','\"5a80053a-6435-4fd2-8a47-53e409d994ad\"'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.sortOrder','1'),
	('entryTypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc.titleFormat','\"{section.name|raw}\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.autocapitalize','true'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.autocomplete','false'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.autocorrect','true'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.class','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.disabled','false'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.id','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.instructions','\"\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.label','\"Package Name\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.max','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.min','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.name','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.orientation','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.placeholder','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.readonly','false'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.requirable','false'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.size','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.step','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.tip','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.title','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\EntryTitleField\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.warning','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.0.width','100'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.1.fieldUid','\"baf92585-f5fa-4c8f-b0c1-bdf44702738a\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.1.instructions','\"\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.1.label','\"Package Intro\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.1.required','\"\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.1.tip','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.1.warning','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.1.width','100'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.2.fieldUid','\"967c78dc-e17a-4909-a832-9f5151b2332c\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.2.instructions','\"\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.2.label','\"Packages Copy\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.2.required','\"\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.2.tip','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.2.warning','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.2.width','100'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.3.fieldUid','\"e567b6ab-3855-452b-a337-4c119dac4d62\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.3.instructions','\"\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.3.label','\"Package Content\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.3.required','\"\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.3.tip','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.3.warning','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.3.width','100'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.4.fieldUid','\"f1609569-63ed-461e-a6dd-ef9bd55265cd\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.4.instructions','\"\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.4.label','\"Package Image\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.4.required','\"\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.4.tip','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.4.warning','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.elements.4.width','100'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.name','\"Package Details\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.fieldLayouts.6e08a29d-0e72-41b4-aac3-6b49a25d15eb.tabs.0.sortOrder','1'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.handle','\"packages\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.hasTitleField','true'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.name','\"Packages\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.section','\"0d7d6141-cec6-4acc-9665-0f722f1518f5\"'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.sortOrder','1'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.titleFormat','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.titleTranslationKeyFormat','null'),
	('entryTypes.e4ada667-7f26-4d24-95f6-a2576ecade28.titleTranslationMethod','\"site\"'),
	('fieldGroups.911477c7-3c92-407b-a9a9-e69ccb74eabb.name','\"Common\"'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.contentColumnType','\"string\"'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.fieldGroup','\"911477c7-3c92-407b-a9a9-e69ccb74eabb\"'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.handle','\"cards\"'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.instructions','\"\"'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.name','\"Cards\"'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.searchable','true'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.settings.contentTable','\"{{%matrixcontent_cards}}\"'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.settings.maxBlocks','\"\"'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.settings.minBlocks','\"\"'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.settings.propagationMethod','\"all\"'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.translationKeyFormat','null'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.translationMethod','\"site\"'),
	('fields.2f2878ed-1f33-4e42-a96d-66215377c511.type','\"craft\\\\fields\\\\Matrix\"'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.contentColumnType','\"string\"'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.fieldGroup','\"911477c7-3c92-407b-a9a9-e69ccb74eabb\"'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.handle','\"listing\"'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.instructions','\"\"'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.name','\"Listing\"'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.searchable','true'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.settings.contentTable','\"{{%matrixcontent_listing}}\"'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.settings.maxBlocks','\"\"'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.settings.minBlocks','\"\"'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.settings.propagationMethod','\"all\"'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.translationKeyFormat','null'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.translationMethod','\"site\"'),
	('fields.5078004c-4379-4cfc-8931-f386cbe3dbbc.type','\"craft\\\\fields\\\\Matrix\"'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.contentColumnType','\"string\"'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.fieldGroup','\"911477c7-3c92-407b-a9a9-e69ccb74eabb\"'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.handle','\"hero\"'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.instructions','\"\"'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.name','\"Hero\"'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.searchable','true'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.settings.contentTable','\"{{%matrixcontent_hero}}\"'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.settings.maxBlocks','\"\"'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.settings.minBlocks','\"\"'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.settings.propagationMethod','\"all\"'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.translationKeyFormat','null'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.translationMethod','\"site\"'),
	('fields.5b3791ab-899f-4db6-b8d9-912a0aa18d87.type','\"craft\\\\fields\\\\Matrix\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.contentColumnType','\"text\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.fieldGroup','\"911477c7-3c92-407b-a9a9-e69ccb74eabb\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.handle','\"summary\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.instructions','\"Summary for the blog index\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.name','\"Summary\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.searchable','true'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.settings.availableTransforms','\"*\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.settings.availableVolumes','\"\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.settings.cleanupHtml','true'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.settings.columnType','\"text\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.settings.purifierConfig','\"\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.settings.purifyHtml','\"1\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.settings.redactorConfig','\"\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.settings.removeEmptyTags','\"1\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.settings.removeInlineStyles','\"1\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.settings.removeNbsp','\"1\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.translationKeyFormat','null'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.translationMethod','\"none\"'),
	('fields.5e76b2e3-1eae-4bbc-93f4-122fe4526b02.type','\"craft\\\\redactor\\\\Field\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.contentColumnType','\"text\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.fieldGroup','\"911477c7-3c92-407b-a9a9-e69ccb74eabb\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.handle','\"pageCopy\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.instructions','\"\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.name','\"Page Copy\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.searchable','true'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.availableTransforms','\"*\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.availableVolumes','\"*\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.cleanupHtml','true'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.columnType','\"text\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.configSelectionMode','\"choose\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.defaultTransform','\"\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.manualConfig','\"\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.purifierConfig','\"\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.purifyHtml','\"1\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.redactorConfig','\"Standard.json\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.removeEmptyTags','\"1\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.removeInlineStyles','\"1\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.removeNbsp','\"1\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.showHtmlButtonForNonAdmins','\"\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.showUnpermittedFiles','false'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.showUnpermittedVolumes','false'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.settings.uiMode','\"enlarged\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.translationKeyFormat','null'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.translationMethod','\"none\"'),
	('fields.967c78dc-e17a-4909-a832-9f5151b2332c.type','\"craft\\\\redactor\\\\Field\"'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.contentColumnType','\"text\"'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.fieldGroup','\"911477c7-3c92-407b-a9a9-e69ccb74eabb\"'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.handle','\"introduction\"'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.instructions','\"Short text on top of section\"'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.name','\"Introduction\"'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.searchable','true'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.settings.byteLimit','null'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.settings.charLimit','null'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.settings.code','\"\"'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.settings.columnType','null'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.settings.initialRows','\"4\"'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.settings.multiline','\"\"'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.settings.placeholder','\"\"'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.settings.uiMode','\"normal\"'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.translationKeyFormat','null'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.translationMethod','\"none\"'),
	('fields.baf92585-f5fa-4c8f-b0c1-bdf44702738a.type','\"craft\\\\fields\\\\PlainText\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.contentColumnType','\"text\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.fieldGroup','\"911477c7-3c92-407b-a9a9-e69ccb74eabb\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.handle','\"caption\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.instructions','\"\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.name','\"Caption\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.searchable','true'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.settings.charLimit','\"\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.settings.code','\"\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.settings.columnType','\"text\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.settings.initialRows','\"4\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.settings.multiline','\"\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.settings.placeholder','\"\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.translationKeyFormat','null'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.translationMethod','\"none\"'),
	('fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.type','\"craft\\\\fields\\\\PlainText\"'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.contentColumnType','\"string\"'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.fieldGroup','\"911477c7-3c92-407b-a9a9-e69ccb74eabb\"'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.handle','\"centredContent\"'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.instructions','\"\"'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.name','\"Centred Content\"'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.searchable','false'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.settings.contentTable','\"{{%matrixcontent_centredcontent}}\"'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.settings.maxBlocks','\"\"'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.settings.minBlocks','\"\"'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.settings.propagationMethod','\"all\"'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.translationKeyFormat','null'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.translationMethod','\"site\"'),
	('fields.d8a19f7f-5bcc-4035-89a4-c0b3befd9f96.type','\"craft\\\\fields\\\\Matrix\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.contentColumnType','\"text\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.fieldGroup','\"911477c7-3c92-407b-a9a9-e69ccb74eabb\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.handle','\"imageAlt\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.instructions','\"Optional text for the `<img>` tag `alt` attribute.\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.name','\"Image Alt\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.searchable','true'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.settings.charLimit','\"\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.settings.code','\"\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.settings.columnType','\"text\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.settings.initialRows','\"4\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.settings.multiline','\"\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.settings.placeholder','\"\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.translationKeyFormat','null'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.translationMethod','\"none\"'),
	('fields.db95de40-4dec-44cc-9d17-bba2223c91cf.type','\"craft\\\\fields\\\\PlainText\"'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.contentColumnType','\"string\"'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.fieldGroup','\"911477c7-3c92-407b-a9a9-e69ccb74eabb\"'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.handle','\"bodyContent\"'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.instructions','\"\"'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.name','\"Body Content\"'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.searchable','true'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.settings.contentTable','\"{{%matrixcontent_bodycontent}}\"'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.settings.maxBlocks','\"\"'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.settings.minBlocks','\"\"'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.settings.propagationMethod','\"all\"'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.translationKeyFormat','null'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.translationMethod','\"site\"'),
	('fields.e567b6ab-3855-452b-a337-4c119dac4d62.type','\"craft\\\\fields\\\\Matrix\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.contentColumnType','\"string\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.fieldGroup','\"911477c7-3c92-407b-a9a9-e69ccb74eabb\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.handle','\"imagePic\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.instructions','\"\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.name','\"Image Pic\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.searchable','true'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.allowedKinds','null'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.allowSelfRelations','false'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.allowUploads','true'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.defaultUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.defaultUploadLocationSubpath','\"\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.limit','\"\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.localizeRelations','false'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.previewMode','\"full\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.restrictFiles','\"\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.selectionLabel','\"\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.showSiteMenu','true'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.showUnpermittedFiles','false'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.showUnpermittedVolumes','false'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.singleUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.singleUploadLocationSubpath','\"\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.source','null'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.sources','\"*\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.targetSiteId','null'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.useSingleFolder','false'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.validateRelatedElements','false'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.settings.viewMode','\"list\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.translationKeyFormat','null'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.translationMethod','\"site\"'),
	('fields.f1609569-63ed-461e-a6dd-ef9bd55265cd.type','\"craft\\\\fields\\\\Assets\"'),
	('graphql.publicToken.enabled','true'),
	('graphql.publicToken.expiryDate','null'),
	('graphql.schemas.265d76a5-d5a9-4c82-bee4-2f8450aacd0a.isPublic','true'),
	('graphql.schemas.265d76a5-d5a9-4c82-bee4-2f8450aacd0a.name','\"Public Schema\"'),
	('graphql.schemas.55cd92b3-363e-4573-ad2c-04650483ba64.isPublic','false'),
	('graphql.schemas.55cd92b3-363e-4573-ad2c-04650483ba64.name','\"Gatsby\"'),
	('graphql.schemas.55cd92b3-363e-4573-ad2c-04650483ba64.scope.0','\"sections.5a80053a-6435-4fd2-8a47-53e409d994ad:read\"'),
	('graphql.schemas.55cd92b3-363e-4573-ad2c-04650483ba64.scope.1','\"entrytypes.dbd1be32-5e0d-4483-92a5-cc47aba67dcc:read\"'),
	('graphql.schemas.55cd92b3-363e-4573-ad2c-04650483ba64.scope.2','\"sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd:read\"'),
	('graphql.schemas.55cd92b3-363e-4573-ad2c-04650483ba64.scope.3','\"entrytypes.bb6d289b-c3cf-4a8d-9324-b98cbd32753b:read\"'),
	('graphql.schemas.55cd92b3-363e-4573-ad2c-04650483ba64.scope.4','\"sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5:read\"'),
	('graphql.schemas.55cd92b3-363e-4573-ad2c-04650483ba64.scope.5','\"entrytypes.8518a799-a012-4a6c-aa89-6a347cc00c2e:read\"'),
	('graphql.schemas.55cd92b3-363e-4573-ad2c-04650483ba64.scope.6','\"volumes.101a70a1-d200-4629-91e5-3425a0937c0e:read\"'),
	('graphql.schemas.55cd92b3-363e-4573-ad2c-04650483ba64.scope.7','\"usergroups.everyone:read\"'),
	('graphql.schemas.55cd92b3-363e-4573-ad2c-04650483ba64.scope.8','\"gatsby:read\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.field','\"e567b6ab-3855-452b-a337-4c119dac4d62\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fieldLayouts.59ffc94b-a1a3-4ecb-98e4-67dbd4317f23.tabs.0.elements.0.fieldUid','\"df3a27ff-e318-422f-8ff5-d626eda8ce54\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fieldLayouts.59ffc94b-a1a3-4ecb-98e4-67dbd4317f23.tabs.0.elements.0.instructions','null'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fieldLayouts.59ffc94b-a1a3-4ecb-98e4-67dbd4317f23.tabs.0.elements.0.label','null'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fieldLayouts.59ffc94b-a1a3-4ecb-98e4-67dbd4317f23.tabs.0.elements.0.required','false'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fieldLayouts.59ffc94b-a1a3-4ecb-98e4-67dbd4317f23.tabs.0.elements.0.tip','null'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fieldLayouts.59ffc94b-a1a3-4ecb-98e4-67dbd4317f23.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fieldLayouts.59ffc94b-a1a3-4ecb-98e4-67dbd4317f23.tabs.0.elements.0.warning','null'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fieldLayouts.59ffc94b-a1a3-4ecb-98e4-67dbd4317f23.tabs.0.elements.0.width','100'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fieldLayouts.59ffc94b-a1a3-4ecb-98e4-67dbd4317f23.tabs.0.name','\"Content\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fieldLayouts.59ffc94b-a1a3-4ecb-98e4-67dbd4317f23.tabs.0.sortOrder','1'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.contentColumnType','\"text\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.fieldGroup','null'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.handle','\"richText\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.instructions','\"\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.name','\"Rich Text\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.searchable','true'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.availableTransforms','\"*\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.availableVolumes','\"*\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.cleanupHtml','true'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.columnType','\"text\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.configSelectionMode','\"choose\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.defaultTransform','\"\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.manualConfig','\"\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.purifierConfig','\"\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.purifyHtml','\"1\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.redactorConfig','\"Standard.json\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.removeEmptyTags','\"1\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.removeInlineStyles','\"1\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.removeNbsp','\"1\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.showHtmlButtonForNonAdmins','\"1\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.showUnpermittedFiles','false'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.showUnpermittedVolumes','true'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.settings.uiMode','\"enlarged\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.translationKeyFormat','null'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.translationMethod','\"none\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.fields.df3a27ff-e318-422f-8ff5-d626eda8ce54.type','\"craft\\\\redactor\\\\Field\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.handle','\"richText\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.name','\"Rich Text\"'),
	('matrixBlockTypes.0c98f9b9-84bf-4766-af63-a3568b46c0a6.sortOrder','1'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.field','\"e567b6ab-3855-452b-a337-4c119dac4d62\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.0.fieldUid','\"6b203fd7-eca1-4313-8795-efbb5f6a8e63\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.0.instructions','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.0.label','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.0.required','false'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.0.tip','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.0.warning','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.0.width','100'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.1.fieldUid','\"5d2372e2-c220-4af4-80c9-49bb8c85a92e\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.1.instructions','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.1.label','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.1.required','false'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.1.tip','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.1.warning','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.elements.1.width','100'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.name','\"Content\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fieldLayouts.d0baa120-b528-4317-a11e-0a36f80501c3.tabs.0.sortOrder','1'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.contentColumnType','\"string\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.fieldGroup','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.handle','\"position\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.instructions','\"\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.name','\"Position\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.searchable','true'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.optgroups','true'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.0.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.0.__assoc__.0.1','\"Wide\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.0.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.0.__assoc__.1.1','\"wide\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.0.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.0.__assoc__.2.1','\"1\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.1.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.1.__assoc__.0.1','\"Center\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.1.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.1.__assoc__.1.1','\"center\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.1.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.1.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.2.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.2.__assoc__.0.1','\"Left\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.2.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.2.__assoc__.1.1','\"left\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.2.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.2.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.3.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.3.__assoc__.0.1','\"Right\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.3.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.3.__assoc__.1.1','\"right\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.3.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.settings.options.3.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.translationKeyFormat','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.translationMethod','\"none\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.5d2372e2-c220-4af4-80c9-49bb8c85a92e.type','\"craft\\\\fields\\\\Dropdown\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.contentColumnType','\"string\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.fieldGroup','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.handle','\"image\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.instructions','\"Double-click the image thumbnail to apply a caption to an image.\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.name','\"Image\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.searchable','true'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.allowedKinds.0','\"image\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.allowSelfRelations','false'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.allowUploads','true'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.defaultUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.defaultUploadLocationSubpath','\"\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.limit','\"1\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.localizeRelations','false'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.previewMode','\"full\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.restrictFiles','\"1\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.selectionLabel','\"Add an image\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.showSiteMenu','true'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.showUnpermittedFiles','false'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.showUnpermittedVolumes','true'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.singleUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.singleUploadLocationSubpath','\"\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.source','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.sources','\"*\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.targetSiteId','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.useSingleFolder','false'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.validateRelatedElements','false'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.settings.viewMode','\"large\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.translationKeyFormat','null'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.translationMethod','\"site\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.fields.6b203fd7-eca1-4313-8795-efbb5f6a8e63.type','\"craft\\\\fields\\\\Assets\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.handle','\"image\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.name','\"Image\"'),
	('matrixBlockTypes.28d5c036-8cb0-4a14-b553-0167ee34efbe.sortOrder','3'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.field','\"d8a19f7f-5bcc-4035-89a4-c0b3befd9f96\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.0.fieldUid','\"36c68627-dc00-4d86-a012-7482704054a9\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.0.instructions','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.0.label','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.0.required','false'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.0.tip','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.0.warning','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.0.width','100'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.1.fieldUid','\"4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.1.instructions','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.1.label','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.1.required','false'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.1.tip','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.1.warning','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.elements.1.width','100'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.name','\"Content\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fieldLayouts.4c830e39-6813-460b-b225-d6b17d860ea7.tabs.0.sortOrder','1'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.contentColumnType','\"text\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.fieldGroup','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.handle','\"centredTitle\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.instructions','\"\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.name','\"Centred Title\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.searchable','true'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.settings.byteLimit','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.settings.charLimit','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.settings.code','\"\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.settings.columnType','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.settings.initialRows','\"4\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.settings.multiline','\"\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.settings.placeholder','\"\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.settings.uiMode','\"enlarged\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.translationKeyFormat','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.translationMethod','\"none\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.36c68627-dc00-4d86-a012-7482704054a9.type','\"craft\\\\fields\\\\PlainText\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.contentColumnType','\"text\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.fieldGroup','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.handle','\"centredCopy\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.instructions','\"\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.name','\"Centred Copy\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.searchable','false'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.availableTransforms','\"*\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.availableVolumes','\"*\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.cleanupHtml','true'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.columnType','\"text\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.configSelectionMode','\"choose\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.defaultTransform','\"\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.manualConfig','\"\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.purifierConfig','\"\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.purifyHtml','\"1\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.redactorConfig','\"\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.removeEmptyTags','\"1\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.removeInlineStyles','\"1\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.removeNbsp','\"1\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.showHtmlButtonForNonAdmins','\"1\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.showUnpermittedFiles','false'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.showUnpermittedVolumes','true'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.settings.uiMode','\"enlarged\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.translationKeyFormat','null'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.translationMethod','\"none\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.fields.4dc80d2b-b1ff-47bb-8562-0a6ed9cd2969.type','\"craft\\\\redactor\\\\Field\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.handle','\"centredContent\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.name','\"Centred Content\"'),
	('matrixBlockTypes.2f43fde9-8649-458c-ac99-490e41bf1f03.sortOrder','1'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.field','\"5078004c-4379-4cfc-8931-f386cbe3dbbc\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.0.fieldUid','\"cbf2ec30-a090-4597-8978-83fec9be0363\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.0.instructions','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.0.label','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.0.required','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.0.tip','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.0.warning','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.0.width','100'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.1.fieldUid','\"50d7c69d-2fa8-428c-b8be-c9727158fe13\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.1.instructions','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.1.label','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.1.required','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.1.tip','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.1.warning','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.1.width','100'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.2.fieldUid','\"4b552e7e-8127-494a-89a3-579eeaadcd70\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.2.instructions','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.2.label','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.2.required','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.2.tip','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.2.warning','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.2.width','100'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.3.fieldUid','\"d29ea691-1c48-450b-b491-ebe48ca11f64\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.3.instructions','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.3.label','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.3.required','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.3.tip','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.3.warning','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.3.width','100'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.4.fieldUid','\"b1858648-d1e3-4189-9f41-9d1f6ce73132\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.4.instructions','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.4.label','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.4.required','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.4.tip','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.4.warning','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.elements.4.width','100'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.name','\"Content\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fieldLayouts.39a13f9e-7e80-42aa-8e46-bf24fca50aed.tabs.0.sortOrder','1'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.contentColumnType','\"text\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.fieldGroup','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.handle','\"listingTitle\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.instructions','\"Enter Title\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.name','\"Listing Title\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.searchable','true'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.settings.byteLimit','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.settings.charLimit','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.settings.code','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.settings.columnType','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.settings.initialRows','\"4\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.settings.multiline','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.settings.placeholder','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.settings.uiMode','\"normal\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.translationKeyFormat','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.translationMethod','\"none\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.4b552e7e-8127-494a-89a3-579eeaadcd70.type','\"craft\\\\fields\\\\PlainText\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.contentColumnType','\"string\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.fieldGroup','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.handle','\"aspectRatio\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.instructions','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.name','\"Aspect Ratio\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.searchable','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.optgroups','true'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.0.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.0.__assoc__.0.1','\"16:9\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.0.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.0.__assoc__.1.1','\"169\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.0.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.0.__assoc__.2.1','\"1\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.1.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.1.__assoc__.0.1','\"4:3\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.1.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.1.__assoc__.1.1','\"43\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.1.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.1.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.2.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.2.__assoc__.0.1','\"3:2\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.2.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.2.__assoc__.1.1','\"32\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.2.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.2.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.3.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.3.__assoc__.0.1','\"2:5\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.3.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.3.__assoc__.1.1','\"25\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.3.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.settings.options.3.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.translationKeyFormat','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.translationMethod','\"none\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.50d7c69d-2fa8-428c-b8be-c9727158fe13.type','\"craft\\\\fields\\\\Dropdown\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.contentColumnType','\"string\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.fieldGroup','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.handle','\"listingImage\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.instructions','\"Double-click the image thumbnail to apply a caption to an image.\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.name','\"Listing Image\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.searchable','true'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.allowedKinds.0','\"image\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.allowSelfRelations','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.allowUploads','true'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.defaultUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.defaultUploadLocationSubpath','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.limit','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.localizeRelations','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.previewMode','\"full\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.restrictFiles','\"1\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.selectionLabel','\"Add an image\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.showSiteMenu','true'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.showUnpermittedFiles','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.showUnpermittedVolumes','true'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.singleUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.singleUploadLocationSubpath','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.source','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.sources','\"*\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.targetSiteId','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.useSingleFolder','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.validateRelatedElements','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.settings.viewMode','\"list\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.translationKeyFormat','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.translationMethod','\"site\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.b1858648-d1e3-4189-9f41-9d1f6ce73132.type','\"craft\\\\fields\\\\Assets\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.contentColumnType','\"string\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.fieldGroup','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.handle','\"images\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.instructions','\"Double-click an image thumbnail to apply a caption to an image.\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.name','\"images\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.searchable','true'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.allowedKinds.0','\"html\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.allowedKinds.1','\"image\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.allowSelfRelations','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.allowUploads','true'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.defaultUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.defaultUploadLocationSubpath','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.limit','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.localizeRelations','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.previewMode','\"full\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.restrictFiles','\"1\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.selectionLabel','\"Add an icon\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.showSiteMenu','true'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.showUnpermittedFiles','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.showUnpermittedVolumes','true'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.singleUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.singleUploadLocationSubpath','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.source','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.sources','\"*\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.targetSiteId','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.useSingleFolder','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.validateRelatedElements','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.settings.viewMode','\"large\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.translationKeyFormat','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.translationMethod','\"site\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.cbf2ec30-a090-4597-8978-83fec9be0363.type','\"craft\\\\fields\\\\Assets\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.contentColumnType','\"text\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.fieldGroup','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.handle','\"listingCopy\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.instructions','\"Enter Copy\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.name','\"Listing Copy\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.searchable','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.availableTransforms','\"*\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.availableVolumes','\"*\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.cleanupHtml','true'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.columnType','\"text\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.configSelectionMode','\"choose\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.defaultTransform','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.manualConfig','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.purifierConfig','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.purifyHtml','\"1\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.redactorConfig','\"\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.removeEmptyTags','\"1\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.removeInlineStyles','\"1\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.removeNbsp','\"1\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.showHtmlButtonForNonAdmins','\"1\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.showUnpermittedFiles','false'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.showUnpermittedVolumes','true'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.settings.uiMode','\"enlarged\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.translationKeyFormat','null'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.translationMethod','\"none\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.fields.d29ea691-1c48-450b-b491-ebe48ca11f64.type','\"craft\\\\redactor\\\\Field\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.handle','\"listing\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.name','\"Listing\"'),
	('matrixBlockTypes.73224dba-c124-4f91-9f5a-de0bb4843c02.sortOrder','1'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.field','\"e567b6ab-3855-452b-a337-4c119dac4d62\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.0.fieldUid','\"a6f02aa5-ab37-46e2-bbd4-3b56930577d5\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.0.instructions','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.0.label','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.0.required','false'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.0.tip','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.0.warning','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.0.width','100'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.1.fieldUid','\"2f6bf496-df01-42e0-9b77-a764f886813d\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.1.instructions','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.1.label','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.1.required','false'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.1.tip','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.1.warning','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.1.width','100'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.2.fieldUid','\"b18e27a7-8264-41c8-9914-70b37afe1e37\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.2.instructions','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.2.label','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.2.required','false'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.2.tip','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.2.warning','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.elements.2.width','100'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.name','\"Content\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fieldLayouts.a3b39778-708a-4de0-9501-6b1d37108919.tabs.0.sortOrder','1'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.contentColumnType','\"string\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.fieldGroup','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.handle','\"aspectRatio\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.instructions','\"\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.name','\"Aspect Ratio\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.searchable','true'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.optgroups','true'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.0.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.0.__assoc__.0.1','\"16:9\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.0.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.0.__assoc__.1.1','\"16:9\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.0.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.0.__assoc__.2.1','\"1\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.1.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.1.__assoc__.0.1','\"4:3\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.1.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.1.__assoc__.1.1','\"4:3\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.1.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.1.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.2.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.2.__assoc__.0.1','\"3:2\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.2.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.2.__assoc__.1.1','\"3:2\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.2.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.settings.options.2.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.translationKeyFormat','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.translationMethod','\"none\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.2f6bf496-df01-42e0-9b77-a764f886813d.type','\"craft\\\\fields\\\\Dropdown\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.contentColumnType','\"string\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.fieldGroup','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.handle','\"images\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.instructions','\"Double-click an image thumbnail to apply a caption to an image.\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.name','\"Images\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.searchable','true'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.allowedKinds.0','\"image\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.allowSelfRelations','false'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.allowUploads','true'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.defaultUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.defaultUploadLocationSubpath','\"images\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.limit','\"\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.localizeRelations','false'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.previewMode','\"full\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.restrictFiles','\"1\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.selectionLabel','\"Add an image\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.showSiteMenu','true'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.showUnpermittedFiles','false'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.showUnpermittedVolumes','true'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.singleUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.singleUploadLocationSubpath','\"\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.source','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.sources','\"*\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.targetSiteId','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.useSingleFolder','false'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.validateRelatedElements','false'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.settings.viewMode','\"large\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.translationKeyFormat','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.translationMethod','\"site\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.a6f02aa5-ab37-46e2-bbd4-3b56930577d5.type','\"craft\\\\fields\\\\Assets\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.contentColumnType','\"text\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.fieldGroup','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.handle','\"imagesTitle\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.instructions','\"Enter Title\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.name','\"Title\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.searchable','false'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.settings.byteLimit','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.settings.charLimit','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.settings.code','\"\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.settings.columnType','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.settings.initialRows','\"4\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.settings.multiline','\"\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.settings.placeholder','\"\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.settings.uiMode','\"normal\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.translationKeyFormat','null'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.translationMethod','\"none\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.fields.b18e27a7-8264-41c8-9914-70b37afe1e37.type','\"craft\\\\fields\\\\PlainText\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.handle','\"imageCarousel\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.name','\"Image Carousel\"'),
	('matrixBlockTypes.7e401ee6-3575-42de-b3b4-cedae706f392.sortOrder','4'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.field','\"e567b6ab-3855-452b-a337-4c119dac4d62\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.0.fieldUid','\"a6ca7d80-fa7f-433b-b6ba-fd9f19791f82\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.0.instructions','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.0.label','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.0.required','false'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.0.tip','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.0.warning','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.0.width','100'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.1.fieldUid','\"09c265f3-2ab1-405d-9111-108e6b54f0fb\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.1.instructions','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.1.label','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.1.required','false'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.1.tip','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.1.warning','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.1.width','100'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.2.fieldUid','\"5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.2.instructions','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.2.label','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.2.required','false'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.2.tip','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.2.warning','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.elements.2.width','100'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.name','\"Content\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fieldLayouts.e25f5116-982d-45a0-ac12-9d3a3f1d07e7.tabs.0.sortOrder','1'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.contentColumnType','\"text\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.fieldGroup','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.handle','\"quote\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.instructions','\"\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.name','\"Quote\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.searchable','true'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.availableTransforms','\"*\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.availableVolumes','\"*\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.cleanupHtml','true'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.columnType','\"text\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.configSelectionMode','\"choose\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.defaultTransform','\"\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.manualConfig','\"\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.purifierConfig','\"\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.purifyHtml','\"1\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.redactorConfig','\"Simple.json\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.removeEmptyTags','\"1\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.removeInlineStyles','\"1\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.removeNbsp','\"1\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.showHtmlButtonForNonAdmins','\"1\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.showUnpermittedFiles','false'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.showUnpermittedVolumes','true'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.settings.uiMode','\"enlarged\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.translationKeyFormat','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.translationMethod','\"none\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.09c265f3-2ab1-405d-9111-108e6b54f0fb.type','\"craft\\\\redactor\\\\Field\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.contentColumnType','\"text\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.fieldGroup','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.handle','\"attribution\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.instructions','\"\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.name','\"Attribution\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.searchable','true'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.settings.byteLimit','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.settings.charLimit','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.settings.code','\"\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.settings.columnType','\"text\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.settings.initialRows','\"4\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.settings.multiline','\"\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.settings.placeholder','\"\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.settings.uiMode','\"normal\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.translationKeyFormat','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.translationMethod','\"none\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.5fd465cf-5b00-4b4f-8ee0-ce0eac4fd2eb.type','\"craft\\\\fields\\\\PlainText\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.contentColumnType','\"string\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.fieldGroup','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.handle','\"style\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.instructions','\"\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.name','\"Style\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.searchable','true'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.optgroups','true'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.options.0.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.options.0.__assoc__.0.1','\"Blockquote\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.options.0.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.options.0.__assoc__.1.1','\"blockquote\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.options.0.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.options.0.__assoc__.2.1','\"1\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.options.1.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.options.1.__assoc__.0.1','\"Pullquote\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.options.1.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.options.1.__assoc__.1.1','\"pullquote\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.options.1.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.settings.options.1.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.translationKeyFormat','null'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.translationMethod','\"none\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.fields.a6ca7d80-fa7f-433b-b6ba-fd9f19791f82.type','\"craft\\\\fields\\\\Dropdown\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.handle','\"quote\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.name','\"Quote\"'),
	('matrixBlockTypes.a121b8e6-70e6-421b-9629-c664d2949934.sortOrder','2'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.field','\"5b3791ab-899f-4db6-b8d9-912a0aa18d87\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.0.fieldUid','\"3d69ecc2-ebfc-4738-bf23-e680f804b116\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.0.instructions','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.0.label','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.0.required','false'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.0.tip','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.0.warning','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.0.width','100'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.1.fieldUid','\"f3ade68f-0542-4f6c-afbf-1a7a9d628b75\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.1.instructions','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.1.label','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.1.required','false'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.1.tip','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.1.warning','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.1.width','100'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.2.fieldUid','\"1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.2.instructions','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.2.label','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.2.required','false'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.2.tip','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.2.warning','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.elements.2.width','100'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.name','\"Content\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fieldLayouts.23a9ec3b-ec1c-4293-b023-67ae43be1cf8.tabs.0.sortOrder','1'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.contentColumnType','\"text\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.fieldGroup','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.handle','\"imagesTitle\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.instructions','\"Enter Title\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.name','\"Title\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.searchable','true'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.settings.byteLimit','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.settings.charLimit','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.settings.code','\"\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.settings.columnType','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.settings.initialRows','\"4\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.settings.multiline','\"\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.settings.placeholder','\"\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.settings.uiMode','\"normal\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.translationKeyFormat','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.translationMethod','\"none\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.1c4ccbe2-32ed-4ebb-94ab-1723b6ed2dc2.type','\"craft\\\\fields\\\\PlainText\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.contentColumnType','\"string\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.fieldGroup','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.handle','\"images\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.instructions','\"Double-click an image thumbnail to apply a caption to an image.\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.name','\"images\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.searchable','true'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.allowedKinds.0','\"image\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.allowSelfRelations','false'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.allowUploads','true'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.defaultUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.defaultUploadLocationSubpath','\"\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.limit','\"\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.localizeRelations','false'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.previewMode','\"full\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.restrictFiles','\"1\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.selectionLabel','\"Add an image\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.showSiteMenu','true'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.showUnpermittedFiles','false'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.showUnpermittedVolumes','true'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.singleUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.singleUploadLocationSubpath','\"\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.source','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.sources','\"*\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.targetSiteId','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.useSingleFolder','false'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.validateRelatedElements','false'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.settings.viewMode','\"large\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.translationKeyFormat','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.translationMethod','\"site\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.3d69ecc2-ebfc-4738-bf23-e680f804b116.type','\"craft\\\\fields\\\\Assets\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.contentColumnType','\"string\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.fieldGroup','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.handle','\"aspectRatio\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.instructions','\"\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.name','\"Aspect Ratio\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.searchable','true'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.optgroups','true'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.0.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.0.__assoc__.0.1','\"16:9\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.0.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.0.__assoc__.1.1','\"169\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.0.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.0.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.1.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.1.__assoc__.0.1','\"4:3\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.1.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.1.__assoc__.1.1','\"43\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.1.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.1.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.2.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.2.__assoc__.0.1','\"3:2\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.2.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.2.__assoc__.1.1','\"32\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.2.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.2.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.3.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.3.__assoc__.0.1','\"2:5\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.3.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.3.__assoc__.1.1','\"13\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.3.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.settings.options.3.__assoc__.2.1','\"1\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.translationKeyFormat','null'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.translationMethod','\"none\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.fields.f3ade68f-0542-4f6c-afbf-1a7a9d628b75.type','\"craft\\\\fields\\\\Dropdown\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.handle','\"hero\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.name','\"Hero\"'),
	('matrixBlockTypes.b8af96bb-780f-4207-bd37-5975ec6038a3.sortOrder','1'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.field','\"2f2878ed-1f33-4e42-a96d-66215377c511\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.0.fieldUid','\"51c7d4c0-45da-4471-bdce-4a8e18dc2e96\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.0.instructions','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.0.label','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.0.required','false'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.0.tip','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.0.warning','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.0.width','100'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.1.fieldUid','\"3a5512ac-b907-450c-badc-45ad3c3b901e\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.1.instructions','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.1.label','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.1.required','false'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.1.tip','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.1.warning','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.1.width','100'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.2.fieldUid','\"62a1a784-5e65-4837-94bf-a4738d632822\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.2.instructions','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.2.label','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.2.required','false'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.2.tip','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.2.warning','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.2.width','100'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.3.fieldUid','\"0041e888-c18e-4ebb-ac05-be517a26ed9e\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.3.instructions','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.3.label','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.3.required','false'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.3.tip','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.3.warning','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.3.width','100'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.4.fieldUid','\"b0249c07-1a4f-4d4f-b948-73106f7ebb2e\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.4.instructions','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.4.label','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.4.required','false'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.4.tip','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.4.warning','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.elements.4.width','100'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.name','\"Content\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fieldLayouts.e12e54fd-ab49-4e27-b342-ce149c61d1c3.tabs.0.sortOrder','1'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.contentColumnType','\"string\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.fieldGroup','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.handle','\"aspectRatio\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.instructions','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.name','\"Aspect Ratio\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.searchable','true'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.optgroups','true'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.0.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.0.__assoc__.0.1','\"16:9\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.0.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.0.__assoc__.1.1','\"169\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.0.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.0.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.1.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.1.__assoc__.0.1','\"4:3\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.1.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.1.__assoc__.1.1','\"43\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.1.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.1.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.2.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.2.__assoc__.0.1','\"3:2\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.2.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.2.__assoc__.1.1','\"32\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.2.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.2.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.3.__assoc__.0.0','\"label\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.3.__assoc__.0.1','\"2:3\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.3.__assoc__.1.0','\"value\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.3.__assoc__.1.1','\"23\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.3.__assoc__.2.0','\"default\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.settings.options.3.__assoc__.2.1','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.translationKeyFormat','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.translationMethod','\"none\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.0041e888-c18e-4ebb-ac05-be517a26ed9e.type','\"craft\\\\fields\\\\Dropdown\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.contentColumnType','\"text\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.fieldGroup','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.handle','\"cardsSection\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.instructions','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.name','\"Cards Section\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.searchable','false'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.settings.byteLimit','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.settings.charLimit','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.settings.code','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.settings.columnType','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.settings.initialRows','\"4\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.settings.multiline','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.settings.placeholder','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.settings.uiMode','\"enlarged\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.translationKeyFormat','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.translationMethod','\"none\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.3a5512ac-b907-450c-badc-45ad3c3b901e.type','\"craft\\\\fields\\\\PlainText\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.contentColumnType','\"text\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.fieldGroup','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.handle','\"cardsTitle\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.instructions','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.name','\"Cards Title\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.searchable','false'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.settings.byteLimit','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.settings.charLimit','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.settings.code','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.settings.columnType','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.settings.initialRows','\"4\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.settings.multiline','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.settings.placeholder','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.settings.uiMode','\"enlarged\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.translationKeyFormat','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.translationMethod','\"none\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.51c7d4c0-45da-4471-bdce-4a8e18dc2e96.type','\"craft\\\\fields\\\\PlainText\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.contentColumnType','\"string\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.fieldGroup','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.handle','\"images\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.instructions','\"Double-click an image thumbnail to apply a caption to an image.\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.name','\"Images\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.searchable','true'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.allowedKinds.0','\"image\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.allowSelfRelations','false'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.allowUploads','true'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.defaultUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.defaultUploadLocationSubpath','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.limit','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.localizeRelations','false'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.previewMode','\"full\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.restrictFiles','\"1\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.selectionLabel','\"Add an image\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.showSiteMenu','true'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.showUnpermittedFiles','false'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.showUnpermittedVolumes','true'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.singleUploadLocationSource','\"volume:101a70a1-d200-4629-91e5-3425a0937c0e\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.singleUploadLocationSubpath','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.source','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.sources','\"*\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.targetSiteId','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.useSingleFolder','false'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.validateRelatedElements','false'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.settings.viewMode','\"large\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.translationKeyFormat','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.translationMethod','\"site\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.62a1a784-5e65-4837-94bf-a4738d632822.type','\"craft\\\\fields\\\\Assets\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.contentColumnType','\"text\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.fieldGroup','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.handle','\"buttonLabel\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.instructions','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.name','\"Button Label\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.searchable','true'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.settings.byteLimit','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.settings.charLimit','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.settings.code','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.settings.columnType','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.settings.initialRows','\"4\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.settings.multiline','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.settings.placeholder','\"\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.settings.uiMode','\"normal\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.translationKeyFormat','null'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.translationMethod','\"none\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.fields.b0249c07-1a4f-4d4f-b948-73106f7ebb2e.type','\"craft\\\\fields\\\\PlainText\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.handle','\"cards\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.name','\"Cards\"'),
	('matrixBlockTypes.d9c7c085-cbae-4086-8b3f-04b598277c3e.sortOrder','1'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.field','\"e567b6ab-3855-452b-a337-4c119dac4d62\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fieldLayouts.edfa3f3b-4e3a-4aa8-959c-95de3a10409d.tabs.0.elements.0.fieldUid','\"e8fdd2ad-6739-4bab-a689-8a422e18a8f4\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fieldLayouts.edfa3f3b-4e3a-4aa8-959c-95de3a10409d.tabs.0.elements.0.instructions','null'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fieldLayouts.edfa3f3b-4e3a-4aa8-959c-95de3a10409d.tabs.0.elements.0.label','null'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fieldLayouts.edfa3f3b-4e3a-4aa8-959c-95de3a10409d.tabs.0.elements.0.required','true'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fieldLayouts.edfa3f3b-4e3a-4aa8-959c-95de3a10409d.tabs.0.elements.0.tip','null'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fieldLayouts.edfa3f3b-4e3a-4aa8-959c-95de3a10409d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fieldLayouts.edfa3f3b-4e3a-4aa8-959c-95de3a10409d.tabs.0.elements.0.warning','null'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fieldLayouts.edfa3f3b-4e3a-4aa8-959c-95de3a10409d.tabs.0.elements.0.width','100'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fieldLayouts.edfa3f3b-4e3a-4aa8-959c-95de3a10409d.tabs.0.name','\"Content\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fieldLayouts.edfa3f3b-4e3a-4aa8-959c-95de3a10409d.tabs.0.sortOrder','1'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fields.e8fdd2ad-6739-4bab-a689-8a422e18a8f4.contentColumnType','\"text\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fields.e8fdd2ad-6739-4bab-a689-8a422e18a8f4.fieldGroup','null'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fields.e8fdd2ad-6739-4bab-a689-8a422e18a8f4.handle','\"embed\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fields.e8fdd2ad-6739-4bab-a689-8a422e18a8f4.instructions','\"\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fields.e8fdd2ad-6739-4bab-a689-8a422e18a8f4.name','\"Embed\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fields.e8fdd2ad-6739-4bab-a689-8a422e18a8f4.searchable','false'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fields.e8fdd2ad-6739-4bab-a689-8a422e18a8f4.settings.url','\"\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fields.e8fdd2ad-6739-4bab-a689-8a422e18a8f4.translationKeyFormat','null'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fields.e8fdd2ad-6739-4bab-a689-8a422e18a8f4.translationMethod','\"none\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.fields.e8fdd2ad-6739-4bab-a689-8a422e18a8f4.type','\"wrav\\\\oembed\\\\fields\\\\OembedField\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.handle','\"embed\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.name','\"Embed\"'),
	('matrixBlockTypes.fb2f8912-57ad-4b4e-887d-e55f22a6d348.sortOrder','5'),
	('plugins.assetrev.edition','\"standard\"'),
	('plugins.assetrev.enabled','true'),
	('plugins.assetrev.schemaVersion','\"1.0.0\"'),
	('plugins.oembed.edition','\"standard\"'),
	('plugins.oembed.enabled','true'),
	('plugins.oembed.schemaVersion','\"1.0.1\"'),
	('plugins.oembed.settings.enableCache','\"1\"'),
	('plugins.redactor.edition','\"standard\"'),
	('plugins.redactor.enabled','true'),
	('plugins.redactor.schemaVersion','\"2.3.0\"'),
	('plugins.typogrify.edition','\"standard\"'),
	('plugins.typogrify.enabled','true'),
	('plugins.typogrify.schemaVersion','\"1.0.0\"'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.enableVersioning','true'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.handle','\"packages\"'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.name','\"Packages\"'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.previewTargets.0.__assoc__.0.0','\"label\"'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.previewTargets.0.__assoc__.1.1','\"{url}\"'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.previewTargets.0.__assoc__.2.0','\"refresh\"'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.previewTargets.0.__assoc__.2.1','\"1\"'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.propagationMethod','\"all\"'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.enabledByDefault','true'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.hasUrls','true'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.template','\"_private/packages\"'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.uriFormat','\"packages/{slug}\"'),
	('sections.0d7d6141-cec6-4acc-9665-0f722f1518f5.type','\"channel\"'),
	('sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5.enableVersioning','true'),
	('sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5.handle','\"home\"'),
	('sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5.name','\"Home\"'),
	('sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5.previewTargets.0.label','\"Primary entry page\"'),
	('sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5.previewTargets.0.urlFormat','\"{url}\"'),
	('sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5.propagationMethod','\"all\"'),
	('sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.enabledByDefault','true'),
	('sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.hasUrls','true'),
	('sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.template','\"_private/home\"'),
	('sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.uriFormat','\"__home__\"'),
	('sections.4593234a-cdd0-4c54-9931-4eb606b9e7f5.type','\"single\"'),
	('sections.5a80053a-6435-4fd2-8a47-53e409d994ad.enableVersioning','true'),
	('sections.5a80053a-6435-4fd2-8a47-53e409d994ad.handle','\"about\"'),
	('sections.5a80053a-6435-4fd2-8a47-53e409d994ad.name','\"About\"'),
	('sections.5a80053a-6435-4fd2-8a47-53e409d994ad.previewTargets.0.label','\"Primary entry page\"'),
	('sections.5a80053a-6435-4fd2-8a47-53e409d994ad.previewTargets.0.urlFormat','\"{url}\"'),
	('sections.5a80053a-6435-4fd2-8a47-53e409d994ad.propagationMethod','\"all\"'),
	('sections.5a80053a-6435-4fd2-8a47-53e409d994ad.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.enabledByDefault','true'),
	('sections.5a80053a-6435-4fd2-8a47-53e409d994ad.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.hasUrls','true'),
	('sections.5a80053a-6435-4fd2-8a47-53e409d994ad.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.template','\"_private/about\"'),
	('sections.5a80053a-6435-4fd2-8a47-53e409d994ad.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.uriFormat','\"about\"'),
	('sections.5a80053a-6435-4fd2-8a47-53e409d994ad.type','\"single\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.enableVersioning','true'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.handle','\"blog\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.name','\"Blog\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.previewTargets.0.__assoc__.0.0','\"label\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.previewTargets.0.__assoc__.1.1','\"{url}\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.previewTargets.0.__assoc__.2.0','\"refresh\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.previewTargets.0.__assoc__.2.1','\"1\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.previewTargets.1.__assoc__.0.0','\"label\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.previewTargets.1.__assoc__.0.1','\"Gatsby entry page\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.previewTargets.1.__assoc__.1.0','\"urlFormat\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.previewTargets.1.__assoc__.1.1','\"http://localhost:8000/blog/{slug}\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.previewTargets.1.__assoc__.2.0','\"refresh\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.previewTargets.1.__assoc__.2.1','\"\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.propagationMethod','\"all\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.enabledByDefault','true'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.hasUrls','true'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.template','\"_private/blog-entry\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.siteSettings.f3400d6f-0f33-4cef-9521-f8f6620399ec.uriFormat','\"blog/{slug}\"'),
	('sections.db2dff45-19b4-479c-8cba-ab88e7e7d2fd.type','\"channel\"'),
	('siteGroups.90dee5cc-23f1-40ac-ae14-3fa71bebc4dc.name','\"Craft Blog\"'),
	('sites.f3400d6f-0f33-4cef-9521-f8f6620399ec.baseUrl','\"$DEFAULT_SITE_URL\"'),
	('sites.f3400d6f-0f33-4cef-9521-f8f6620399ec.enabled','true'),
	('sites.f3400d6f-0f33-4cef-9521-f8f6620399ec.handle','\"default\"'),
	('sites.f3400d6f-0f33-4cef-9521-f8f6620399ec.hasUrls','true'),
	('sites.f3400d6f-0f33-4cef-9521-f8f6620399ec.language','\"en-US\"'),
	('sites.f3400d6f-0f33-4cef-9521-f8f6620399ec.name','\"Craft Demo\"'),
	('sites.f3400d6f-0f33-4cef-9521-f8f6620399ec.primary','true'),
	('sites.f3400d6f-0f33-4cef-9521-f8f6620399ec.siteGroup','\"90dee5cc-23f1-40ac-ae14-3fa71bebc4dc\"'),
	('sites.f3400d6f-0f33-4cef-9521-f8f6620399ec.sortOrder','1'),
	('system.edition','\"pro\"'),
	('system.live','true'),
	('system.name','\"My Craft CMS Demo\"'),
	('system.retryDuration','null'),
	('system.schemaVersion','\"3.5.13\"'),
	('system.timeZone','\"America/Los_Angeles\"'),
	('users.allowPublicRegistration','false'),
	('users.defaultGroup','null'),
	('users.photoSubpath','\"\"'),
	('users.photoVolumeUid','null'),
	('users.requireEmailVerification','true'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.fieldLayouts.f6203211-ad03-49ec-8423-3d215898f508.tabs.0.fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.required','false'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.fieldLayouts.f6203211-ad03-49ec-8423-3d215898f508.tabs.0.fields.cdd377e5-a451-46b0-ae80-bc4cee907d3e.sortOrder','1'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.fieldLayouts.f6203211-ad03-49ec-8423-3d215898f508.tabs.0.fields.db95de40-4dec-44cc-9d17-bba2223c91cf.required','false'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.fieldLayouts.f6203211-ad03-49ec-8423-3d215898f508.tabs.0.fields.db95de40-4dec-44cc-9d17-bba2223c91cf.sortOrder','2'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.fieldLayouts.f6203211-ad03-49ec-8423-3d215898f508.tabs.0.name','\"Content\"'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.fieldLayouts.f6203211-ad03-49ec-8423-3d215898f508.tabs.0.sortOrder','1'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.handle','\"uploads\"'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.hasUrls','true'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.name','\"Uploads\"'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.settings.path','\"@webroot/uploads\"'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.sortOrder','1'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.type','\"craft\\\\volumes\\\\Local\"'),
	('volumes.101a70a1-d200-4629-91e5-3425a0937c0e.url','\"@web/uploads\"');

/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table queue
# ------------------------------------------------------------

DROP TABLE IF EXISTS `queue`;

CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT '0',
  `priority` int(11) unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `queue_channel_fail_timeUpdated_timePushed_idx` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `queue_channel_fail_timeUpdated_delay_idx` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table relations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `relations`;

CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `relations_fieldId_sourceId_sourceSiteId_targetId_unq_idx` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `relations_sourceId_idx` (`sourceId`),
  KEY `relations_targetId_idx` (`targetId`),
  KEY `relations_sourceSiteId_idx` (`sourceSiteId`),
  CONSTRAINT `relations_fieldId_fk` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `relations_sourceSiteId_fk` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `relations_targetId_fk` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;

INSERT INTO `relations` (`id`, `fieldId`, `sourceId`, `sourceSiteId`, `targetId`, `sortOrder`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,14,25,NULL,14,1,'2020-12-07 19:56:43','2020-12-07 19:56:43','6744b47c-f7c3-4d76-ad72-646a723d5a2f'),
	(2,14,25,NULL,15,2,'2020-12-07 19:56:43','2020-12-07 19:56:43','370c7797-aae4-4b09-92e5-7d0aa6ef9bcb'),
	(3,14,25,NULL,16,3,'2020-12-07 19:56:43','2020-12-07 19:56:43','727f25e4-ff2d-4424-b627-2f929d8c0d97'),
	(4,14,28,NULL,14,1,'2020-12-07 19:56:43','2020-12-07 19:56:43','562e5a1b-e847-4642-80ea-e373f63b7025'),
	(5,14,28,NULL,15,2,'2020-12-07 19:56:43','2020-12-07 19:56:43','f31e2dc8-a498-41fa-b71f-82046afe48eb'),
	(6,14,28,NULL,16,3,'2020-12-07 19:56:43','2020-12-07 19:56:43','9223d0f3-bc40-40e6-8ec8-a21077ca6a37'),
	(7,14,31,NULL,14,1,'2020-12-07 20:14:29','2020-12-07 20:14:29','a0ff85c9-312d-4e97-b0d8-bf321ee90b83'),
	(8,14,31,NULL,15,2,'2020-12-07 20:14:29','2020-12-07 20:14:29','2c075b8c-bca6-46c2-8893-e2039c0f89a2'),
	(9,14,31,NULL,16,3,'2020-12-07 20:14:29','2020-12-07 20:14:29','18415e9f-00e5-46b5-9fb8-00c31997de99'),
	(10,14,34,NULL,14,1,'2020-12-07 20:36:27','2020-12-07 20:36:27','64d0a0be-f3c6-4db7-b18d-e932d079dff7'),
	(11,14,34,NULL,15,2,'2020-12-07 20:36:27','2020-12-07 20:36:27','019bf6f6-834f-4643-9503-fa730e143535'),
	(12,14,34,NULL,16,3,'2020-12-07 20:36:27','2020-12-07 20:36:27','bb839659-85c2-417d-ae16-9323c344396b'),
	(16,14,44,NULL,14,1,'2020-12-08 08:19:55','2020-12-08 08:19:55','15b30f58-53bc-426b-93c6-1a3a0d927956'),
	(17,14,44,NULL,15,2,'2020-12-08 08:19:55','2020-12-08 08:19:55','df685d70-a35f-494d-8a99-ac9ccaf99902'),
	(18,14,44,NULL,16,3,'2020-12-08 08:19:55','2020-12-08 08:19:55','28607dda-edba-4059-a05c-00d6773eb303'),
	(19,14,46,NULL,14,1,'2020-12-08 08:20:21','2020-12-08 08:20:21','765b55b7-814f-4426-a5ee-c9553e958d2a'),
	(20,14,46,NULL,15,2,'2020-12-08 08:20:21','2020-12-08 08:20:21','5d6407f6-290c-4e73-b965-be971d446676'),
	(21,14,46,NULL,16,3,'2020-12-08 08:20:21','2020-12-08 08:20:21','42154460-9d00-4904-8c64-1d42806b2dd0'),
	(22,8,47,NULL,14,1,'2020-12-08 09:23:25','2020-12-08 09:23:25','73582031-7127-473e-9d6c-1a2138a47ab7'),
	(23,8,48,NULL,15,1,'2020-12-08 09:23:25','2020-12-08 09:23:25','f42b34d1-dd45-4506-b15a-5344f9ff97b4'),
	(24,8,49,NULL,16,1,'2020-12-08 09:23:25','2020-12-08 09:23:25','53fa295c-8c65-4959-88f0-cb42489ee057'),
	(25,14,51,NULL,14,1,'2020-12-08 09:23:25','2020-12-08 09:23:25','c5058463-ae8d-4fd2-a1bc-14f7ad4d12c9'),
	(26,14,51,NULL,15,2,'2020-12-08 09:23:25','2020-12-08 09:23:25','42c7dba0-a30d-4b28-9631-fe8e2586df07'),
	(27,14,51,NULL,16,3,'2020-12-08 09:23:25','2020-12-08 09:23:25','7d0b9e02-1231-421d-a003-9585f87f782f'),
	(28,8,52,NULL,14,1,'2020-12-08 09:23:26','2020-12-08 09:23:26','e2cac5c2-7f43-4dd2-bd32-4731ec7111a4'),
	(29,8,53,NULL,15,1,'2020-12-08 09:23:26','2020-12-08 09:23:26','02da1c97-3a13-460b-992f-9675efc4c98b'),
	(30,8,54,NULL,16,1,'2020-12-08 09:23:26','2020-12-08 09:23:26','86ff0282-e277-4c3e-9aa7-77b923135b8c'),
	(31,8,66,NULL,16,1,'2020-12-08 18:08:38','2020-12-08 18:08:38','0427a0a7-555d-4d21-8e46-ef7be6328eef'),
	(32,8,68,NULL,16,1,'2020-12-08 18:08:38','2020-12-08 18:08:38','728a4e39-beb2-4076-9945-a5c3f78c7e58'),
	(33,8,69,NULL,15,1,'2020-12-08 18:09:16','2020-12-08 18:09:16','74b5c43a-ae84-42ea-9bfe-a346cb2fa1dd'),
	(34,8,71,NULL,15,1,'2020-12-08 18:09:16','2020-12-08 18:09:16','896b267c-689d-4f30-a19d-d06db3fc829c'),
	(35,8,72,NULL,14,1,'2020-12-08 18:09:50','2020-12-08 18:09:50','3af0c16c-88c7-4a3c-91d4-6a7a1303c7b4'),
	(36,8,74,NULL,14,1,'2020-12-08 18:09:51','2020-12-08 18:09:51','92af4ac3-fe8e-4a40-8c47-2618d9596424'),
	(37,20,64,NULL,16,1,'2020-12-08 18:17:41','2020-12-08 18:17:41','1b1b7b64-d01e-46ee-b791-5570c063c852'),
	(38,20,75,NULL,16,1,'2020-12-08 18:17:41','2020-12-08 18:17:41','cdee79b3-72c5-45ba-9b9d-6653c0afaf0a'),
	(39,8,76,NULL,16,1,'2020-12-08 18:17:41','2020-12-08 18:17:41','a9d5cb94-f323-4d7d-b859-e9e4a9f49bb3'),
	(40,20,61,NULL,15,1,'2020-12-08 18:17:56','2020-12-08 18:17:56','f14d0137-d574-441b-8eee-c0968519dfe4'),
	(41,20,77,NULL,15,1,'2020-12-08 18:17:56','2020-12-08 18:17:56','9512a7b2-c794-4cb6-ae42-8cba81f95ca1'),
	(42,8,78,NULL,15,1,'2020-12-08 18:17:56','2020-12-08 18:17:56','8c594cae-adae-41df-b4ad-e991e9605aae'),
	(43,20,57,NULL,14,1,'2020-12-08 18:18:12','2020-12-08 18:18:12','cff3bf40-e29d-463e-813d-cbd2b9648369'),
	(44,20,79,NULL,14,1,'2020-12-08 18:18:12','2020-12-08 18:18:12','5de7156c-ee2d-4f25-9ae9-bc78c682ac11'),
	(45,8,80,NULL,14,1,'2020-12-08 18:18:12','2020-12-08 18:18:12','6b8c4208-4ced-4123-9395-e268c755b21a'),
	(46,14,82,NULL,14,1,'2020-12-08 20:07:34','2020-12-08 20:07:34','d2ce2040-de7d-48df-9429-d814cf8f60f8'),
	(47,14,82,NULL,15,2,'2020-12-08 20:07:34','2020-12-08 20:07:34','6900561a-3a15-428d-b882-95dd1ab45aa9'),
	(48,14,82,NULL,16,3,'2020-12-08 20:07:34','2020-12-08 20:07:34','302beb64-ed2c-468b-85e3-5c9ac73e3581'),
	(49,14,42,NULL,18,1,'2020-12-09 00:07:30','2020-12-09 00:07:30','9ea8222a-fa8f-4dd4-b17c-591474307af5'),
	(50,14,42,NULL,19,2,'2020-12-09 00:07:30','2020-12-09 00:07:30','84cca625-8a89-4c43-a3fc-8ae32b90eb93'),
	(51,14,42,NULL,20,3,'2020-12-09 00:07:30','2020-12-09 00:07:30','bb55a8aa-8f02-4fd8-9d03-f2ac9ea7b70e'),
	(52,14,42,NULL,21,4,'2020-12-09 00:07:30','2020-12-09 00:07:30','126bfbf8-214c-4716-a05d-83dddb9658f8'),
	(54,14,84,NULL,18,1,'2020-12-09 00:07:30','2020-12-09 00:07:30','f75e147f-dfc8-478e-a2d9-a5b46482ddd1'),
	(55,14,84,NULL,19,2,'2020-12-09 00:07:30','2020-12-09 00:07:30','51c3af9c-517d-44c5-b39c-34738c2abbbf'),
	(56,14,84,NULL,20,3,'2020-12-09 00:07:30','2020-12-09 00:07:30','574d0702-db39-412e-9292-48853409cc71'),
	(57,14,84,NULL,21,4,'2020-12-09 00:07:30','2020-12-09 00:07:30','947c1d9f-12c7-46b2-ab8e-05e6e02c485c'),
	(58,14,84,NULL,22,5,'2020-12-09 00:07:30','2020-12-09 00:07:30','3cab99b6-c105-4a38-8c28-668a3b086278'),
	(59,14,85,NULL,13,1,'2020-12-09 07:28:39','2020-12-09 07:28:39','75f2a63d-3596-49f1-86bd-e5c822908f96'),
	(60,14,85,NULL,12,2,'2020-12-09 07:28:39','2020-12-09 07:28:39','39305241-d336-4e03-872c-b019f6fa47b2'),
	(61,14,85,NULL,11,3,'2020-12-09 07:28:39','2020-12-09 07:28:39','1b99f6c4-7638-4c54-aa19-7d1ed8dd9d9a'),
	(62,14,85,NULL,10,4,'2020-12-09 07:28:39','2020-12-09 07:28:39','6f756c3d-4c78-4c9d-9471-772c618b81a2'),
	(63,14,85,NULL,9,5,'2020-12-09 07:28:39','2020-12-09 07:28:39','887f51bb-5b81-49e2-aaa5-cb35de32c37a'),
	(64,14,87,NULL,18,1,'2020-12-09 07:28:39','2020-12-09 07:28:39','35c74077-bd61-4d89-bc97-a633e629e330'),
	(65,14,87,NULL,19,2,'2020-12-09 07:28:39','2020-12-09 07:28:39','de823fb1-9a7b-4af2-885a-6f1c4644ef03'),
	(66,14,87,NULL,20,3,'2020-12-09 07:28:39','2020-12-09 07:28:39','91cebfa5-2bdb-4c3d-8cf0-b4f136460ee7'),
	(67,14,87,NULL,21,4,'2020-12-09 07:28:39','2020-12-09 07:28:39','5e00e3b1-7823-496f-8011-f1d851626b77'),
	(68,14,87,NULL,22,5,'2020-12-09 07:28:39','2020-12-09 07:28:39','9f79dd39-85ee-4458-aba1-65b5ddd610d9'),
	(69,14,88,NULL,13,1,'2020-12-09 07:28:39','2020-12-09 07:28:39','0c947366-effc-485f-b342-fee5f7337c98'),
	(70,14,88,NULL,12,2,'2020-12-09 07:28:39','2020-12-09 07:28:39','09a99ee7-c86e-4efa-8ac1-e7c54a54d409'),
	(71,14,88,NULL,11,3,'2020-12-09 07:28:39','2020-12-09 07:28:39','20033d4a-561b-4ead-9327-ebc0df449ea9'),
	(72,14,88,NULL,10,4,'2020-12-09 07:28:39','2020-12-09 07:28:39','17341208-5674-4b5d-856e-ce339dd9eeb4'),
	(73,14,88,NULL,9,5,'2020-12-09 07:28:39','2020-12-09 07:28:39','8288bad6-fb7b-4b85-8b8b-00bfad2ed7e4'),
	(74,14,90,NULL,18,1,'2020-12-09 07:38:03','2020-12-09 07:38:03','ce2f948a-b4d2-440f-b4b3-8be68471a704'),
	(75,14,90,NULL,19,2,'2020-12-09 07:38:03','2020-12-09 07:38:03','0e55f1c1-cff3-43a4-b083-02b03f5f7673'),
	(76,14,90,NULL,20,3,'2020-12-09 07:38:03','2020-12-09 07:38:03','9cf031c6-765e-42d9-97a9-61480dc6efb3'),
	(77,14,90,NULL,21,4,'2020-12-09 07:38:03','2020-12-09 07:38:03','da8e8622-7b3c-4e53-8354-5cddcf4dbf2f'),
	(78,14,91,NULL,13,1,'2020-12-09 07:38:03','2020-12-09 07:38:03','c89589cc-4e3a-4899-971e-02bd175816f0'),
	(79,14,91,NULL,12,2,'2020-12-09 07:38:03','2020-12-09 07:38:03','9fb758ed-a242-48d6-973c-f3c7b60fd97c'),
	(80,14,91,NULL,11,3,'2020-12-09 07:38:03','2020-12-09 07:38:03','f771e91d-de87-4bc7-9f0f-8a22c7a0def7'),
	(81,14,91,NULL,10,4,'2020-12-09 07:38:03','2020-12-09 07:38:03','39e47b92-fb02-420f-a478-de09d983fe86'),
	(82,14,91,NULL,9,5,'2020-12-09 07:38:03','2020-12-09 07:38:03','eef29d5a-6df1-4927-818c-92a9e6e784cb'),
	(83,14,93,NULL,18,1,'2020-12-09 08:06:36','2020-12-09 08:06:36','4b496529-37a8-4c0d-8780-50b462e49a5a'),
	(84,14,93,NULL,19,2,'2020-12-09 08:06:36','2020-12-09 08:06:36','08730f01-7343-43bc-85d5-042531b86585'),
	(85,14,93,NULL,20,3,'2020-12-09 08:06:36','2020-12-09 08:06:36','538b2b6e-8094-493f-8fd1-aab6244b060d'),
	(86,14,93,NULL,21,4,'2020-12-09 08:06:36','2020-12-09 08:06:36','631793df-35a8-44de-9ccc-9888e76f57bb'),
	(87,14,95,NULL,18,1,'2020-12-09 08:07:13','2020-12-09 08:07:13','c15c7035-6e2b-42ae-aa59-42b972cfc0bf'),
	(88,14,95,NULL,19,2,'2020-12-09 08:07:13','2020-12-09 08:07:13','4d5ff1da-394f-4e00-a111-026a589b3797'),
	(89,14,95,NULL,20,3,'2020-12-09 08:07:13','2020-12-09 08:07:13','ece15a6f-171c-40bd-b49c-2f9f2aceee5d'),
	(90,14,95,NULL,21,4,'2020-12-09 08:07:13','2020-12-09 08:07:13','1e146f5f-bba3-4f15-9246-74e36a5482cc'),
	(97,14,101,NULL,18,1,'2020-12-09 08:10:35','2020-12-09 08:10:35','5a00c6b9-d083-4c19-87d8-0fde0bf74521'),
	(98,14,101,NULL,19,2,'2020-12-09 08:10:35','2020-12-09 08:10:35','bd8c89ec-333b-46d7-af7e-8bf9c80bb976'),
	(99,14,101,NULL,20,3,'2020-12-09 08:10:35','2020-12-09 08:10:35','66f2b00c-ad15-4707-8ac8-a9fa0f0ba60a'),
	(100,14,101,NULL,21,4,'2020-12-09 08:10:35','2020-12-09 08:10:35','3d20b848-6aae-4b71-b612-27eb373ca028'),
	(107,14,110,NULL,18,1,'2020-12-09 18:47:32','2020-12-09 18:47:32','09014015-c413-44d4-bf87-3b1523f8a436'),
	(108,14,110,NULL,19,2,'2020-12-09 18:47:32','2020-12-09 18:47:32','1f3634e1-4ab0-4337-9c1b-96a2812c40e8'),
	(109,14,110,NULL,20,3,'2020-12-09 18:47:32','2020-12-09 18:47:32','b44108f0-a0db-4ec9-a4b4-c02ddff03132'),
	(110,14,110,NULL,21,4,'2020-12-09 18:47:32','2020-12-09 18:47:32','d64514fc-5af1-4c22-8cc9-47688359732f'),
	(117,14,119,NULL,18,1,'2020-12-09 19:08:12','2020-12-09 19:08:12','d9d0341d-a3bc-4260-8e64-4488d23a379a'),
	(118,14,119,NULL,19,2,'2020-12-09 19:08:12','2020-12-09 19:08:12','c3ee85d0-8c67-461e-bfc3-4e963d53ce32'),
	(119,14,119,NULL,20,3,'2020-12-09 19:08:12','2020-12-09 19:08:12','037b4cfd-7eab-4e34-b99c-a7dc27c0caa3'),
	(120,14,119,NULL,21,4,'2020-12-09 19:08:12','2020-12-09 19:08:12','799e3985-09ca-4be2-845d-fc4027d09eb9'),
	(127,29,127,NULL,14,1,'2020-12-09 19:11:11','2020-12-09 19:11:11','08fc56b1-5d09-46b3-bc4c-712113ae9e3c'),
	(128,29,127,NULL,15,2,'2020-12-09 19:11:11','2020-12-09 19:11:11','32da6f61-b64c-4654-a59b-f16b0da8708f'),
	(129,29,127,NULL,16,3,'2020-12-09 19:11:11','2020-12-09 19:11:11','c0c71ccc-ab81-4413-ab98-60c1f50fada4'),
	(130,29,129,NULL,14,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','6e14169b-fa33-47e5-a66d-f885890de2f0'),
	(131,29,129,NULL,15,2,'2020-12-09 19:11:12','2020-12-09 19:11:12','70292771-0be3-4c43-8d8d-9452527dccb8'),
	(132,29,129,NULL,16,3,'2020-12-09 19:11:12','2020-12-09 19:11:12','2330325b-e866-4f36-9a68-6eaf1eaee6b7'),
	(133,14,130,NULL,18,1,'2020-12-09 19:11:12','2020-12-09 19:11:12','e930a566-bcb3-4f52-ba96-b7dda1f94421'),
	(134,14,130,NULL,19,2,'2020-12-09 19:11:12','2020-12-09 19:11:12','50b12216-93a7-4935-92ec-c1e1cae1a344'),
	(135,14,130,NULL,20,3,'2020-12-09 19:11:12','2020-12-09 19:11:12','0f89c65b-bee0-46df-983a-225748af6e90'),
	(136,14,130,NULL,21,4,'2020-12-09 19:11:12','2020-12-09 19:11:12','6f4e6347-4c16-4b52-89ba-d041bddba567'),
	(143,29,139,NULL,14,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','29534e4c-280f-455a-92ab-2d3c4a39fcfa'),
	(144,29,139,NULL,15,2,'2020-12-09 22:32:49','2020-12-09 22:32:49','b77e7b3d-d702-4cf9-9bd1-20669d5effce'),
	(145,29,139,NULL,16,3,'2020-12-09 22:32:49','2020-12-09 22:32:49','0a5fa5f5-7c62-44f1-a306-d6aff0d1f126'),
	(146,14,140,NULL,18,1,'2020-12-09 22:32:49','2020-12-09 22:32:49','fe2019a8-8a39-4a0b-a419-ccccae7a00ba'),
	(147,14,140,NULL,19,2,'2020-12-09 22:32:49','2020-12-09 22:32:49','908597fd-d7d5-42ba-b5eb-7c1893c9c9c0'),
	(148,14,140,NULL,20,3,'2020-12-09 22:32:49','2020-12-09 22:32:49','999a618c-e4ce-4a92-a772-81037e37c9ae'),
	(149,14,140,NULL,21,4,'2020-12-09 22:32:49','2020-12-09 22:32:49','d9005e8d-fd93-468f-9c1e-761121ba4a7b'),
	(156,29,149,NULL,14,1,'2020-12-09 22:35:36','2020-12-09 22:35:36','931b14dc-33e3-467c-a944-4af15837cc90'),
	(157,29,149,NULL,15,2,'2020-12-09 22:35:36','2020-12-09 22:35:36','ac82a8f6-461d-4701-9227-c832afc8dd2b'),
	(158,29,149,NULL,16,3,'2020-12-09 22:35:36','2020-12-09 22:35:36','b0b34f9d-8091-4a15-821e-fa26b9186b49'),
	(159,14,150,NULL,18,1,'2020-12-09 22:35:36','2020-12-09 22:35:36','e3051d42-e6ef-4fb0-bd83-81103be3058a'),
	(160,14,150,NULL,19,2,'2020-12-09 22:35:36','2020-12-09 22:35:36','b6606363-b37c-49a8-9537-8ee50fba05db'),
	(161,14,150,NULL,20,3,'2020-12-09 22:35:36','2020-12-09 22:35:36','bfecb660-2554-4c61-ac47-3e31bee8538c'),
	(162,14,150,NULL,21,4,'2020-12-09 22:35:36','2020-12-09 22:35:36','df7f616f-19a5-4915-bd02-18e36f039a62'),
	(169,29,159,NULL,14,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','ae188624-ddba-45ef-9cf0-4bb1a3d15732'),
	(170,29,159,NULL,15,2,'2020-12-09 22:50:38','2020-12-09 22:50:38','375f71ef-273b-44ab-b03f-bc96cca1b4aa'),
	(171,29,159,NULL,16,3,'2020-12-09 22:50:38','2020-12-09 22:50:38','396a37c9-e97f-4edd-9fae-19ccf92fafd9'),
	(172,14,160,NULL,18,1,'2020-12-09 22:50:38','2020-12-09 22:50:38','85f5c073-432e-4a92-aeb0-3a511ca2d148'),
	(173,14,160,NULL,19,2,'2020-12-09 22:50:38','2020-12-09 22:50:38','dbaa9075-3a05-4cc8-9094-09882c833c36'),
	(174,14,160,NULL,20,3,'2020-12-09 22:50:38','2020-12-09 22:50:38','6d78408e-e06b-4ebc-a552-d4c4cbf77fa5'),
	(175,14,160,NULL,21,4,'2020-12-09 22:50:38','2020-12-09 22:50:38','2f30bed6-a43b-4eb5-94a1-5a9373745eca'),
	(182,29,170,NULL,14,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','5438a395-50f6-406e-9aa1-69629c5c13c1'),
	(183,29,170,NULL,15,2,'2020-12-09 22:56:06','2020-12-09 22:56:06','921de7d8-4048-40f0-8730-dc2efd4e7257'),
	(184,29,170,NULL,16,3,'2020-12-09 22:56:06','2020-12-09 22:56:06','c7e1f7d6-2267-4ec7-92ef-3b6d1f97a61c'),
	(185,14,172,NULL,18,1,'2020-12-09 22:56:06','2020-12-09 22:56:06','23c48436-0a3e-4004-bc81-7d22e580438c'),
	(186,14,172,NULL,19,2,'2020-12-09 22:56:06','2020-12-09 22:56:06','fa1baf53-a58e-486c-a6ca-dae5e2c8bff0'),
	(187,14,172,NULL,20,3,'2020-12-09 22:56:06','2020-12-09 22:56:06','84317b16-6fd8-4009-99d9-e440ed997693'),
	(188,14,172,NULL,21,4,'2020-12-09 22:56:06','2020-12-09 22:56:06','e4ccd072-aadc-4d8c-b74d-77b952f42859'),
	(195,33,168,NULL,9,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','7f557cc0-f335-49e5-8fb0-6da4ee0ac799'),
	(196,33,168,NULL,10,2,'2020-12-09 23:01:03','2020-12-09 23:01:03','70a5c949-5bd2-4d35-b415-3074eed6c1dd'),
	(197,33,168,NULL,11,3,'2020-12-09 23:01:03','2020-12-09 23:01:03','c5631e56-8b9f-4e2a-9adc-aada1d1fda59'),
	(198,33,168,NULL,12,4,'2020-12-09 23:01:03','2020-12-09 23:01:03','3041ad41-d7aa-4077-87fc-2879689cbab2'),
	(199,33,168,NULL,13,5,'2020-12-09 23:01:03','2020-12-09 23:01:03','0b1e9276-9827-4468-aa96-89c07e17cf0b'),
	(200,29,181,NULL,14,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','63817b00-7b99-443d-a6e9-d82d2ffb2b31'),
	(201,29,181,NULL,15,2,'2020-12-09 23:01:03','2020-12-09 23:01:03','0a6b5b6c-da2c-4dc2-8df7-d9b978cbb3bd'),
	(202,29,181,NULL,16,3,'2020-12-09 23:01:03','2020-12-09 23:01:03','a9717583-6fed-48a0-bce6-ced7dd5daf30'),
	(203,33,182,NULL,9,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','a0800774-5ff8-4b9a-8f1e-d0aa1e53bd02'),
	(204,33,182,NULL,10,2,'2020-12-09 23:01:03','2020-12-09 23:01:03','8a2552da-0885-40f5-956c-986e849acded'),
	(205,33,182,NULL,11,3,'2020-12-09 23:01:03','2020-12-09 23:01:03','1471262c-e4ea-42b7-9857-17247a595a1c'),
	(206,33,182,NULL,12,4,'2020-12-09 23:01:03','2020-12-09 23:01:03','1722d38f-fee8-478d-8e6f-a47cc706a3ce'),
	(207,33,182,NULL,13,5,'2020-12-09 23:01:03','2020-12-09 23:01:03','513336e5-1ff8-4c04-ac00-f8725d5d4799'),
	(208,14,183,NULL,18,1,'2020-12-09 23:01:03','2020-12-09 23:01:03','7c5c3630-1ca5-47bc-baed-20ead2117b37'),
	(209,14,183,NULL,19,2,'2020-12-09 23:01:03','2020-12-09 23:01:03','ace47c77-d68f-4fdb-a992-82f51f14564f'),
	(210,14,183,NULL,20,3,'2020-12-09 23:01:03','2020-12-09 23:01:03','bd7a2fae-89cb-473c-a3f6-534c98c01264'),
	(211,14,183,NULL,21,4,'2020-12-09 23:01:03','2020-12-09 23:01:03','db784300-394e-419c-9b07-f845c1438d65'),
	(218,37,168,NULL,17,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','136cfdbc-21b8-4bb7-b907-41c8727767da'),
	(219,29,192,NULL,14,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','bdde2087-6a66-4dcf-988f-f46e5cd73ae3'),
	(220,29,192,NULL,15,2,'2020-12-09 23:18:20','2020-12-09 23:18:20','e0ccacdb-cd69-47b3-b71b-4bce75fa60a4'),
	(221,29,192,NULL,16,3,'2020-12-09 23:18:20','2020-12-09 23:18:20','6de5e9ea-f5e5-4abf-897f-cb64293d95f8'),
	(222,33,193,NULL,9,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','8c8f60d0-2460-4dbe-b78b-5c8fe1ce79dd'),
	(223,33,193,NULL,10,2,'2020-12-09 23:18:20','2020-12-09 23:18:20','72502e0b-df8b-4acf-9e1d-b53b881120c6'),
	(224,33,193,NULL,11,3,'2020-12-09 23:18:20','2020-12-09 23:18:20','6f92de5a-c523-42f1-a171-29cf635f2f93'),
	(225,33,193,NULL,12,4,'2020-12-09 23:18:20','2020-12-09 23:18:20','ad8dba7f-bb71-4a64-bd7e-5282c04112ef'),
	(226,33,193,NULL,13,5,'2020-12-09 23:18:20','2020-12-09 23:18:20','bee12af2-9ead-465a-8ab7-6ef1fbc4c67b'),
	(227,37,193,NULL,17,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','1b75b2b5-2da5-469f-8cd6-ae67ef358fe5'),
	(228,14,194,NULL,18,1,'2020-12-09 23:18:20','2020-12-09 23:18:20','b5b18695-bcb2-4151-bb83-aeb4055a9233'),
	(229,14,194,NULL,19,2,'2020-12-09 23:18:20','2020-12-09 23:18:20','47958d81-f230-4129-ad68-cda28df96e1a'),
	(230,14,194,NULL,20,3,'2020-12-09 23:18:20','2020-12-09 23:18:20','396ab113-ad99-496b-a7bc-449045155ccd'),
	(231,14,194,NULL,21,4,'2020-12-09 23:18:20','2020-12-09 23:18:20','8685636f-1640-4df2-9d60-30dc5072d3ba'),
	(238,29,203,NULL,14,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','2d849c96-6a3c-486e-b11e-625c9b9cb2f0'),
	(239,29,203,NULL,15,2,'2020-12-09 23:20:49','2020-12-09 23:20:49','9e454ddc-9b60-4cdf-b67f-42211e3e6ef3'),
	(240,29,203,NULL,16,3,'2020-12-09 23:20:49','2020-12-09 23:20:49','a1d0d15e-05c4-4d7e-9ab3-c8f85e4cb231'),
	(241,33,204,NULL,9,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','2486d78e-5b95-4356-9935-663bf640f1ff'),
	(242,33,204,NULL,10,2,'2020-12-09 23:20:49','2020-12-09 23:20:49','e58bd585-ab23-4e3e-9308-6bcc9abcc901'),
	(243,33,204,NULL,11,3,'2020-12-09 23:20:49','2020-12-09 23:20:49','1cc2f23c-3388-4aa6-9d44-0d3b60ffab5b'),
	(244,33,204,NULL,12,4,'2020-12-09 23:20:49','2020-12-09 23:20:49','ae4f1ffa-aae6-4ad2-b74e-9647102748ac'),
	(245,33,204,NULL,13,5,'2020-12-09 23:20:49','2020-12-09 23:20:49','8565d859-fe93-466f-917b-e14d6adfd638'),
	(246,37,204,NULL,17,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','69162c0a-3ae1-43f8-ac22-b69f81fe0032'),
	(247,14,205,NULL,18,1,'2020-12-09 23:20:49','2020-12-09 23:20:49','738653f9-bd34-4359-aadb-b2d78bfcf091'),
	(248,14,205,NULL,19,2,'2020-12-09 23:20:49','2020-12-09 23:20:49','d2029fcf-e5e1-4f7c-a4bf-6842e938a5e1'),
	(249,14,205,NULL,20,3,'2020-12-09 23:20:49','2020-12-09 23:20:49','94cb2b1b-6fec-4b6d-b810-8f027e3fe55d'),
	(250,14,205,NULL,21,4,'2020-12-09 23:20:49','2020-12-09 23:20:49','3464c671-cbf0-4c10-9156-eec25374986b'),
	(257,29,214,NULL,14,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','ec81467b-e8d5-4e19-a0d4-2c3ec38c6d40'),
	(258,29,214,NULL,15,2,'2020-12-09 23:58:21','2020-12-09 23:58:21','6e9adb49-9509-4781-a33f-4e85fc7e068e'),
	(259,29,214,NULL,16,3,'2020-12-09 23:58:21','2020-12-09 23:58:21','496a4001-4aad-41b6-a52c-324003819e87'),
	(260,33,215,NULL,9,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','0f6d011e-dca2-4dad-a1d3-b13993d7b0e6'),
	(261,33,215,NULL,10,2,'2020-12-09 23:58:21','2020-12-09 23:58:21','74725370-232e-42ff-ad0c-0b1b2bf0733f'),
	(262,33,215,NULL,11,3,'2020-12-09 23:58:21','2020-12-09 23:58:21','b5ad54b9-cf53-4052-a1f3-f63b03aa79a2'),
	(263,33,215,NULL,12,4,'2020-12-09 23:58:21','2020-12-09 23:58:21','a87a880e-9a98-461b-9456-d82691930f2c'),
	(264,33,215,NULL,13,5,'2020-12-09 23:58:21','2020-12-09 23:58:21','382d9f03-2488-4b3b-adfe-953d80427043'),
	(265,37,215,NULL,17,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','bc7621dc-8daf-4732-91be-a19d4fdc32af'),
	(266,14,216,NULL,18,1,'2020-12-09 23:58:21','2020-12-09 23:58:21','5e874dc0-d7ae-4204-b89c-1080db2dd1fb'),
	(267,14,216,NULL,19,2,'2020-12-09 23:58:21','2020-12-09 23:58:21','eed0cde2-78d7-4e0b-bcf9-c83562b292af'),
	(268,14,216,NULL,20,3,'2020-12-09 23:58:21','2020-12-09 23:58:21','c28bfc3c-d83d-48d9-97cb-e625f93feab5'),
	(269,14,216,NULL,21,4,'2020-12-09 23:58:21','2020-12-09 23:58:21','dc92892d-dfd2-4910-844e-71d0eeb2d06b'),
	(276,40,224,NULL,18,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','c4666b63-e6c1-46ba-a40f-f3754627480a'),
	(277,40,224,NULL,19,2,'2020-12-10 00:00:08','2020-12-10 00:00:08','87876e5f-ed1f-4904-a404-73641d8ce668'),
	(278,40,224,NULL,20,3,'2020-12-10 00:00:08','2020-12-10 00:00:08','359ce95f-5bd7-4c61-8478-10bebe7e3c83'),
	(279,40,224,NULL,21,4,'2020-12-10 00:00:08','2020-12-10 00:00:08','0c17f516-d3f3-46a0-bf34-88cb25d78c64'),
	(280,29,226,NULL,14,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','940a7511-3fc0-4db9-81e7-9e877b63826e'),
	(281,29,226,NULL,15,2,'2020-12-10 00:00:08','2020-12-10 00:00:08','03acba0a-7a68-46ec-baa0-7ea00269cb86'),
	(282,29,226,NULL,16,3,'2020-12-10 00:00:08','2020-12-10 00:00:08','51aa3dc6-819d-4d8a-bec2-cf1ab9ca9c6f'),
	(283,33,227,NULL,9,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','0f23f069-5ec0-4160-a02e-9e675c66d3f9'),
	(284,33,227,NULL,10,2,'2020-12-10 00:00:08','2020-12-10 00:00:08','11b239fd-a4a7-460f-9e42-8af37c55b35b'),
	(285,33,227,NULL,11,3,'2020-12-10 00:00:08','2020-12-10 00:00:08','ed51af0f-e499-4858-b09a-b8b46161a424'),
	(286,33,227,NULL,12,4,'2020-12-10 00:00:08','2020-12-10 00:00:08','dc8adf97-0434-4c21-8fab-b02d978dec22'),
	(287,33,227,NULL,13,5,'2020-12-10 00:00:08','2020-12-10 00:00:08','ca0ee32a-68d3-4695-9c47-aad461cc15eb'),
	(288,37,227,NULL,17,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','74e6e2b8-c637-48c7-b2ff-ce0d059ae53a'),
	(289,40,228,NULL,18,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','3e1e4884-6346-491c-bf62-cabe9758ce10'),
	(290,40,228,NULL,19,2,'2020-12-10 00:00:08','2020-12-10 00:00:08','1d2429e3-3dcd-4e0e-9a73-7e2ed7f5f30a'),
	(291,40,228,NULL,20,3,'2020-12-10 00:00:08','2020-12-10 00:00:08','2e0ec7d1-bdea-453e-968f-a57901793c54'),
	(292,40,228,NULL,21,4,'2020-12-10 00:00:08','2020-12-10 00:00:08','3f81ecc0-b41e-4850-aa68-3edc4124749e'),
	(293,14,229,NULL,18,1,'2020-12-10 00:00:08','2020-12-10 00:00:08','8acedcdf-d2b2-4831-bf17-0dfb68ec1fed'),
	(294,14,229,NULL,19,2,'2020-12-10 00:00:08','2020-12-10 00:00:08','64b77a52-29b0-4f4d-9b16-f9e9b1e9f5bc'),
	(295,14,229,NULL,20,3,'2020-12-10 00:00:08','2020-12-10 00:00:08','948f2816-4632-47d9-a2b2-903c7690eec2'),
	(296,14,229,NULL,21,4,'2020-12-10 00:00:08','2020-12-10 00:00:08','b79c8b09-d5e8-44ff-9f82-d2c65d071a75'),
	(303,29,238,NULL,14,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','a0d6ce8e-64d5-4295-8a57-593c885a00df'),
	(304,29,238,NULL,15,2,'2020-12-10 00:08:00','2020-12-10 00:08:00','d18a42ba-b565-47ed-9be7-1dbaa6ca9000'),
	(305,29,238,NULL,16,3,'2020-12-10 00:08:00','2020-12-10 00:08:00','c1cb856f-44c5-40cf-ab0d-3715dbbc2b04'),
	(306,33,239,NULL,9,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','9aeb67f2-3ffc-446a-b8bb-cdabd5c65c86'),
	(307,33,239,NULL,10,2,'2020-12-10 00:08:00','2020-12-10 00:08:00','7b04a77c-a048-4889-909f-d6fba17d1ec7'),
	(308,33,239,NULL,11,3,'2020-12-10 00:08:00','2020-12-10 00:08:00','e4dbcbbd-7337-4453-9d7e-95c4e804fa21'),
	(309,33,239,NULL,12,4,'2020-12-10 00:08:00','2020-12-10 00:08:00','fe0a3404-ef4a-44bb-9cbc-9f5f4f266238'),
	(310,33,239,NULL,13,5,'2020-12-10 00:08:00','2020-12-10 00:08:00','ad4b0899-00e7-4c8c-ac5c-6e303ff447a5'),
	(311,37,239,NULL,17,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','a8a7fdea-d3ec-43fe-9493-289aa9c746b0'),
	(312,40,240,NULL,18,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','40282bca-77b0-43da-9d61-d49ec9132c2b'),
	(313,40,240,NULL,19,2,'2020-12-10 00:08:00','2020-12-10 00:08:00','ad4eec43-2664-400b-a01a-3005c711d1be'),
	(314,40,240,NULL,20,3,'2020-12-10 00:08:00','2020-12-10 00:08:00','3b3fdb5b-2cc5-4676-b9ba-54485a9cc73b'),
	(315,40,240,NULL,21,4,'2020-12-10 00:08:00','2020-12-10 00:08:00','1f8d4cee-05f0-457f-860c-2baa797de376'),
	(316,14,241,NULL,18,1,'2020-12-10 00:08:00','2020-12-10 00:08:00','0daba48f-a496-4c46-8273-7efea25c8270'),
	(317,14,241,NULL,19,2,'2020-12-10 00:08:00','2020-12-10 00:08:00','508849a7-98bc-43d3-b289-b2d49e678dc3'),
	(318,14,241,NULL,20,3,'2020-12-10 00:08:00','2020-12-10 00:08:00','c61e3485-a62d-49a4-aea5-8d7189853013'),
	(319,14,241,NULL,21,4,'2020-12-10 00:08:00','2020-12-10 00:08:00','f439ca05-b5b1-4042-a0e4-4221fdcec9ad'),
	(326,29,250,NULL,14,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','806e518f-8d01-4cc9-9cfe-8fb302355be0'),
	(327,29,250,NULL,15,2,'2020-12-10 00:31:34','2020-12-10 00:31:34','ace7cc8f-4cc6-4d28-ad0b-ad948124190a'),
	(328,29,250,NULL,16,3,'2020-12-10 00:31:34','2020-12-10 00:31:34','44ebfc92-98e4-46a6-b50d-adf9dcbc3cf4'),
	(329,33,251,NULL,9,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','9ae16215-6825-4275-9d22-dacd3e6b04f1'),
	(330,33,251,NULL,10,2,'2020-12-10 00:31:34','2020-12-10 00:31:34','245ebe29-dcaa-4839-9b84-42396c508683'),
	(331,33,251,NULL,11,3,'2020-12-10 00:31:34','2020-12-10 00:31:34','77631301-e731-4b81-848d-69d800303792'),
	(332,33,251,NULL,12,4,'2020-12-10 00:31:34','2020-12-10 00:31:34','29b5f036-6e3e-48fa-8beb-365246c04e16'),
	(333,33,251,NULL,13,5,'2020-12-10 00:31:34','2020-12-10 00:31:34','de815486-ba31-4797-9d21-0f6aed536b9c'),
	(334,37,251,NULL,17,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','86c3e28a-b6f6-4a92-a349-d00e12a59321'),
	(335,40,252,NULL,18,1,'2020-12-10 00:31:34','2020-12-10 00:31:34','c0775b3a-d502-4354-af9c-e22421e99253'),
	(336,40,252,NULL,19,2,'2020-12-10 00:31:34','2020-12-10 00:31:34','3e02e093-b735-45ca-905a-2a2eae2e272d'),
	(337,40,252,NULL,20,3,'2020-12-10 00:31:34','2020-12-10 00:31:34','68f3ea5e-2d4f-43f9-8d52-3622abe5f642'),
	(338,40,252,NULL,21,4,'2020-12-10 00:31:34','2020-12-10 00:31:34','19624052-a48f-44e5-8cb9-806cc6a69d81'),
	(339,14,253,NULL,18,1,'2020-12-10 00:31:35','2020-12-10 00:31:35','80a10ed2-974f-426b-aa95-03fe005b5e63'),
	(340,14,253,NULL,19,2,'2020-12-10 00:31:35','2020-12-10 00:31:35','e84fee70-0a1c-4cab-86f2-3b75d41bd149'),
	(341,14,253,NULL,20,3,'2020-12-10 00:31:35','2020-12-10 00:31:35','129c3546-8298-4540-b4be-17be1b7f5e7d'),
	(342,14,253,NULL,21,4,'2020-12-10 00:31:35','2020-12-10 00:31:35','c59e6a80-942a-4431-9915-e65a3fe4e007'),
	(343,29,259,NULL,14,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','61582808-4cfa-4c26-a840-c57ee421d943'),
	(344,29,259,NULL,15,2,'2020-12-10 00:33:07','2020-12-10 00:33:07','daaecd06-c7cc-49c9-a705-24dbc89cbe7d'),
	(345,29,259,NULL,16,3,'2020-12-10 00:33:07','2020-12-10 00:33:07','51e55dfb-3ad1-48e5-9072-dc8ef0affd06'),
	(346,33,260,NULL,9,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','89815e97-d1dc-42e4-a238-5ced7966f4a5'),
	(347,33,260,NULL,10,2,'2020-12-10 00:33:07','2020-12-10 00:33:07','ed9925ca-7aa3-4742-8318-999e88f6cb08'),
	(348,33,260,NULL,11,3,'2020-12-10 00:33:07','2020-12-10 00:33:07','8e11c537-b520-4740-8ee2-8070584e40ea'),
	(349,33,260,NULL,12,4,'2020-12-10 00:33:07','2020-12-10 00:33:07','c2fe32ba-1f16-4869-9312-64d98a735510'),
	(350,33,260,NULL,13,5,'2020-12-10 00:33:07','2020-12-10 00:33:07','500142d2-7f36-41b5-81bd-89711206395f'),
	(351,37,260,NULL,17,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','b9ef6b93-9180-4928-a65d-b71a90b4f795'),
	(352,40,261,NULL,18,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','aa87f58a-deec-4048-8c60-f7c77743b821'),
	(353,40,261,NULL,19,2,'2020-12-10 00:33:07','2020-12-10 00:33:07','5ab8c99b-a95f-4d82-9650-ea3eb159b192'),
	(354,40,261,NULL,20,3,'2020-12-10 00:33:07','2020-12-10 00:33:07','dc056a83-a1be-489b-8934-3e030526e802'),
	(355,40,261,NULL,21,4,'2020-12-10 00:33:07','2020-12-10 00:33:07','7bcf245e-063f-44dd-bc1b-32abd93218d6'),
	(356,14,263,NULL,18,1,'2020-12-10 00:33:07','2020-12-10 00:33:07','5ca56fe1-04f7-4853-803d-6b79c9901716'),
	(357,14,263,NULL,19,2,'2020-12-10 00:33:07','2020-12-10 00:33:07','354d15ad-ec73-4a2d-8005-2c4c08a1541d'),
	(358,14,263,NULL,20,3,'2020-12-10 00:33:07','2020-12-10 00:33:07','61e5166d-280a-432d-9c6c-fa022fecff60'),
	(359,14,263,NULL,21,4,'2020-12-10 00:33:07','2020-12-10 00:33:07','3f99681a-7180-4664-bfb5-873176b249a1'),
	(360,29,268,NULL,14,1,'2020-12-10 00:34:13','2020-12-10 00:34:13','2d565820-602e-4049-9187-9fa3ab74c72b'),
	(361,29,268,NULL,15,2,'2020-12-10 00:34:13','2020-12-10 00:34:13','825c68b5-2cd3-4b2b-ab9b-ace11966e580'),
	(362,29,268,NULL,16,3,'2020-12-10 00:34:13','2020-12-10 00:34:13','7b078526-0b0f-4652-8d50-b38678354fe5'),
	(363,33,269,NULL,9,1,'2020-12-10 00:34:13','2020-12-10 00:34:13','a5c960ca-d144-463a-b579-377769fce707'),
	(364,33,269,NULL,10,2,'2020-12-10 00:34:13','2020-12-10 00:34:13','36320c55-a9d4-4ffc-a127-2353490c296d'),
	(365,33,269,NULL,11,3,'2020-12-10 00:34:13','2020-12-10 00:34:13','336412f5-457f-40b9-b773-2450e611b5dc'),
	(366,33,269,NULL,12,4,'2020-12-10 00:34:13','2020-12-10 00:34:13','f3473239-0860-4176-aee8-611876dc57f5'),
	(367,33,269,NULL,13,5,'2020-12-10 00:34:13','2020-12-10 00:34:13','6889fcf6-d224-4525-a61d-01c1e79f2606'),
	(368,37,269,NULL,17,1,'2020-12-10 00:34:13','2020-12-10 00:34:13','56ea2ce8-429c-4b1d-ba5e-ce13fc6770b4'),
	(369,40,270,NULL,18,1,'2020-12-10 00:34:13','2020-12-10 00:34:13','6b7ed1db-eb61-4600-8beb-9f7a029e8dcf'),
	(370,40,270,NULL,19,2,'2020-12-10 00:34:13','2020-12-10 00:34:13','8544a249-e823-44a8-8e79-42d8e156622e'),
	(371,40,270,NULL,20,3,'2020-12-10 00:34:13','2020-12-10 00:34:13','beea50d2-9e24-410c-8eda-1c9f87694295'),
	(372,40,270,NULL,21,4,'2020-12-10 00:34:13','2020-12-10 00:34:13','c1af4410-2f4d-46a3-9cd7-41962f792833'),
	(373,29,273,NULL,14,1,'2020-12-10 00:34:53','2020-12-10 00:34:53','f9a4d693-e22e-4112-be26-6381aa2a6996'),
	(374,29,273,NULL,15,2,'2020-12-10 00:34:53','2020-12-10 00:34:53','eac0dcc5-f703-48ca-9446-284256a04ca8'),
	(375,29,273,NULL,16,3,'2020-12-10 00:34:53','2020-12-10 00:34:53','cb738de0-7c7d-46b8-a7a2-a8ac87987ef4'),
	(376,33,274,NULL,9,1,'2020-12-10 00:34:53','2020-12-10 00:34:53','64ec9650-3644-48b9-8931-1bae04164fa4'),
	(377,33,274,NULL,10,2,'2020-12-10 00:34:53','2020-12-10 00:34:53','cddc273f-6222-4b6a-aa97-2d1438748dff'),
	(378,33,274,NULL,11,3,'2020-12-10 00:34:53','2020-12-10 00:34:53','f066b135-ef69-4fc0-809e-c74aee31a97d'),
	(379,33,274,NULL,12,4,'2020-12-10 00:34:53','2020-12-10 00:34:53','77c443bf-ddc7-4160-a3ed-db6545ecf2e8'),
	(380,33,274,NULL,13,5,'2020-12-10 00:34:53','2020-12-10 00:34:53','77346ee9-1262-4bb4-88c8-cfe4444d926f'),
	(381,37,274,NULL,17,1,'2020-12-10 00:34:54','2020-12-10 00:34:54','49fd2423-dcdf-4f73-9b97-2b009aa962d1'),
	(382,40,275,NULL,18,1,'2020-12-10 00:34:54','2020-12-10 00:34:54','4bf5692d-8f22-4668-a4ac-7ac88b0531d9'),
	(383,40,275,NULL,19,2,'2020-12-10 00:34:54','2020-12-10 00:34:54','585ac542-1bb0-43ab-b4ab-0c13730f6ef4'),
	(384,40,275,NULL,20,3,'2020-12-10 00:34:54','2020-12-10 00:34:54','ac0bfdf0-99e0-4799-88c8-0d19ef60c5a9'),
	(385,40,275,NULL,21,4,'2020-12-10 00:34:54','2020-12-10 00:34:54','fd8e3907-b653-434d-ba1f-042f2fb7d397'),
	(386,29,127,NULL,20,4,'2020-12-14 23:15:24','2020-12-14 23:15:24','1abe7be1-021d-4aef-a5de-c5b1f36d70e4'),
	(387,29,278,NULL,14,1,'2020-12-14 23:15:24','2020-12-14 23:15:24','839ca1b1-b0c1-4297-8df2-7be8a68d7c68'),
	(388,29,278,NULL,15,2,'2020-12-14 23:15:24','2020-12-14 23:15:24','25dbe9a5-ec56-45b3-8ceb-02da1b48e1ad'),
	(389,29,278,NULL,16,3,'2020-12-14 23:15:24','2020-12-14 23:15:24','f0d5f597-5ced-462e-aa92-573886470c10'),
	(390,29,278,NULL,20,4,'2020-12-14 23:15:24','2020-12-14 23:15:24','1e06fe40-c91b-4387-a980-26e4e4d72c43'),
	(391,33,279,NULL,9,1,'2020-12-14 23:15:24','2020-12-14 23:15:24','48d67cee-9ae9-47c4-ab21-ce443f2f5457'),
	(392,33,279,NULL,10,2,'2020-12-14 23:15:24','2020-12-14 23:15:24','d26cd23e-7129-4b79-af1b-a7649d55c8d5'),
	(393,33,279,NULL,11,3,'2020-12-14 23:15:24','2020-12-14 23:15:24','95c16b52-754b-4571-8aba-28e4ed262028'),
	(394,33,279,NULL,12,4,'2020-12-14 23:15:24','2020-12-14 23:15:24','439b3130-7005-49c0-9a7e-415cd511663c'),
	(395,33,279,NULL,13,5,'2020-12-14 23:15:24','2020-12-14 23:15:24','2b878fe2-2792-4874-93eb-e0e46a52c223'),
	(396,37,279,NULL,17,1,'2020-12-14 23:15:24','2020-12-14 23:15:24','dfca7d8e-cead-4240-a670-97b1ba5cb4f1'),
	(397,40,280,NULL,18,1,'2020-12-14 23:15:24','2020-12-14 23:15:24','7e6147de-34e3-4e08-9865-7f3cd598aa8e'),
	(398,40,280,NULL,19,2,'2020-12-14 23:15:24','2020-12-14 23:15:24','26b065e8-4e94-49f0-a90a-7ba8f999674c'),
	(399,40,280,NULL,20,3,'2020-12-14 23:15:24','2020-12-14 23:15:24','8d072dc8-115b-4b3d-a20e-1989da4e5a14'),
	(400,40,280,NULL,21,4,'2020-12-14 23:15:24','2020-12-14 23:15:24','f758fc3f-da90-4411-84bb-1c03464d69ba'),
	(401,29,283,NULL,14,1,'2020-12-16 06:04:29','2020-12-16 06:04:29','cac77ec2-950b-45e1-a1e4-610b607ea366'),
	(402,29,283,NULL,15,2,'2020-12-16 06:04:29','2020-12-16 06:04:29','127dd108-a7c8-4967-b2d9-dc3afea6218a'),
	(403,29,283,NULL,16,3,'2020-12-16 06:04:29','2020-12-16 06:04:29','11d9eb4e-458e-447d-ac74-670941b2f87e'),
	(404,29,283,NULL,20,4,'2020-12-16 06:04:29','2020-12-16 06:04:29','08cb6687-ba3f-410c-972a-6dbcf187a8b8'),
	(405,33,284,NULL,9,1,'2020-12-16 06:04:29','2020-12-16 06:04:29','cf5c449f-a10b-4e62-959a-c0b8aee3f2aa'),
	(406,33,284,NULL,10,2,'2020-12-16 06:04:29','2020-12-16 06:04:29','d8941cc7-04e2-4a31-a6e1-c544955ced07'),
	(407,33,284,NULL,11,3,'2020-12-16 06:04:29','2020-12-16 06:04:29','765133be-8467-4f7d-b990-a2195f3cf93c'),
	(408,33,284,NULL,12,4,'2020-12-16 06:04:29','2020-12-16 06:04:29','741690b5-c81c-4857-815d-de308ef61e23'),
	(409,33,284,NULL,13,5,'2020-12-16 06:04:29','2020-12-16 06:04:29','668a52b4-3771-45c5-b5f5-de60dd91230a'),
	(410,37,284,NULL,17,1,'2020-12-16 06:04:29','2020-12-16 06:04:29','08dd7b88-86a0-40cd-8c88-2631ab3e1f2e'),
	(411,40,285,NULL,18,1,'2020-12-16 06:04:29','2020-12-16 06:04:29','da4f47db-202f-434e-a091-830af8a2d16f'),
	(412,40,285,NULL,19,2,'2020-12-16 06:04:29','2020-12-16 06:04:29','ec4fa7ac-bb14-470d-9191-bfa6e9caaf2c'),
	(413,40,285,NULL,20,3,'2020-12-16 06:04:29','2020-12-16 06:04:29','dfd023cb-955e-4d28-ad6f-c74e28b3f7cc'),
	(414,40,285,NULL,21,4,'2020-12-16 06:04:29','2020-12-16 06:04:29','44d05ec1-8e35-42f4-8219-9115a50e4cd9'),
	(415,29,288,NULL,14,1,'2020-12-16 06:05:08','2020-12-16 06:05:08','76397b92-074c-48a1-9230-6ce89a8a3e05'),
	(416,29,288,NULL,15,2,'2020-12-16 06:05:08','2020-12-16 06:05:08','8188dadc-309e-4f4a-a5da-2461ae644e6a'),
	(417,29,288,NULL,16,3,'2020-12-16 06:05:08','2020-12-16 06:05:08','975b8538-7850-4024-a8a2-bfc29e8be816'),
	(418,29,288,NULL,20,4,'2020-12-16 06:05:08','2020-12-16 06:05:08','4ee735e9-c35e-4631-b4ab-b03400e8d754'),
	(419,33,289,NULL,9,1,'2020-12-16 06:05:09','2020-12-16 06:05:09','ea726cfd-9c58-4da4-98b3-7efd95bbd800'),
	(420,33,289,NULL,10,2,'2020-12-16 06:05:09','2020-12-16 06:05:09','31a1d18a-bf12-426d-a96f-656c91b352f0'),
	(421,33,289,NULL,11,3,'2020-12-16 06:05:09','2020-12-16 06:05:09','bf980e65-45e7-47e0-ad7f-81116c3c7f44'),
	(422,33,289,NULL,12,4,'2020-12-16 06:05:09','2020-12-16 06:05:09','9238cbb2-e61e-4d5c-a0ba-d3770b072415'),
	(423,33,289,NULL,13,5,'2020-12-16 06:05:09','2020-12-16 06:05:09','f9d95f28-3451-4dca-b927-346c10727aac'),
	(424,37,289,NULL,17,1,'2020-12-16 06:05:09','2020-12-16 06:05:09','0a9b2446-337c-4f87-b4d8-109d954a481b'),
	(425,40,290,NULL,18,1,'2020-12-16 06:05:09','2020-12-16 06:05:09','84c76753-ad6c-4334-95e8-496b7e1bee6c'),
	(426,40,290,NULL,19,2,'2020-12-16 06:05:09','2020-12-16 06:05:09','f19077d5-0f11-4444-b0b6-7cbc33aee747'),
	(427,40,290,NULL,20,3,'2020-12-16 06:05:09','2020-12-16 06:05:09','ae2a3c12-3e0b-4882-9c50-9c0eed27493d'),
	(428,40,290,NULL,21,4,'2020-12-16 06:05:09','2020-12-16 06:05:09','eafb1f32-df9b-458a-8439-a8337493041c'),
	(429,29,293,NULL,14,1,'2020-12-16 06:13:57','2020-12-16 06:13:57','58574551-7f6a-4cb0-98dc-f5d47ddb1845'),
	(430,29,293,NULL,15,2,'2020-12-16 06:13:57','2020-12-16 06:13:57','659eef20-8f10-4714-bd44-64ba8551c977'),
	(431,29,293,NULL,16,3,'2020-12-16 06:13:57','2020-12-16 06:13:57','b3ce7f4a-7442-479b-8834-7e59aa1de08e'),
	(432,29,293,NULL,20,4,'2020-12-16 06:13:57','2020-12-16 06:13:57','33077704-3623-4e80-b7b6-efb476ebc9b4'),
	(433,33,294,NULL,9,1,'2020-12-16 06:13:58','2020-12-16 06:13:58','65868e56-9902-4c0c-9b35-db45477d1de9'),
	(434,33,294,NULL,10,2,'2020-12-16 06:13:58','2020-12-16 06:13:58','30c752f0-093a-4829-b65f-c0224a6067bc'),
	(435,33,294,NULL,11,3,'2020-12-16 06:13:58','2020-12-16 06:13:58','f0222109-c5e7-4290-9567-11e3f53a38eb'),
	(436,33,294,NULL,12,4,'2020-12-16 06:13:58','2020-12-16 06:13:58','a535c2cd-0c09-43c2-bff5-2fc9b5a6a9d3'),
	(437,33,294,NULL,13,5,'2020-12-16 06:13:58','2020-12-16 06:13:58','7442dd92-d0b5-4f8a-ba4b-94d388002881'),
	(438,37,294,NULL,17,1,'2020-12-16 06:13:58','2020-12-16 06:13:58','d4583203-979b-400c-bd3a-b09b20563366'),
	(439,40,295,NULL,18,1,'2020-12-16 06:13:58','2020-12-16 06:13:58','1083e5cd-fac0-4600-9ccc-d4bda9c14173'),
	(440,40,295,NULL,19,2,'2020-12-16 06:13:58','2020-12-16 06:13:58','13ac0740-87ae-4c48-99c9-ecba14819c2e'),
	(441,40,295,NULL,20,3,'2020-12-16 06:13:58','2020-12-16 06:13:58','98e7f134-9fac-4254-a1e2-216cec8ce45b'),
	(442,40,295,NULL,21,4,'2020-12-16 06:13:58','2020-12-16 06:13:58','ea26ba5f-3f57-4f6d-95a5-0cbb40801958'),
	(443,40,224,NULL,22,5,'2020-12-16 12:18:09','2020-12-16 12:18:09','f3a4645a-a510-4718-9997-b367585f9786'),
	(444,29,298,NULL,14,1,'2020-12-16 12:18:09','2020-12-16 12:18:09','cdb36ad1-94ce-4590-b486-aec190e3f9c1'),
	(445,29,298,NULL,15,2,'2020-12-16 12:18:09','2020-12-16 12:18:09','256ed767-ac4f-4909-b407-4a504419557c'),
	(446,29,298,NULL,16,3,'2020-12-16 12:18:09','2020-12-16 12:18:09','4db756ed-11e2-4d0b-8fb2-eaba4a96e257'),
	(447,29,298,NULL,20,4,'2020-12-16 12:18:09','2020-12-16 12:18:09','b8573049-f031-413d-817a-9f9e6ce02ea0'),
	(448,33,299,NULL,9,1,'2020-12-16 12:18:09','2020-12-16 12:18:09','42baa1f2-2525-4bbc-96b0-0748d98732e2'),
	(449,33,299,NULL,10,2,'2020-12-16 12:18:09','2020-12-16 12:18:09','e6a95a07-c03b-446f-9446-68b1a38ea116'),
	(450,33,299,NULL,11,3,'2020-12-16 12:18:09','2020-12-16 12:18:09','d52a00db-eddc-4caf-9c31-bd69e845ff27'),
	(451,33,299,NULL,12,4,'2020-12-16 12:18:09','2020-12-16 12:18:09','170f48dc-52da-439b-b052-a32bedf925c0'),
	(452,33,299,NULL,13,5,'2020-12-16 12:18:09','2020-12-16 12:18:09','fc94a96e-9e45-4719-9240-7b06d942880b'),
	(453,37,299,NULL,17,1,'2020-12-16 12:18:09','2020-12-16 12:18:09','66d6cc72-4f24-41e4-8c01-0f316720f2e2'),
	(454,40,300,NULL,18,1,'2020-12-16 12:18:09','2020-12-16 12:18:09','1a66eb61-c089-4368-97ce-e268998664af'),
	(455,40,300,NULL,19,2,'2020-12-16 12:18:09','2020-12-16 12:18:09','937fb8fe-0f26-49ff-a539-baac69483bbe'),
	(456,40,300,NULL,20,3,'2020-12-16 12:18:09','2020-12-16 12:18:09','4db484a7-89fa-4992-a661-d8c617d468db'),
	(457,40,300,NULL,21,4,'2020-12-16 12:18:09','2020-12-16 12:18:09','3ca5c88e-d5a0-4b83-9d42-17050e3509a4'),
	(458,40,300,NULL,22,5,'2020-12-16 12:18:09','2020-12-16 12:18:09','2b11c1c6-1856-4aa7-a8f2-2faced5c5505'),
	(459,29,303,NULL,14,1,'2020-12-16 12:19:22','2020-12-16 12:19:22','7731615b-a4ef-41aa-8a16-fb79c111eb5c'),
	(460,29,303,NULL,15,2,'2020-12-16 12:19:22','2020-12-16 12:19:22','d8d3c101-a367-48dd-b714-463998ef5ee7'),
	(461,29,303,NULL,16,3,'2020-12-16 12:19:22','2020-12-16 12:19:22','1f6e7a6e-76b1-4b9b-a732-73fc1150d185'),
	(462,29,303,NULL,20,4,'2020-12-16 12:19:22','2020-12-16 12:19:22','12d6e616-b92a-41bd-8497-0c8e5c8a264b'),
	(463,33,304,NULL,9,1,'2020-12-16 12:19:22','2020-12-16 12:19:22','116ea08e-c597-4910-8e26-9a822f9a0846'),
	(464,33,304,NULL,10,2,'2020-12-16 12:19:22','2020-12-16 12:19:22','d67bdc22-0089-4692-81d3-aa710231d79b'),
	(465,33,304,NULL,11,3,'2020-12-16 12:19:22','2020-12-16 12:19:22','75af73b4-189e-4285-a9ef-a32b18c70b06'),
	(466,33,304,NULL,12,4,'2020-12-16 12:19:22','2020-12-16 12:19:22','aea1652a-1ba6-41b4-8a2a-f397739232dd'),
	(467,33,304,NULL,13,5,'2020-12-16 12:19:22','2020-12-16 12:19:22','9449d904-ef9f-4481-8043-1e8760625ba6'),
	(468,37,304,NULL,17,1,'2020-12-16 12:19:22','2020-12-16 12:19:22','13a2d742-9010-4a87-951e-ca8b5ba24884'),
	(469,40,305,NULL,18,1,'2020-12-16 12:19:22','2020-12-16 12:19:22','6c248a09-4679-493b-b3fa-515693cf3cf7'),
	(470,40,305,NULL,19,2,'2020-12-16 12:19:22','2020-12-16 12:19:22','79fac290-7316-41eb-891d-19d1760e4287'),
	(471,40,305,NULL,20,3,'2020-12-16 12:19:22','2020-12-16 12:19:22','086efe80-d506-468a-a4be-ac0e395c4241'),
	(472,40,305,NULL,21,4,'2020-12-16 12:19:22','2020-12-16 12:19:22','d4717d62-f8db-4520-9c51-c949aa88d0bd'),
	(473,40,305,NULL,22,5,'2020-12-16 12:19:22','2020-12-16 12:19:22','d8581cc8-5a88-4c8e-b988-041cb3adb30e');

/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table resourcepaths
# ------------------------------------------------------------

DROP TABLE IF EXISTS `resourcepaths`;

CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;

INSERT INTO `resourcepaths` (`hash`, `path`)
VALUES
	('1133e210','@app/web/assets/craftsupport/dist'),
	('12e26d88','@app/web/assets/fieldsettings/dist'),
	('1fa14ed1','@app/web/assets/updateswidget/dist'),
	('20c76e31','@lib/vue'),
	('211b0cbf','@app/web/assets/recententries/dist'),
	('33f24dca','@craft/web/assets/login/dist'),
	('38683e4c','@app/web/assets/login/dist'),
	('3bf4fa07','@craft/web/assets/craftsupport/dist'),
	('3c562b32','@app/web/assets/cp/dist'),
	('3d14371d','@craft/redactor/assets/redactor-plugins/dist/fullscreen'),
	('41debb06','@wrav/oembed/assetbundles/oembed/dist/js'),
	('454d608c','@app/web/assets/feed/dist'),
	('495216a8','@lib/velocity'),
	('4e1c743','@craft/web/assets/feed/dist'),
	('5575b940','@lib/jquery.payment'),
	('57bd349b','@storage/rebrand/logo'),
	('58dde1d5','@bower/jquery/dist'),
	('59c50ce','@craft/redactor/assets/field/dist'),
	('5e2d69a3','@app/web/assets/utilities/dist'),
	('6bb6c824','@wrav/oembed/assetbundles/oembed/dist/css'),
	('6d74f019','@storage/rebrand/logo'),
	('748734e3','@app/web/assets/matrixsettings/dist'),
	('774d4a20','@lib/element-resize-detector'),
	('7da2e188','@craft/web/assets/dashboard/dist'),
	('7f524638','@lib/iframe-resizer-cw'),
	('7fb8d0d','@lib/jquery-ui'),
	('8009f0d6','@lib/selectize'),
	('8626d59f','@craft/web/assets/cp/dist'),
	('8a65b45c','@lib/xregexp'),
	('90907b57','@craft/redactor/assets/redactor/dist'),
	('9c580c0e','@craft/web/assets/updateswidget/dist'),
	('a19ea12e','@app/web/assets/admintable/dist'),
	('a2e24e60','@craft/web/assets/recententries/dist'),
	('accb84c0','@app/web/assets/clearcaches/dist'),
	('b0522c0','@app/web/assets/generalsettings/dist'),
	('b59aec29','@lib/timepicker'),
	('b7afe355','@app/web/assets/editsection/dist'),
	('bd90286d','@app/web/assets/plugins/dist'),
	('c013ea5d','@app/web/assets/dbbackup/dist'),
	('c03ce3bb','@lib/iframe-resizer'),
	('c9960cf0','@app/web/assets/sites/dist'),
	('cc9fdcac','@lib/fileupload'),
	('d0df854a','@app/web/assets/matrix/dist'),
	('d155eb19','@lib/prismjs'),
	('d2ccd44','@lib/axios'),
	('d3d3e190','@lib/jquery-touch-events'),
	('d477dd52','@lib/picturefill'),
	('dad2fd03','@lib/d3'),
	('dffda77e','@app/web/assets/editentry/dist'),
	('e0a6aa0f','@app/web/assets/updates/dist'),
	('e96fea85','@lib/garnishjs'),
	('f83c4b30','@app/web/assets/fields/dist'),
	('fc293ebb','@lib/fabric'),
	('ff5b657e','@app/web/assets/dashboard/dist');

/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table revisions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `revisions`;

CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sourceId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `revisions_sourceId_num_unq_idx` (`sourceId`,`num`),
  KEY `revisions_creatorId_fk` (`creatorId`),
  CONSTRAINT `revisions_creatorId_fk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `revisions_sourceId_fk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;

INSERT INTO `revisions` (`id`, `sourceId`, `creatorId`, `num`, `notes`)
VALUES
	(1,1,NULL,1,NULL),
	(2,3,NULL,1,NULL),
	(3,1,5,2,''),
	(4,3,5,2,''),
	(5,3,5,3,''),
	(6,3,5,4,''),
	(7,36,5,1,NULL),
	(8,39,5,1,NULL),
	(9,1,5,3,NULL),
	(10,1,5,4,''),
	(11,1,5,5,''),
	(12,1,5,6,''),
	(13,57,5,1,NULL),
	(14,61,5,1,NULL),
	(15,64,5,1,NULL),
	(16,64,5,2,''),
	(17,61,5,2,''),
	(18,57,5,2,''),
	(19,64,5,3,''),
	(20,61,5,3,''),
	(21,57,5,3,''),
	(22,1,5,7,''),
	(23,1,5,8,''),
	(24,1,5,9,''),
	(25,1,5,10,''),
	(26,1,5,11,''),
	(27,1,5,12,NULL),
	(28,1,5,13,''),
	(29,1,5,14,''),
	(30,1,5,15,NULL),
	(31,1,5,16,''),
	(32,1,5,17,NULL),
	(33,1,5,18,''),
	(34,1,5,19,NULL),
	(35,1,5,20,''),
	(36,1,5,21,''),
	(37,1,5,22,''),
	(38,1,5,23,''),
	(39,1,5,24,NULL),
	(40,1,5,25,''),
	(41,1,5,26,''),
	(42,1,5,27,NULL),
	(43,1,5,28,''),
	(44,1,5,29,''),
	(45,1,5,30,''),
	(46,1,5,31,''),
	(47,1,5,32,''),
	(48,1,5,33,''),
	(49,1,5,34,''),
	(50,1,5,35,''),
	(51,1,5,36,'');

/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table searchindex
# ------------------------------------------------------------

DROP TABLE IF EXISTS `searchindex`;

CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `searchindex_keywords_idx` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;

INSERT INTO `searchindex` (`elementId`, `attribute`, `fieldId`, `siteId`, `keywords`)
VALUES
	(1,'title',0,1,' home '),
	(5,'username',0,1,' andyzack '),
	(5,'firstname',0,1,''),
	(5,'lastname',0,1,''),
	(5,'fullname',0,1,''),
	(5,'email',0,1,' andyzack gmail com '),
	(5,'slug',0,1,''),
	(6,'filename',0,1,' branchout logo svg '),
	(6,'extension',0,1,' svg '),
	(6,'kind',0,1,' image '),
	(6,'slug',0,1,''),
	(6,'title',0,1,' branchout logo '),
	(7,'filename',0,1,' branchout jaggeddivider svg '),
	(7,'extension',0,1,' svg '),
	(7,'kind',0,1,' image '),
	(7,'slug',0,1,''),
	(7,'title',0,1,' branchout jaggeddivider '),
	(8,'filename',0,1,' branchout badge svg '),
	(8,'extension',0,1,' svg '),
	(8,'kind',0,1,' image '),
	(8,'slug',0,1,''),
	(8,'title',0,1,' branchout badge '),
	(9,'kind',0,1,' image '),
	(9,'extension',0,1,' svg '),
	(9,'filename',0,1,' branchout icon1 svg '),
	(10,'kind',0,1,' image '),
	(10,'extension',0,1,' svg '),
	(10,'filename',0,1,' branchout icon2 svg '),
	(11,'kind',0,1,' image '),
	(11,'extension',0,1,' svg '),
	(11,'filename',0,1,' branchout icon3 svg '),
	(12,'kind',0,1,' image '),
	(12,'extension',0,1,' svg '),
	(12,'filename',0,1,' branchout icon4 svg '),
	(13,'kind',0,1,' image '),
	(13,'extension',0,1,' svg '),
	(13,'filename',0,1,' branchout icon5 svg '),
	(14,'slug',0,1,''),
	(14,'title',0,1,' activities '),
	(14,'extension',0,1,' jpg '),
	(14,'kind',0,1,' image '),
	(15,'slug',0,1,''),
	(15,'title',0,1,' places '),
	(15,'kind',0,1,' image '),
	(15,'extension',0,1,' jpg '),
	(16,'slug',0,1,''),
	(16,'extension',0,1,' jpg '),
	(16,'kind',0,1,' image '),
	(17,'kind',0,1,' image '),
	(17,'extension',0,1,' jpg '),
	(17,'filename',0,1,' 40999098740 eb68d5446e o jpg '),
	(18,'field',4,1,' 4 days 3 nights '),
	(18,'kind',0,1,' image '),
	(18,'slug',0,1,''),
	(18,'title',0,1,' the icons of tasmania '),
	(19,'field',4,1,' 4 days 3 nights '),
	(19,'kind',0,1,' image '),
	(19,'extension',0,1,' jpg '),
	(19,'filename',0,1,' img 8649 jpg '),
	(20,'extension',0,1,' jpg '),
	(20,'slug',0,1,''),
	(20,'kind',0,1,' image '),
	(21,'kind',0,1,' image '),
	(21,'extension',0,1,' jpg '),
	(21,'filename',0,1,' mg 8105 jpg '),
	(22,'slug',0,1,''),
	(22,'title',0,1,' beating heart of australias red centre alice '),
	(14,'filename',0,1,' 14711049381 84dab5ff50 o jpg '),
	(14,'field',4,1,' immersive activities '),
	(15,'filename',0,1,' mg 7346 jpg '),
	(15,'field',4,1,' incredible places '),
	(16,'filename',0,1,' mg 8600 jpg '),
	(16,'field',4,1,' curative packages '),
	(16,'field',3,1,' curative packages '),
	(127,'slug',0,1,''),
	(15,'field',3,1,' incredible places '),
	(14,'field',3,1,' immersive activities '),
	(24,'slug',0,1,''),
	(24,'field',8,1,''),
	(24,'field',7,1,' wide '),
	(25,'slug',0,1,''),
	(25,'field',14,1,' 14711049381 84dab5ff50 o mg 7346 mg 8600 '),
	(25,'field',13,1,' 4 3 '),
	(3,'slug',0,1,' about '),
	(3,'title',0,1,' about '),
	(3,'field',2,1,' wide 4 3 14711049381 84dab5ff50 o mg 7346 mg 8600 '),
	(36,'slug',0,1,' guide to broome '),
	(36,'title',0,1,' guide to broome '),
	(36,'field',1,1,' broomes rich and colourful history has created a multicultural melting pot that is reflected in the towns welcoming and laid back feel warm temperatures and palms deliver a tropical vibe that fits perfectly with the many holiday resorts and the stretch of white sand known as cable beach dont miss watching the sunset on the endless sandy stretch of cable beach trying on the perfect white orbs of cultured broome pearls the trip of a lifetime cruising the kimberley departing from broome how to get there virgin australia and qantas fly to broome and it is serviced by most australian capital cities otherwise its a 2 226 kilometre 1 383 mile drive from perth the capital city of western australia '),
	(36,'field',2,1,''),
	(39,'slug',0,1,' guide to alice springs '),
	(39,'title',0,1,' guide to alice springs '),
	(39,'field',1,1,' surrounded by ochre sands and hauntingly beautiful mountain ranges is alice springs a city perhaps surprisingly full of arts events and culture despite its remoteness known to locals simply as alice its the beating heart of australias red centre and one of the largest towns in the northern territory alice is also a fascinating spot to explore australias aboriginal culture and unique wildlife while there is plenty to do in the town itself alice springs is also a great base for exploring the natural wonders of the outback including ulur u kata tjut a kings canyon the west macdonnell ranges dont miss get up close and personal with native wildlife at the kangaroo sanctuary dine under the stars with aboriginal chef bob pernuka from rt tours discover the work of noted indigenous artists at araluen arts centre '),
	(39,'field',2,1,''),
	(1,'slug',0,1,' home '),
	(42,'slug',0,1,''),
	(42,'field',14,1,' the icons of tasmania make the most of the gold coast the gateway to queenslands tropical north cairns hobart is a small city with big ideas '),
	(42,'field',13,1,' 16 9 '),
	(18,'extension',0,1,' jpg '),
	(47,'slug',0,1,''),
	(47,'field',8,1,' 14711049381 84dab5ff50 o '),
	(47,'field',7,1,' wide '),
	(48,'slug',0,1,''),
	(48,'field',8,1,' mg 7346 '),
	(48,'field',7,1,' wide '),
	(49,'slug',0,1,''),
	(49,'field',8,1,' mg 8600 '),
	(49,'field',7,1,' wide '),
	(96,'slug',0,1,''),
	(57,'slug',0,1,' immersive activities '),
	(57,'title',0,1,' immersive activities '),
	(57,'field',18,1,' delivering an immersive experience is exciting '),
	(57,'field',19,1,' immersive experiences the use of technology storytelling and space to convey a message educate or entertain can transport visitors to another time and or place increasingly companies are recognizing immersive experiences as an opportunity to engage with customers in a unique and powerful way here are six tips for approaching your first immersive experience project '),
	(61,'slug',0,1,' places '),
	(61,'field',18,1,' incredible places '),
	(61,'field',19,1,' lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum '),
	(64,'slug',0,1,' packages '),
	(64,'field',18,1,' curated packages '),
	(64,'field',19,1,' lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum '),
	(66,'slug',0,1,''),
	(66,'field',8,1,' mg 8600 '),
	(66,'field',7,1,' wide '),
	(64,'field',2,1,' mg 8600 wide '),
	(69,'slug',0,1,''),
	(69,'field',8,1,' mg 7346 '),
	(69,'field',7,1,' wide '),
	(61,'field',2,1,' mg 7346 wide '),
	(72,'slug',0,1,''),
	(72,'field',8,1,' 14711049381 84dab5ff50 o '),
	(72,'field',7,1,' wide '),
	(57,'field',2,1,' 14711049381 84dab5ff50 o wide '),
	(64,'title',0,1,' packages '),
	(64,'field',20,1,' mg 8600 '),
	(61,'title',0,1,' places '),
	(61,'field',20,1,' mg 7346 '),
	(57,'field',20,1,' 14711049381 84dab5ff50 o '),
	(18,'filename',0,1,' adventure stock jpg '),
	(18,'field',3,1,' tasmania '),
	(19,'slug',0,1,''),
	(19,'title',0,1,' make the most of the gold coast '),
	(19,'field',3,1,' gold coast '),
	(22,'kind',0,1,' image '),
	(22,'filename',0,1,' mg 7359 jpg '),
	(22,'extension',0,1,' jpg '),
	(22,'field',3,1,' alice springs '),
	(20,'title',0,1,' the gateway to queenslands tropical north cairns '),
	(20,'field',4,1,' gateway to queenslands tropical north '),
	(20,'field',3,1,' cairns '),
	(21,'slug',0,1,''),
	(21,'title',0,1,' hobart is a small city with big ideas '),
	(21,'field',4,1,' 4 days 3 nights '),
	(21,'field',3,1,' hobart '),
	(20,'filename',0,1,' mg 9091 jpg '),
	(22,'field',4,1,' 4 days 3 nights '),
	(85,'slug',0,1,''),
	(85,'field',14,1,' branchout icon5 branchout icon4 branchout icon3 branchout icon2 branchout icon1 '),
	(85,'field',13,1,' 16 9 '),
	(96,'field',22,1,' connecting people and places through amazing '),
	(97,'slug',0,1,''),
	(97,'field',23,1,' we harness the power of nature and travel to help people get rebalanced reinvigorated and reconnect with what really matters in life our main goal is to take you out of the grind of daily life and help you experience exceptional places incredible moments and life changing connections '),
	(98,'slug',0,1,''),
	(98,'field',24,1,' 40999098740 eb68d5446e o '),
	(99,'slug',0,1,''),
	(99,'field',25,1,' branchout icon5 branchout icon4 branchout icon3 branchout icon2 branchout icon1 '),
	(99,'field',26,1,' 32 '),
	(99,'field',27,1,''),
	(257,'slug',0,1,''),
	(257,'field',45,1,' ready to start your adventure '),
	(106,'slug',0,1,''),
	(106,'field',6,1,''),
	(107,'slug',0,1,''),
	(107,'field',12,1,' blockquote '),
	(107,'field',10,1,''),
	(107,'field',11,1,''),
	(108,'slug',0,1,''),
	(108,'field',12,1,' blockquote '),
	(108,'field',10,1,' block quote test message '),
	(108,'field',11,1,' attribution '),
	(1,'field',2,1,''),
	(16,'title',0,1,' packages '),
	(127,'field',29,1,' activities places packages the gateway to queenslands tropical north cairns '),
	(127,'field',30,1,' 13 '),
	(127,'field',31,1,' this is my hero '),
	(1,'field',28,1,' 13 activities places packages the gateway to queenslands tropical north cairns this is my hero '),
	(168,'slug',0,1,''),
	(168,'field',33,1,' intimate groups premium accomodation luxury experiences in local communities vip options local guides real connections '),
	(9,'slug',0,1,''),
	(9,'title',0,1,' intimate groups '),
	(9,'field',4,1,' intimate groups '),
	(9,'field',3,1,' intimate groups '),
	(10,'slug',0,1,''),
	(10,'title',0,1,' premium accomodation '),
	(10,'field',4,1,' premium accomodation '),
	(10,'field',3,1,' premium accomodation '),
	(11,'slug',0,1,''),
	(11,'title',0,1,' luxury experiences in local communities '),
	(11,'field',4,1,' luxury experiences in local communities '),
	(11,'field',3,1,' luxury experiences in local communities '),
	(12,'slug',0,1,''),
	(12,'title',0,1,' vip options '),
	(12,'field',4,1,' vip options '),
	(12,'field',3,1,' vip options '),
	(13,'slug',0,1,''),
	(13,'title',0,1,' local guides real connections '),
	(13,'field',4,1,' local guides real connections '),
	(13,'field',3,1,' local guides real connections '),
	(168,'field',35,1,' connecting people and places through amazing '),
	(1,'field',32,1,' intimate groups premium accomodation luxury experiences in local communities vip options local guides real connections 40999098740 eb68d5446e o connecting people and places through amazing '),
	(168,'field',37,1,' 40999098740 eb68d5446e o '),
	(17,'slug',0,1,''),
	(17,'title',0,1,' connecting people and places '),
	(17,'field',4,1,' connecting people and places '),
	(17,'field',3,1,' connecting people and places '),
	(224,'slug',0,1,''),
	(224,'field',40,1,' the icons of tasmania make the most of the gold coast the gateway to queenslands tropical north cairns hobart is a small city with big ideas beating heart of australias red centre alice '),
	(224,'field',39,1,' 169 '),
	(224,'field',41,1,' explore details '),
	(1,'field',38,1,' 169 explore details the icons of tasmania make the most of the gold coast the gateway to queenslands tropical north cairns hobart is a small city with big ideas beating heart of australias red centre alice ');

/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table sections
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sections`;

CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sections_handle_idx` (`handle`),
  KEY `sections_name_idx` (`name`),
  KEY `sections_structureId_idx` (`structureId`),
  KEY `sections_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `sections_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;

INSERT INTO `sections` (`id`, `structureId`, `name`, `handle`, `type`, `enableVersioning`, `propagationMethod`, `previewTargets`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,NULL,'Blog','blog','channel',1,'all','[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\",\"refresh\":\"1\"},{\"label\":\"Gatsby entry page\",\"urlFormat\":\"http://localhost:8000/blog/{slug}\",\"refresh\":\"\"}]','2020-12-07 08:31:19','2020-12-07 08:31:19',NULL,'db2dff45-19b4-479c-8cba-ab88e7e7d2fd'),
	(2,NULL,'Home','home','single',1,'all','[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\"}]','2020-12-07 08:31:19','2020-12-07 08:31:19',NULL,'4593234a-cdd0-4c54-9931-4eb606b9e7f5'),
	(3,NULL,'About','about','single',1,'all','[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\"}]','2020-12-07 08:31:19','2020-12-07 08:31:19',NULL,'5a80053a-6435-4fd2-8a47-53e409d994ad'),
	(4,NULL,'Packages','packages','channel',1,'all','[{\"label\":\"Primary entry page\",\"urlFormat\":\"{url}\",\"refresh\":\"1\"}]','2020-12-08 09:39:43','2020-12-09 07:17:26',NULL,'0d7d6141-cec6-4acc-9665-0f722f1518f5');

/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table sections_sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sections_sites`;

CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sections_sites_sectionId_siteId_unq_idx` (`sectionId`,`siteId`),
  KEY `sections_sites_siteId_idx` (`siteId`),
  CONSTRAINT `sections_sites_sectionId_fk` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sections_sites_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;

INSERT INTO `sections_sites` (`id`, `sectionId`, `siteId`, `hasUrls`, `uriFormat`, `template`, `enabledByDefault`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,1,1,1,'blog/{slug}','_private/blog-entry',1,'2020-12-07 08:31:19','2020-12-07 08:31:19','b423ed10-5748-4f54-b10e-a55fd486b953'),
	(2,2,1,1,'__home__','_private/home',1,'2020-12-07 08:31:19','2020-12-07 08:31:19','0ce67374-ec4d-40cc-b71b-e505e7d2c7a8'),
	(3,3,1,1,'about','_private/about',1,'2020-12-07 08:31:19','2020-12-07 08:31:19','e01dbaf2-16ec-49b8-9ee2-ab1e07816d52'),
	(4,4,1,1,'packages/{slug}','_private/packages',1,'2020-12-08 09:39:43','2020-12-09 07:17:26','95ea80eb-d1ec-47fb-917c-14cbadc2da10');

/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table sequences
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sequences`;

CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table sessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sessions`;

CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sessions_uid_idx` (`uid`),
  KEY `sessions_token_idx` (`token`),
  KEY `sessions_dateUpdated_idx` (`dateUpdated`),
  KEY `sessions_userId_idx` (`userId`),
  CONSTRAINT `sessions_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;

INSERT INTO `sessions` (`id`, `userId`, `token`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,5,'4Tz__qNn0Sq44TGCrItd_ehw3ZOkHxiLYOIycis0dHgNgjnqpu4nKe92CZVxKxb4EOJyeO-NxCmcm6FmivnVZpBDI_aI-bTfiBBV','2020-12-07 08:31:23','2020-12-07 10:07:46','89694143-538d-47b9-933d-265806a62214'),
	(2,5,'xUa4LvjMwKZQPnwBV3gW5ruyCPihB_d1UViErx26yHQw6DeLnuk-0Y-AHbZQ97lN3hP2XZQX2vEbaZFhFrbmYX76gBrOBo0Ne2Ga','2020-12-08 05:17:17','2020-12-08 10:10:59','0e775377-ae09-4d0d-a389-01a88c625af4'),
	(3,5,'jajuf2JIvXsAf7KTiBo23DrOIqB4KBJSZF60oNdEmhB6n0ohw-j-HweKbY4kR9T9Vu3c8zrSQgN4tKG26P_qTmECYSb7D927wv49','2020-12-14 01:30:52','2020-12-14 01:36:41','9cca78a5-0d92-4f67-bb0d-ec853db9b194'),
	(4,5,'7ztTV_n-Ig5znfl3lcFgedWAg_DT0pwDR4MyB62yBjoMbvTU_Hx30wFpYJ74pMnCjQpEGgU80DDZKgUXVr-e4N3_D0F5oDbDRQ4H','2020-12-14 02:56:47','2020-12-14 02:57:25','4930e02f-2a01-4b82-858e-b5bed2e6c675');

/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table shunnedmessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `shunnedmessages`;

CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `shunnedmessages_userId_message_unq_idx` (`userId`,`message`),
  CONSTRAINT `shunnedmessages_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table sitegroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sitegroups`;

CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sitegroups_name_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;

INSERT INTO `sitegroups` (`id`, `name`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,'Craft Blog','2020-12-07 08:31:18','2020-12-07 08:31:18',NULL,'90dee5cc-23f1-40ac-ae14-3fa71bebc4dc');

/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table sites
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sites`;

CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sites_dateDeleted_idx` (`dateDeleted`),
  KEY `sites_handle_idx` (`handle`),
  KEY `sites_sortOrder_idx` (`sortOrder`),
  KEY `sites_groupId_fk` (`groupId`),
  CONSTRAINT `sites_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;

INSERT INTO `sites` (`id`, `groupId`, `primary`, `enabled`, `name`, `handle`, `language`, `hasUrls`, `baseUrl`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,1,1,1,'Craft Demo','default','en-US',1,'$DEFAULT_SITE_URL',1,'2020-12-07 08:31:18','2020-12-07 08:31:22',NULL,'f3400d6f-0f33-4cef-9521-f8f6620399ec');

/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table structureelements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `structureelements`;

CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `structureelements_structureId_elementId_unq_idx` (`structureId`,`elementId`),
  KEY `structureelements_root_idx` (`root`),
  KEY `structureelements_lft_idx` (`lft`),
  KEY `structureelements_rgt_idx` (`rgt`),
  KEY `structureelements_level_idx` (`level`),
  KEY `structureelements_elementId_idx` (`elementId`),
  CONSTRAINT `structureelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `structureelements_structureId_fk` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table structures
# ------------------------------------------------------------

DROP TABLE IF EXISTS `structures`;

CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `structures_dateDeleted_idx` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table systemmessages
# ------------------------------------------------------------

DROP TABLE IF EXISTS `systemmessages`;

CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `systemmessages_key_language_unq_idx` (`key`,`language`),
  KEY `systemmessages_language_idx` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table taggroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `taggroups`;

CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `taggroups_name_idx` (`name`),
  KEY `taggroups_handle_idx` (`handle`),
  KEY `taggroups_dateDeleted_idx` (`dateDeleted`),
  KEY `taggroups_fieldLayoutId_fk` (`fieldLayoutId`),
  CONSTRAINT `taggroups_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table tags
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tags`;

CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tags_groupId_idx` (`groupId`),
  CONSTRAINT `tags_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tags_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table templatecacheelements
# ------------------------------------------------------------

DROP TABLE IF EXISTS `templatecacheelements`;

CREATE TABLE `templatecacheelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `elementId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecacheelements_cacheId_idx` (`cacheId`),
  KEY `templatecacheelements_elementId_idx` (`elementId`),
  CONSTRAINT `templatecacheelements_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE,
  CONSTRAINT `templatecacheelements_elementId_fk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table templatecachequeries
# ------------------------------------------------------------

DROP TABLE IF EXISTS `templatecachequeries`;

CREATE TABLE `templatecachequeries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cacheId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `query` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecachequeries_cacheId_idx` (`cacheId`),
  KEY `templatecachequeries_type_idx` (`type`),
  CONSTRAINT `templatecachequeries_cacheId_fk` FOREIGN KEY (`cacheId`) REFERENCES `templatecaches` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table templatecaches
# ------------------------------------------------------------

DROP TABLE IF EXISTS `templatecaches`;

CREATE TABLE `templatecaches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `siteId` int(11) NOT NULL,
  `cacheKey` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `body` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_path_idx` (`cacheKey`,`siteId`,`expiryDate`,`path`),
  KEY `templatecaches_cacheKey_siteId_expiryDate_idx` (`cacheKey`,`siteId`,`expiryDate`),
  KEY `templatecaches_siteId_idx` (`siteId`),
  CONSTRAINT `templatecaches_siteId_fk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table tokens
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tokens`;

CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tokens_token_unq_idx` (`token`),
  KEY `tokens_expiryDate_idx` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table usergroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `usergroups`;

CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `usergroups_handle_idx` (`handle`),
  KEY `usergroups_name_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table usergroups_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `usergroups_users`;

CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `usergroups_users_groupId_userId_unq_idx` (`groupId`,`userId`),
  KEY `usergroups_users_userId_idx` (`userId`),
  CONSTRAINT `usergroups_users_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usergroups_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table userpermissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `userpermissions`;

CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_name_unq_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table userpermissions_usergroups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `userpermissions_usergroups`;

CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_usergroups_permissionId_groupId_unq_idx` (`permissionId`,`groupId`),
  KEY `userpermissions_usergroups_groupId_idx` (`groupId`),
  CONSTRAINT `userpermissions_usergroups_groupId_fk` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_usergroups_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table userpermissions_users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `userpermissions_users`;

CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userpermissions_users_permissionId_userId_unq_idx` (`permissionId`,`userId`),
  KEY `userpermissions_users_userId_idx` (`userId`),
  CONSTRAINT `userpermissions_users_permissionId_fk` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `userpermissions_users_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table userpreferences
# ------------------------------------------------------------

DROP TABLE IF EXISTS `userpreferences`;

CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `userpreferences_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;

INSERT INTO `userpreferences` (`userId`, `preferences`)
VALUES
	(5,'{\"language\":\"en-US\"}');

/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `firstName` varchar(100) DEFAULT NULL,
  `lastName` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `users_uid_idx` (`uid`),
  KEY `users_verificationCode_idx` (`verificationCode`),
  KEY `users_email_idx` (`email`),
  KEY `users_username_idx` (`username`),
  KEY `users_photoId_fk` (`photoId`),
  CONSTRAINT `users_id_fk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `users_photoId_fk` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `username`, `photoId`, `firstName`, `lastName`, `email`, `password`, `admin`, `locked`, `suspended`, `pending`, `lastLoginDate`, `lastLoginAttemptIp`, `invalidLoginWindowStart`, `invalidLoginCount`, `lastInvalidLoginDate`, `lockoutDate`, `hasDashboard`, `verificationCode`, `verificationCodeIssuedDate`, `unverifiedEmail`, `passwordResetRequired`, `lastPasswordChangeDate`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(5,'andyzack',NULL,NULL,NULL,'andyzack@gmail.com','$2y$13$fhZ7vcR7W/kI8KZF27O8LukHwbGEy49kTryvRf.QG5vLBlXbKr9Bu',1,0,0,0,'2021-01-02 22:42:24',NULL,NULL,NULL,'2020-12-14 01:19:19',NULL,1,'$2y$13$CSUsGBuEpNJpWdAIXW5d0udlr64NYCG0dHsO9WCctbo6imPheikGe','2020-12-14 01:18:05',NULL,0,'2020-12-07 08:31:23','2020-12-07 08:31:23','2021-01-02 22:42:24','8b157d55-f876-407d-b443-27605909fdbf');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table volumefolders
# ------------------------------------------------------------

DROP TABLE IF EXISTS `volumefolders`;

CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `volumefolders_name_parentId_volumeId_unq_idx` (`name`,`parentId`,`volumeId`),
  KEY `volumefolders_parentId_idx` (`parentId`),
  KEY `volumefolders_volumeId_idx` (`volumeId`),
  CONSTRAINT `volumefolders_parentId_fk` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `volumefolders_volumeId_fk` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;

INSERT INTO `volumefolders` (`id`, `parentId`, `volumeId`, `name`, `path`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,NULL,1,'Uploads','','2020-12-07 08:31:18','2020-12-07 08:31:18','3c17a539-ae4d-402b-ad40-1e1828cb358e'),
	(2,NULL,NULL,'Temporary source',NULL,'2020-12-07 19:16:35','2020-12-07 19:16:35','fb730111-8921-4c35-9352-958b498121f0'),
	(3,2,NULL,'user_5','user_5/','2020-12-07 19:16:35','2020-12-07 19:16:35','e2cc706a-6d49-4455-b681-41985bea3191'),
	(4,1,1,'images','images/','2020-12-07 19:31:05','2020-12-07 19:31:05','ff643735-ba62-4481-bd61-a22a1f2bf366');

/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table volumes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `volumes`;

CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `settings` text,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `volumes_name_idx` (`name`),
  KEY `volumes_handle_idx` (`handle`),
  KEY `volumes_fieldLayoutId_idx` (`fieldLayoutId`),
  KEY `volumes_dateDeleted_idx` (`dateDeleted`),
  CONSTRAINT `volumes_fieldLayoutId_fk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;

INSERT INTO `volumes` (`id`, `fieldLayoutId`, `name`, `handle`, `type`, `hasUrls`, `url`, `settings`, `sortOrder`, `dateCreated`, `dateUpdated`, `dateDeleted`, `uid`)
VALUES
	(1,1,'Uploads','uploads','craft\\volumes\\Local',1,'@web/uploads','{\"path\":\"@webroot/uploads\"}',1,'2020-12-07 08:31:18','2020-12-07 08:31:18',NULL,'101a70a1-d200-4629-91e5-3425a0937c0e');

/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table widgets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `widgets`;

CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `widgets_userId_idx` (`userId`),
  CONSTRAINT `widgets_userId_fk` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;

INSERT INTO `widgets` (`id`, `userId`, `type`, `sortOrder`, `colspan`, `settings`, `enabled`, `dateCreated`, `dateUpdated`, `uid`)
VALUES
	(1,5,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2020-12-07 08:31:26','2020-12-07 08:31:26','8d510ce4-520f-4206-88cb-28d7f18a3645'),
	(2,5,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2020-12-07 08:31:26','2020-12-07 08:31:26','4bbbd884-a36e-4b20-b891-2d5cdbffabb3'),
	(3,5,'craft\\widgets\\Updates',3,NULL,'[]',1,'2020-12-07 08:31:26','2020-12-07 08:31:26','170972ec-f8cf-430e-9fe7-4d6f65a24aeb'),
	(4,5,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2020-12-07 08:31:26','2020-12-07 08:31:26','7a9c3213-7d3d-4c29-b559-368ea1c104d2');

/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
